#include <iostream>
#include <queue>
#include <cmath>
#include <vector>
#include <fstream>

using namespace std;

class City
{
    public:
        int x;
        int y;
        int dist(City& b);
        City(int a,int b){x=a,y=b;}
};
int City::dist(City& b)
{
    return (int)ceil(sqrt((this->x-b.x)*(this->x-b.x)+(this->y-b.y)*(this->y-b.y)));
}



vector<City> city ;

bool bf_search(int mid, int dst){
    queue<int> que;
    que.push(0);
    vector<bool> visit(city.size(), false);
    visit[0] = true;

    while(!que.empty()){
        int a = que.front();
        que.pop();
        if(city[a].x == dst && city[a].y == dst) return true;
        for(int i = 0 ; i < city.size(); ++i) {
           if((city[a].dist(city[i]) <= mid) && visit[i] == false)
            {
              que.push(i);
              visit[i] = true;
            }
      }
    }
    return false;
}

int w_is_min(int low, int high,int dst)
{
  if(low>high)
    return low;
  int w = (low+high)/2;
  if(bf_search((int)ceil(sqrt(w*w)),dst))
     return w_is_min(low,w-1,dst);
  else
     return w_is_min(w+1,high,dst);
}

int main(void)
{
   int n, dst;

   ifstream inFile("battery.inp");
   ofstream outFile("battery.out");
   City tmp(0,0);
   inFile >> n >> dst;
   city.push_back(tmp);
   for(int i=0; i<n; i++){
      inFile >> tmp.x >> tmp.y;
      city.push_back(tmp);
   }
   tmp.x=dst,tmp.y=dst;
   city.push_back(tmp);
   int min = 1, max = (int)ceil(sqrt(dst*dst));
   outFile<<w_is_min(min,max,dst)<<endl;
   outFile.close();
   inFile.close();

   return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    char p1[10], p2[10];
    int pxx[10000];
    int pyy[10000];
    int px, py;
    char n1[10],z1[10];
    int n, z;
    double length_s = 0;
    double min_s = 0;
    int path[1000];
    double length[1000];
    int r = 0;

    FILE *fp1 = fopen("battery.inp","r");
    FILE *fp2 = fopen("battery.out","w");
    fscanf(fp1,"%s",n1);
    sscanf(n1,"%d",&n);
    fscanf(fp1,"%s",z1);
    sscanf(z1,"%d",&z);

    pxx[n] = z;
	pyy[n] = z; 
	
	int i;
    for(i=0;i<n;i++) {
        fscanf(fp1,"%s", p1);
        sscanf(p1,"%d",&px);
        fscanf(fp1,"%s", p2);
        sscanf(p2,"%d",&py);
        pxx[i] = px;
        pyy[i] = py;
    }
    
    int past[n+2];
    int t;
    for(t=0;t<=n+1;t++) {
    	past[t] = t;
    }
    
    int l;
    for(l=0;l<=n;l++) {
        length_s = sqrt(pxx[l]*pxx[l] + pyy[l]*pyy[l]);
        if(min_s == 0 || length_s < min_s) {
            min_s = length_s;
            path[r] = l;
            length[r] = min_s;
        }
    }
    past[path[r]+1] = 0;
    r++;
    
    while(1) {
	    int k, j;
	    min_s = 0;
	    for(k=0;k<=n;k++) {
	    	if(past[k+1]!=0&&(pyy[path[r-1]]-pyy[k])<=0) {
			    length_s = sqrt((pxx[path[r-1]] - pxx[k])*(pxx[path[r-1]] - pxx[k]) + (pyy[path[r-1]] - pyy[k])*(pyy[path[r-1]] - pyy[k]));
			    if((min_s == 0 || length_s <= min_s)&&length_s!=0) {
			        min_s = length_s;
			        path[r] = k;
			        length[r] = min_s;
			    }
			}
		}
	    past[path[r]+1] = 0;
		if(path[r] == n) break;
		r++;
	}
	
	double w = 0;
	int q;
	for(q=0;q<=r;q++) {
		if(w == 0 || length[q] > w) {
			w = length[q];
		}
	}
    
    int result = ceil(w);

	printf("%d\n", result);
    fprintf(fp2,"%d", result);
    fclose(fp1);
    fclose(fp2);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char buffer[10000];
	char *str;
	int num;
	FILE *fp = fopen("palin.inp", "r");
	str = fgets(buffer, sizeof(buffer), fp);
	num = atoi(str);
	int out[num] = {0};
	for(int i = 0; i < num; i++) {
		str = fgets(buffer, sizeof(buffer), fp);
		int length = strlen(str) - 1;
		for(int j = 0; j < length/2; j++) {
			out[i] = 1;
			if(str[j]!=str[length-j-1]) {
				if(str[j]==str[length-j-2]) {
					for(int k = length-j-1; k < length-1; k++) {
						str[k] = str[k+1];
					}
					length = length - 1;
					for(int m = 0; m < length/2; m++) {
						out[i] = 2;
						if(str[m]!=str[length-m-1]) {
							out[i] = 3;
							break;
						}
					}
					break;
				}
				if((str[j+1]==str[length-j-1])) {
					for(int k = j; k < length-1; k++) {
						str[k] = str[k+1];
					}
					length = length - 1;
					for(int m = 0; m < length/2; m++) {
						out[i] = 2;
						if(str[m]!=str[length-m-1]) {
							out[i] = 3;
							break;
						}
					}
					break;
				}
				out[i] = 3;
				break;
			}
		}
		printf("%d\n", out[i]);	
	}
	fclose(fp);
	
	FILE *file = fopen("palin.out", "w");
	for(int i = 0; i < num; i++) {
		fprintf(file, "%d\n", out[i]);
	}
	fclose(file);
	
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    char p1[10], p2[10];
    int pxx[10000];
    int pyy[10000];
    int px,py;
    char n1[10],z1[10];
    int n,z;
    double length_s = 0;
    double length_p = 0;
    double length_z = 0;
    double min_s = 0;
    double min_p = 0;
    double max = 0;
    double w=0;

    FILE *fp1 = fopen("battery.inp","r");
    FILE *fp2 = fopen("battery.out","w");
    fscanf(fp1,"%s",n1);
    sscanf(n1,"%d",&n);
    fscanf(fp1,"%s",z1);
    sscanf(z1,"%d",&z);

    int zx_zy[2] = {z,z};

    for(int i=0;i<n;i++){
        fscanf(fp1,"%s", p1);
        sscanf(p1,"%d",&px);
        fscanf(fp1,"%s", p2);
        sscanf(p2,"%d",&py);
        pxx[i] = px;
        pyy[i] = py;
    }
    while(min_p,length_z == 0 || min_p < length_z){
    for(int l=0;l < n;l++){
        length_s = sqrt(pxx[l]*pxx[l] + pyy[l]*pyy[l]);
        if(min_s == 0 || length_s < min_s){
            min_s = length_s;//p(118,13)

            for(int m=0;m<n;m++){
                length_p = sqrt((pxx[l]-pxx[m])*(pxx[l]-pxx[m])+(pyy[l]-pyy[m])*(pyy[l]-pyy[m]));
                length_z = sqrt((pxx[m]-zx_zy[0])*(pxx[m]-zx_zy[0])+(pyy[m]-zx_zy[1])*(pyy[m]-zx_zy[1]));
                if(min_p == 0 || length_p < min_p){
                    min_p = length_p;
                }
                else if(max == 0 || length_p > max){
                    max = length_p;
                }
            }
        }
        }
    }
    if(max > length_z){
        w = max;
    }
    else{
        w = length_z;
    }
    int result = ceil(w);

    fprintf(fp2,"%d",result);
    fclose(fp1);
    fclose(fp2);


    return 0;
}

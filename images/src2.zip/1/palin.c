#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
int main()
{
    char str[10000];
    char *pstr;
    int i,l,m,n,o;
    int flen; //file length
    int length=0;
    int result;

    FILE *fp1 = fopen("palin.inp", "r");
    FILE *fp2 = fopen("palin.out", "w");

    pstr = fgets(str, sizeof(str), fp1);

    int num = atoi(pstr); // ���ڿ��� ���ڷ� ��ȯ

    for(flen = 0; flen < num; flen++){
            pstr = fgets( str, sizeof(str), fp1);
            length = strlen(pstr)-1;
            for(i=0; i< length/2; i++){
                    result = 1;
                    if(pstr[i] != pstr[length-1-i]){
                            if(pstr[i] == pstr[length-2-i]){
                                for(int l = length-i-1; l < length-1; l++){
                                    pstr[l] = pstr[l+1];
                                }
                                length = length -1;
                                for(int m = 0; m < length/2 ; m++){
                                    result=2;
                                    if(pstr[m] != pstr[length-1-m]){
                                        result=3;
                                        break;
                                    }
                                }
                                break;
                            }
                            if(pstr[i+1] == pstr[length-1-i]){
                                    for(n=i; n < length-1; n++){
                                        str[n] = str[n+1];
                                    }
                                    length = length - 1;
                                    for(o = 0; o < length/2 ; o++){
                                        result = 2;
                                        if(pstr[o] != pstr[length-o-1]){
                                            result = 3;
                                            break;
                                        }
                                    }
                                    break;
                                }
                                result= 3;
                                break;
                            }
                    }
                    printf("%d \n", result);
                    if (result == 1){
                        fprintf(fp2, "%d \n", result);
                    }
                    else if(result==2){
                        fprintf(fp2, "%d \n", result);
                    }
                    else if(result==3){
                        fprintf(fp2, "%d \n", result);
                    }
            }
            fclose(fp1);
            fclose(fp2);

            return 0;

}

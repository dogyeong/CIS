f = open('palin.inp', 'r')
n = int(f.readline())
o = open('palin.out', 'w')
    
def lens(a):
    if(len(a)%2 == 0):
        return int(len(a)/2)
    else:
        return int((len(a)-1)/2)

def det(a):
    reva = a[::-1]
    if(reva != a):
        return 0
    else:
        return 1
        
def palin(a):
    if(det(a) == 1):
        return "1"
    else:
        for i in range(0,len(a)):
            newa = a.replace(a[i],"")
            revnewa = newa[::-1]
            if(det(newa)==1):
                return "2"
                break
        return "3"


while(1):
    a = f.readline()
    a = a.replace("\n","")
    if(a):
        o.write(palin(a)+'\n')
    else:
        break
o.close()
f.close()


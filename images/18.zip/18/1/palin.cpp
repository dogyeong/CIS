#include <iostream>
#include <string>
#include <fstream>

using namespace std;

bool is_palindrome(string str) {

   int str_len = str.length();

   for (int i = 0; i < str_len; i++)
      if (str[i] != str[str_len - i-1])
         return false;

   return true;
}

int is_pseudoPalindrome(string str) {

   int str_len = str.length();
   string strCopy = str;

   for (int i = 0; i < str_len; i++)
      if (str[i] != str[str_len - i-1]){
         str.replace(i,1,"");
         strCopy.replace(str_len - i-1,1,"");
         
         if(is_palindrome(str) || is_palindrome(strCopy))
            return 2;
         else
            return 3;
      }

   return 1; // �׳� ȸ���̸� 
}

int main(void)
{
   int cnt;
   string str;
   
   ifstream inFile("palin.inp");
   ofstream outFile("palin.out");
   
   inFile >> cnt;
   
   for(int i=0; i<cnt; i++){
      inFile >> str;
      outFile << is_pseudoPalindrome(str) << endl;
   }
      
// ȸ���̸� 1,  ����ȸ���̸� 2, �ƴϸ� 3 
}

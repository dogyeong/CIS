f = open('palin.inp', 'r')
n = int(f.readline())
    
def lens(a):
    if(len(a)%2 == 0):
        return int(len(a)/2)
    else:
        return int((len(a)-1)/2)

def pal(a):
    for i in range(0,lens(a)):
        if(a[i] != a[len(a)-i-1]):
            for j in range(0,len(a)):
                newa = a.replace(a[j],"")
                for k in range(0,lens(newa)):
                    if(newa[k] == newa[len(newa)-k-1]):
                        res = 2
                        break;
                    else:
                        res = 3
        else:
            res = 1
    print(res)


while(1):
    a = f.readline()
    a = a.replace("\n","")
    if(a):
        pal(a)
        f = open('palin.out','w')
    else:
        break

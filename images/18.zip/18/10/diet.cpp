#include<stdio.h>

int a[20][5];
int standard[4];
int num[20];
int ans[20];
int price = 1000;
int index = 0;

void diet(int n, int r, int k, int l) {
	int sum = 0;
	int data[20] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19};
	bool flag = true;
	
    if(l == r ){
        int pricesum = 0;
        flag = true;
        
        for(int j = 0; j < r; j++){
           pricesum += a[num[j]][4];
        }
        if(pricesum < price){
        for(int i = 0; i < 4; i++){
            sum = 0;
            for(int j = 0; j < r; j++){
                sum += a[num[j]][i];
            }
            if(sum < standard[i]){
            	flag = false;
            	break;
            }
        }
        
        if(flag){
            index = r;
            price = pricesum;
            for(int i = 0; i < r; i++)
            ans[i] = num[i];
         	}
        }
    }
    for (int i = k; i < n; i++){
        num[l] = data[i];
        diet(n, r, i + 1, l + 1);
    }
}

int main()
{
	FILE * inp;
    FILE * out;
    inp = fopen("diet.inp", "r");
	out = fopen("diet.out", "w");
    int n;
    fscanf(inp, "%d", &n);
    for(int i = 0; i < 4;i++){
		fscanf(inp, "%d", &standard[i]);
	}
    for(int i = 0; i < n; i++){
        for(int j = 0; j < 5; j++)
        fscanf(inp, "%d", &a[i][j]);    	
	}
    for(int i = 1; i < n+1; i++){
       diet(n,i,0,0);
    }
    for(int i = 0; i < index; i++){
        fprintf(out, "%d", ans[i]+1);
        if(i != index-1)
            fprintf(out, " ");
    }
    
    fclose(inp);
	fclose(out);
    return 0;
}

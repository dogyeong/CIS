a = input()
b = input()

mat = [[0 for r in range(0,len(a)+4)] for c in range(0,len(b)+4)]
ans = []

answer = []
number = []

big = 0

def remat():
    for r in range(0,len(a)):
        for c in range(0,len(b)):
            mat[c+2][r+2] = 1 if(a[r] == b[c]) else 0
    return mat

mat = remat()

def nmat():
    for r in range(len(a)+2, 0, -1):
        for c in range(len(b)+2, 0, -1):
            if(mat[c][r] != 0 or mat[c-1][r] != 0 or mat[c][r-1] != 0 or mat[c-1][r-1] != 0):
                mat[c-2][r-2] = 1+max(mat[c][r],mat[c-1][r],mat[c][r-1],mat[c-1][r-1]) if(mat[c-2][r-2] != 0) else 0
            else:
                0
    return mat


mat = nmat()

def bigmat():
    for r in range(0,len(a)+2):
        for c in range(0,len(b)+2):
            num = mat[c][r]
            number.append(num)
    return max(number)

big = bigmat()


def rev(dr, dc, big):
    for r in range(dr,len(a)+2):
        for c in range(dc,len(b)+2):
            if(mat[c][r] == big and big > 1):
                answer.append(a[r-2])
                print(answer, big)
                big = big -1
                if(mat[c+1][r+1] == big):
                    dr = r+1
                    dc = c+1
                    rev(dr, dc, big)
                elif(mat[c+1][r+2] == big):
                    dr = r+2
                    dc = c+1
                    rev(dr, dc, big)
                elif(mat[c+2][r+1] == big):
                    dr = r+1
                    dc = c+2
                    rev(dr, dc, big)
                elif(mat[c+2][r+2] == big):
                    dr = r+2
                    dc = c+2
                    rev(dr, dc, big)
            elif big == 1:
                answer.append(a[r-2])
                return answer


answer = rev(0, 0, big)

print(answer)

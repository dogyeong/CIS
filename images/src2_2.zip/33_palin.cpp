﻿#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int N;
string d[11];
int ans[11];

void ReadFile() {
	string filename = "palin.inp";
	ifstream inp;
	string str;
	inp.open(filename);
	inp >> N;
	for (int i = 0; i < N; i++)
		inp >> d[i];

	inp.close();
}

bool isPalin(string chkstr) {
	int ssize = chkstr.size();
	for (int i = 0; i < ssize / 2; i++) {
		if (chkstr[i] != chkstr[ssize - i - 1]) {
			return false;
		}
	}
	return true;
}

int ChkAns(string chkstr) {
	int ssize = chkstr.size();
	bool chkPalin = true;
	string newstr[2];
	for (int i = 0; i < ssize / 2 && chkPalin; i++) {
		if (chkstr[i] != chkstr[ssize - i - 1]) {
			chkPalin = false;
			string origstr = chkstr;
			newstr[0] = chkstr.erase(i, 1);
			chkstr = origstr;
			newstr[1] = chkstr.erase(ssize - i - 1, 1);
		}
	}

	if (chkPalin) return 1;
	bool siPalin = isPalin(newstr[0]);
	if (siPalin) return 2;
	siPalin = isPalin(newstr[1]);
	if (siPalin) return 2;
	return 3;
}

void Run() {
	for (int i = 0; i < N; i++) {
		ans[i] = ChkAns(d[i]);
		//cout << ans[i] << "\n";
	}
}

void WriteFile() {
	string filename = "palin.out";
	ofstream out;
	out.open(filename);
	for (int i = 0; i < N; i++)
		out << ans[i] << "\n";

	out.close();
}

int main()
{
	ReadFile();
	Run();
	WriteFile();

	return 0;
}

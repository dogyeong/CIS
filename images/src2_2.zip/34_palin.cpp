#include <bits/stdc++.h>

using namespace std;

int is_palin(string src)
{
   int i,j;
   int cnt=0;
   
   for(i=0,j=src.length()-1;i<j && cnt!=2 ;++i,--j) {
      if(src[i]!=src[j]) {
         if(src[i]==src[j-1]) {
            --j;
            ++cnt;
            continue;   
         }
         else if(src[i+1]==src[j]) {
            ++i;
            ++cnt;
            continue;
         }
         return 3;
      }
   }
   
   return cnt+1;
}

int main(void)
{
   ifstream ifs("palin.inp");
   int N;
   string src;
   
   ifs >> N;
   
   ofstream ofs("palin.out");
   
   for(int i=0;i<N;++i) {
      ifs >> src;
      ofs << is_palin(src) << endl;
   }
   
   ifs.close();
   ofs.close();
      
   return 0;
}

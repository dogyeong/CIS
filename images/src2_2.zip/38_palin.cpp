#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main(void) {
	ifstream in("palin.inp");
	ofstream out("palin.out");
	int ans[11];
	int n = 0;
	if(in.is_open()) {
		int num;
		int idx = 0;
		in >> n;
		for(int k = 0; k < n; k++) {
			string str;
			num = 0;
			int a = 1;
			in >> str;
			int j = str.size()-1;
			int i = 0;
			while(i < j) {
				if(str[i] == str[j]) {
					i++;
					j--;				
				}
				else if(str[i+1] == str[j]) {
					num++;
					i++;
				}
				else if(str[i] == str[j-1]) {
					num++;
					j--;
				}
				else {
					num+=2;
					break;
				}
			}
			
			if(num == 0)
				ans[idx++] = 1;
			else if(num == 1)
				ans[idx++] = 2;
			else
				ans[idx++] = 3;
			
			}
			
			
		}
	
	if(out.is_open()) {
		for(int i = 0; i < n; i++)
		out << ans[i] <<'\n';
	}	
		
		
	in.close();
	out.close();
	return 0;
}


#include <fstream>
#include <iostream>
#include <string>
using namespace std;

int main()
{
    ifstream infile("palin.inp");
    ofstream outfile("palin.out");
    string str1,str2;
    int n,j;
    infile >> n;
    for(j=0; j<n; j++) {


        infile >> str1;
        str2 = str1;

        int len = str1.length();

        bool pal = true;

        int i, k;

        for (i = 0; i < len / 2; i++) {
            if (str1[i] != str1[len - 1 - i]) {
                pal = false;
                k = i;
                break;
            }
        }
        if (pal == false) {
            str1.erase(len - k, k);
            str1.erase(0, k);

            len = str1.length();

            str2 = str1;

            str1.erase(0, 1);
            str2.erase(len - 1, 1);

            len = str1.length();


            bool a = true, b = true;

            for (i = 0; i < len / 2; i++) {
                if (str1[i] != str1[len - 1 - i])
                    a = false;
                break;
            }
            for (i = 0; i < len / 2; i++) {
                if (str2[i] != str2[len - 1 - i])
                    b = false;
            }


            if (a == false && b == false)
                outfile << "3" << endl;
            else
                outfile << "2" << endl;
        }
        if (pal == true) {
            outfile << "1" << endl;
        }
    }
    infile.close();
    outfile.close();

    return 0;

}
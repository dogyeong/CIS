#include <cstdio>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

class ingre{
public:
	int protein;
	int fat;
	int carbon;
	int vitamin;
	int value;
};

int n, m;
int mp, mf, mc, mv;
int result_v=1000000;
vector<ingre> ingres;
vector<int> result_in;


//int mid_value=0;


//void comb(int n, int r, vector<int>& arr, int sz) {
//	if(r==sz)
//        mid_value = 0;
//	for (int i = n; i >= r; i --) {
//        // choose the first element
//
//        arr[r - 1] = i;
//    	if(mid_value + ingres[i-1].value < result_v){
//    		mid_value += ingres[i-1].value;
//    	}
//    	else
//    		return;
//		if (r > 1) { // if still needs to choose
//            // recursive into smaller problem
//            comb(i - 1, r - 1, arr, sz);
//        } else {
//        	int rp=0, rf=0, rc=0, rv=0;
//        	for (int i = 0; i < sz; i ++) {
//                rp+=ingres[arr[i]].protein;
//           		rf+=ingres[arr[i]].fat;
//           		rc+=ingres[arr[i]].carbon;
//           		rv+=ingres[arr[i]].vitamin;
//		    }
//		    if(rp>=mp && rf>=mf && rc>=mc && rv>=mv){
//		    	result_v = mid_value;
//				for (int i = 0; i < sz; i ++) {
//                	cout << arr[i] << " ";
//            	}
//            	cout << endl;
//            	
//			}
//        }
//    }
//}

vector<int> vc;
void dfs(int cnt)
{
    if (vc.size() == m) {
        int rp=0, rf=0, rc=0, rv=0, va=0;
        for (int i = 0; i < m; i ++) {
            rp+=ingres[vc[i]-1].protein;
          	rf+=ingres[vc[i]-1].fat;
           	rc+=ingres[vc[i]-1].carbon;
           	rv+=ingres[vc[i]-1].vitamin;
           	va+=ingres[vc[i]-1].value;
		}
		if(rp>=mp && rf>=mf && rc>=mc && rv>=mv && va<result_v){
		    result_v = va;
		    result_in = vector<int> (m,0);
		    for (int i = 0; i < m; i ++) {
               	result_in[i] = vc[i];
            }
//			for (int i = 0; i < m; i ++) {
//               	cout << vc[i] << " ";
//            }
//            cout << endl;	
		}
        return;
    }
 
    for (int i = cnt; i <= n; i++)
    {
        if (vc.size() < m)
        {
            vc.push_back(i);
            dfs(i + 1);
            vc.pop_back();
        }
    }
}


void processing(istream& is, ostream& os){
	is >> n;
	is >> mp >> mf >> mc >> mv;
	ingres = vector<ingre>(n);
	
	for(int i=0; i<n; ++i){
		ingre in;
		is >> in.protein >> in.fat >> in.carbon >> in.vitamin >> in.value;
		ingres[i] = in;
	}
	
	for(int i=1; i<=n; ++i){
		m=i;
		dfs(1);
	}
	for(int i=0; i<result_in.size(); ++i)
		os << result_in[i] << ' ';
	os << endl;
}

int main(void){
	ifstream ifs("diet.inp");
	ofstream ofs("diet.out");
	processing(ifs, ofs);
	ifs.close();
	ofs.close();
	
	
	return 0;
}

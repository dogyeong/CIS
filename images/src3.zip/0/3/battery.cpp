#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cmath>

#define endl '\n'
#define pii pair<int, int>
#define pdd pair<double, double>

using namespace std;

double length[1003][1003];

void print(const vector<pdd >& v){
	for(int i=0; i<v.size(); ++i){
		cout << v[i].first << ' ' << v[i].second << endl;	
	}
}

void print_l(int N){
	for(int i=0; i<N; ++i){
		for(int j=0; j<N; ++j){
			cout << length[i][j] << ' ';
		}
		cout << endl;
	}
}

void is_length(int N, const vector<pdd >& v){
	for(int i=0; i<N; ++i){
		for(int j=0; j<N; ++j){
			if(i!=j){
				double dist;
				double x1, y1, x2, y2;
				x1 = v[i].first;
				y1 = v[i].second;
				x2 = v[j].first;
				y2 = v[j].second;
				dist = sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
				length[i][j] = dist;
			}
			else{
				length[i][j] = 0.0;
			}
		}
	}
}

void is_possible(int n, double dist, vector<vector<bool>>& possible){
	for(int i=0; i<n; ++i){
		for(int j=0; j<n; ++j){
			if(length[i][j]<=dist)
				possible[i][j] = true;
		}
	}	
}

bool decision(int n, double dist, vector<bool>& visited, vector<vector<bool>>& possible, int curr){
	//cout << curr << endl;
	visited[curr] = true;
	
	if(curr==n-1)
		return true;
	
	for(int i=0; i<n; ++i){
		bool key = false;
		if( (!visited[i] )&& possible[curr][i]){
			key = decision(n, dist, visited, possible, i);
			if(key == true){
				return true;
			}
		}
	}
	
	if(visited[n-1])
		return true;
	else{
		visited[curr] = false;
		for(int i=0; i<n; ++i){
			possible[i][curr] = false;
			possible[curr][i] = false;
		}
		return false;
	}
}

int optimize(int n, int z){
	int lo=0, ri=(int)(1.5*z);
	int i;
	bool key = false;
	int result = -1;
	
	
	for(i=0; i<15; ++i){
		int mid = (lo + ri)/2;
		vector<bool> visited (n, false);
		vector<vector<bool>> possible (n, vector<bool>(n, false));
		is_possible(n, mid,  possible);	
		
		if(decision(n, mid, visited, possible, 0))
			ri = mid; 
		else	
			lo = mid;
	}
	
	result = ri;
		
	return result;
}

int main(void)
{
	ifstream ifs("battery.inp");
	ofstream ofs("battery.out");
	int n;
	int z;
	ifs >> n >> z;
	vector<pdd > v;
	v.push_back(pdd(0.0,0.0));
	for(int i=0; i<n; ++i){
		double x, y;
		ifs >> x >> y;
		v.push_back(pdd(x, y));
	}
	v.push_back(pdd(z,z));
	
	is_length(n+2, v);
	int result = optimize(n+2,z);
	ofs << result << endl;
	
	ofs.close();
	ifs.close();
	return 0;
}

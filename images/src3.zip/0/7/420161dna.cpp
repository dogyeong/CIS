#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

int row_add[4] = {1, 1, 2, 2};
int col_add[4] = {1, 2, 1, 2};
bool match [1001][1001] = {false,};
vector<char> result;
vector<char> temp;
int n, m;


void matching(const int n, const int m, vector<char>& str1, vector<char>& str2){
	for(int i=0; i<n; ++i){
		for(int j=0; j<m; ++j){
			if(str1[i] == str2[j]){
				match[i][j] = true;
			}
		}
	}
}

void print_str(vector<char>& str, int sz){
	for(int i=0; i<sz; ++i)
		cout << str[i];
	cout << endl;
}

void print_bool(int n, int m){
	for(int i=0; i<n; ++i){
		for(int j=0; j<m; ++j){
			cout << match[i][j] << ' ';
		}
		cout << endl;
	}
}

bool range(int idx, int idy, int n, int m){
	return 0<= idx && idx <n && 0<=idy && idy <m;
}

void set_table(vector<vector<int> >& table, int n, int m){
	for(int i=1; i<n; ++i){
		for(int j=1; j<m; ++j){
			if(match[i-1][j-1] == true){
				table[i][j] = table[i-1][j-1]+1;
			}
			else{
				int num1 = table[i-1][j];
				int num2 = table[i][j-1];
				int num3 = table[i-1][j-1];
				if(num1 > num2){
					if(num1>num3){
						table[i][j] = num1;
					}
				}
				else if (num2 > num3){
						table[i][j] = num2;
				}
				else{
					table[i][j] = num3;
				}
			}
		}
	}
}



void print_table(vector<vector<int> >& table, int n , int m){
	for(int i=0; i<n; ++i){
		for(int j=0; j<m; ++j){
			cout << table[i][j] << ' ';
		}
		cout << endl;
	}
	cout << endl;
}

void DFS(int i, int j, vector<char>& str1, vector<char>& str2, int depth){
	if(depth == 1){
		temp = vector<char> (0);
	}
	
	temp.push_back(str1[i]);
	match[i][j] = false;
		
	int row = i, col =j;
	int count =0;
	for(int k=0; k<4; ++k){
		int nrow = row+row_add[k];
		int ncol = col+col_add[k];
		if(range(nrow, ncol, n, m) && match[nrow][ncol]){
			DFS(nrow, ncol, str1, str2, depth+1);
			count++;
		}
	}
	if(count == 0){
		string str(temp.begin(), temp.end());
		string res(result.begin(), result.end());
		if(temp.size() > result.size()){
			result = temp;
		}
		else if (temp.size() == result.size() && str < res){
			result = temp;
		}
	}
	temp.pop_back();	
}
int main(void){
	/* two string input */
	ifstream ifs("dna.inp");
	if(!ifs.is_open()){
		cerr << "Input file error."<< endl;
		return -1;
	}
	
	string s1, s2;
	ifs >> s1 >> s2;
	ifs.close();
	
		
	/* memorization */
	n = s1.size();
	m = s2.size();
	vector<char> str1(n,0);
	vector<char> str2(m,0);
	
	for(int i=0; i<n; ++i)
		str1[i] = s1.at(i);
	for(int i=0; i<m; ++i)
		str2[i] = s2.at(i);
	
	//print_str(str1, n);
	//print_str(str2, m);
	matching(n, m, str1, str2);

	for(int i=0; i<n; ++i){
		for(int j=0; j<m; ++j){
			if(match[i][j])
				DFS(i, j, str1, str2, 1);
		}
	}
	ofstream ofs("dna.out");
	
	for(int i=0; i<result.size(); ++i)
		ofs << result[i];
	ofs << endl;
	ofs.close();




	return 0;
}

	
	
	
	
	
	
	
	
	
	

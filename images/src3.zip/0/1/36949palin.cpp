#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <queue>

#define pii pair<int, int>
#define endl '\n'

using namespace std;

vector<string> adj;
vector<int> result;

void print(int N, ostream& os){
	for(int i=0; i<N; ++i)
		os << result[i] << endl;
}

int Palindrome(string word){
	int type = 0;

	int i, j;

	for(i=0, j=word.size()-1; i<j && !(word.at(i)!=word.at(j)); ++i, --j)
		;
	if(i>=j)
		type = 1;

	if(type==0){
		int cnt = 0;
		for(i=0, j=word.size()-1; i<j ; ++i, --j)
		{
			if(word.at(i)!=word.at(j) ){
				if(word.at(i+1) == word.at(j) && cnt ==0){
					cnt++;
					++i;
				}
				else
					break;
			}
		}

		if(i>=j)
			type = 2;

		if(type==0){
			for(i=0, j=word.size()-1; i<j ; ++i, --j){
				if(word.at(i)!=word.at(j)){
					if( word.at(i) == word.at(j-1) && cnt ==0){
					cnt++;
					--i;
					}
					else
						break;
				}
			}
			if(i>=j)
			type = 2;
		}
	}

	if(type==0)
		type = 3;

	return type;
}

void processing(int N){

	result = vector<int> (N, 0);

	for(int i=0; i<N; ++i){
		vector<char> v;
		result[i] = Palindrome(adj[i]);
	}
}

int main(void){
	ifstream ifs("palin.inp");
	ofstream ofs("palin.out");
	int N;
	ifs >> N;

	adj = vector<string> (N, "");

	for(int i=0; i<N; ++i)
		ifs >> adj[i];

	processing(N);
	print(N, ofs);

	ifs.close();
	ofs.close();

	return 0;
}


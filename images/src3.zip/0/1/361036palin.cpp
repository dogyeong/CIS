#include <iostream>
#include <fstream>
#include <string>

#define endl '\n'

using namespace std;

class Palindrome{
	int* ip;
	string* sp;
	int len;
public:
	Palindrome(int N):ip(new int[N]), sp(new string[N]), len(N) {}
	~Palindrome(void){
		if(sp!=nullptr)
			delete sp;
		if(ip!=nullptr)
			delete ip;
	}
	void print_s(void){
		for(int i=0; i<len; ++i)
			cout << sp[i] << endl;
	}
	void print_i(ostream& os){
		for(int i=0; i<len; ++i)
			os << ip[i] << endl;
	}
	void input(int i, string word){
		sp[i] = word;
	}
	void palin(void);
};

void Palindrome::palin(void){
	for(int k=0; k<len; ++k){
		string word = sp[k];

		int type = 0;

		int i, j;

		for(i=0, j=word.size()-1; i<j &&!(word.at(i)!=word.at(j)); ++i, --j)
			;
		if(i>=j)
			type = 1;
		if(type==0){
			int cnt = 0;
			for(i=0, j=word.size()-1; i<j ; ++i, --j)
			{
				if(word.at(i)!=word.at(j) ){
					if(word.at(i+1) == word.at(j) && cnt ==0){
						cnt++;
						++i;
					}
					else
						break;
				}
			}
			if(i>=j){
				type = 2;
			}
			if(type==0){
				for(i=0, j=word.size()-1; i<j ; ++i, --j){
					if(word.at(i)!=word.at(j)){
						if( word.at(i) == word.at(j-1) && cnt ==0){
						cnt++;
						--i;
						}
						else
							break;
					}
				}
				if(i>=j)
				type = 2;
			}
		}
		if(type==0)
			type = 3;
		ip[k] = type;
	}
}

int main(void){
	ifstream ifs("palin.inp");
	ofstream ofs("palin.out");

	int N;
	ifs >> N;

	Palindrome p = Palindrome(N);

	for(int i=0; i<N; ++i){
		string word;
		ifs >> word;
		p.input(i, word);
	}
	p.palin();
	p.print_i(ofs);

	ifs.close();
	ofs.close();
	return 0;
}

#include <iostream>
#include <fstream>
#include <queue>
#include <cmath>
#include <cstdlib>
using namespace std;

typedef pair<int, int> pii;

pii adj[1000];
bool visit[1000];


double getDistance(int s, int e, int x, int y)
{
	return ceil(sqrt((s - x)*(s - x) + (e - y)*(e - y)));
}


int main() {
	int n, z, ans = 9999999;

	fstream inp("battery.inp");

	inp >> n >> z;

	for (int i = 0; i < n; i++) {
		int x, y;
		inp >> x >> y;
		adj[i].first = x;
		adj[i].second = y;
	}
	inp.close();


	int left = 0, right = getDistance(0, 0, z, z);

	while (left <= right) {
		int mid = (left + right) / 2;
		bool once = false;
		bool chk = true;

		memset(visit, false, sizeof(visit));
		queue <pii> q;

		q.push({ 0,0 });

		while (!q.empty()) {
			int x = q.front().first;
			int y = q.front().second;
			q.pop();

			if (getDistance(z, z, x, y) <= mid) {
				once = true;
				break;
			}

			for (int i = 0; i < n; i++) {
				int nx = adj[i].first;
				int ny = adj[i].second;

				if (visit[i])
					continue;

				if (getDistance(nx, ny, x, y) <= mid) {
					q.push({ nx, ny });
					visit[i] = true;
				}
			}
		}

		if (once) {
			ans = min(ans, mid);
			right = mid - 1;
		}
		else
			left = mid + 1;

	}
	

	fstream out("battery.out");
	out << ans << endl;

	return 0;
}

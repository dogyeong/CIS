#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int minIngredient[4] = {0,};
int ingredients[20][5] = {0,};
int N = 0;
int sum[5] = {0,};
int minPrice = 1000000;
int result[20] = {0, };

bool check()
{
    if(sum[0] >= minIngredient[0])
    {
        if(sum[1] >= minIngredient[1])
        {
            if(sum[2] >= minIngredient[2])
            {
                if(sum[3] >= minIngredient[3])
                    return true;
                return false;
            }
            return false;
        }
        return false;
    }
    return false;
}
void swap1(int a[], int i, int j)
{
    int temp;

    temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}
void backtrack(int a[], int k, int n)
{

    //cout << "backt" << endl;
    for(int i=0; i<5; i++)
        sum[i] = 0;
    for(int i = 0; i<k; i++)
    {
        //cout <<a[i] << endl;
        for(int j=0; j<5; j++)
        {
            sum[j] += ingredients[a[i]][j];
            //cout << " " << sum[j];
        }
    }
    if(sum[4]>minPrice)
        return;
    //cout << bool(check()) << endl;
    if(check())
    {
        if(minPrice > sum[4])
        {
            /*for(int i=0; i<k; i++)
                cout <<a[i] << " ";
            cout <<endl;*/
            //cout << "sum: " << sum[4] << endl;
            minPrice = sum[4];
            for(int i=0; i<20; i++)
                result[i] = -1;
            for(int i=0; i<k; i++)
                result[i] = a[i];
            return;
        }
        else
            return;
    }

    for(int i=k; i<n; i++)
    {
        swap1(a,k,i);
        backtrack(a, k+1, n);
        swap1(a,k,i);
    }
}
void init()
{
    ifstream fin("diet.inp");
    fin >> N;

    for(int i=0; i<4; i++)
        fin >> minIngredient[i];
    for(int i=0; i<N; i++)
    {
        for(int j=0; j<5; j++)
            fin >> ingredients[i][j];
    }
    for(int i=0; i<20; i++)
        result[i] = -1;
}

int main()
{
    ofstream fout("diet.out");
    init();
    int arr[N];
    for(int i=0; i<N; i++)
        arr[i] = i;
    backtrack(arr, 0, N);
    for(int i=0; i<20; i++)
    {
        if(result[i] != -1)
            fout << result[i]+1 << " ";
    }

    /*for(int i=0; i<3; i++)
    {
        for(int j=0; j<5; j++)
        {
            cout << ingredients[i][j] << " ";
        }
        cout << endl;
    }*/
}

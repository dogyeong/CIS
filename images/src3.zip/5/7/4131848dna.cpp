#include <iostream>
#include <string>
#include <fstream>
#include <cmath>

using namespace std;
int mem[1000][1000] = {0,};
int arr[4] ={0,};
string temp, stand, str2, result="";
int cnt=1;
void check(int xp,int yp)
{
    cnt++;
    temp += stand[xp-2];
    string ptemp = temp;

    if(xp<stand.size()-1 && yp<str2.size()-1)
    {
        if((mem[xp+1][yp+1] == cnt) ||(mem[xp+1][yp+2])==cnt)
        {
            if(mem[xp+1][yp+1] == cnt)
            {
                temp = ptemp;
                check(xp+1, yp+1);
            }
            if(mem[xp+1][yp+2] == cnt)
            {
                temp = ptemp;
                check(xp+1, yp+2);
            }
        }
        if((mem[xp+2][yp+1]==cnt) ||(mem[xp+2][yp+2]==cnt))
        {
            if(mem[xp+2][yp+1] ==cnt)
            {
                temp = ptemp;
                check(xp+2, yp+1);
            }
            if(mem[xp+2][yp+2]==cnt)
            {
                temp = ptemp;
                check(xp+2, yp+2);
            }
        }
    }
    else
    {
        if((mem[xp+1][yp+1] == cnt))
        {
            temp = ptemp;
            check(xp+1, yp+1);
        }
    }
    if(temp.size() > result.size())
    {
        result = temp;
    }
    else if(temp.size() == result.size())
    {
        if(temp < result)
            result = temp;
    }
    cnt--;
    return;
}
int getMax()
{
    int ma = 0;
    for(int i=0; i<4; i++)
    {
        if(arr[i] > ma)
            ma = arr[i];
    }
    return ma;
}
void getLss()
{
    for(int i=0; i<=stand.size();i++)
    {
        for(int j=0; j<=str2.size(); j++)
        {
            if(mem[i][j] == 1)
            {
                check(i, j);
                temp = "";
                cnt = 1;
            }
        }
    }
}
void dpTable()
{
    int ma=0, ma1 = 0;
    for (int i = 2; i <= stand.size()+1; i++)
	{
		for(int j=2; j <= str2.size()+1; j++)
        {
            arr[0] = mem[i-1][j-1];
            arr[1] = mem[i-1][j-2];
            arr[2] = mem[i-2][j-1];
            arr[3] = mem[i-2][j-2];

			if (stand[i - 2] == str2[j - 2])
			{
				mem[i][j] = getMax()+1;
				if(mem[i][j]> ma1)
                    ma1 = mem[i][j];
			}
        }
	}
}


int main()
{
    ifstream fin("dna.inp");
    ofstream fout("dna.out");

    fin >> stand;
    fin >> str2;
    dpTable();
    getLss();
    fout <<result << endl;



}

#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;
int pointArr[1003][3];
double m[1003][1003];
int visit[1003];
int n;

void dfs(double w, int start)
{
    visit[start] = 1;
    for(int i= 0; i<n+2; i++)
    {
        if((m[start][i]<=w) && (!visit[i])){
            dfs(w, i);
        }
    }
}

int w()
{
    double w=1.0;
    while(visit[n+1]==0)
    {
        for(int i=0; i<n+2; i++)
            visit[i]=0;
        dfs(w,0);
        w = w + 1;
    }

    return w-1;
}
double distance(int x1, int y1, int x2, int y2)
{
    double sumX = 0.0,sumY=0.0, result=0.0;
    sumX = pow(abs(x1-x2),2);
    sumY = pow(abs(y1-y2),2);
    result = sumX + sumY;
    return sqrt(result);
}

int main()
{
    ifstream fin("battery.inp");
    ofstream fout("battery.out");

    int z, cnt=0;
    int start = 0;

    fin >> n;
    fin >> z;

    for(int i=1; i<=n; i++)
    {
        fin >> pointArr[i][0];
        fin >> pointArr[i][1];
    }
    pointArr[0][0] = 0;
    pointArr[0][1] = 0;
    pointArr[n+1][0] = z;
    pointArr[n+1][1] = z;

    for(int i=0; i<n+2; i++)
    {
        for(int j=i+1; j<n+2; j++)
        {
            m[i][j] = distance(pointArr[i][0],pointArr[i][1], pointArr[j][0], pointArr[j][1]);
            m[j][i] = distance(pointArr[i][0],pointArr[i][1], pointArr[j][0], pointArr[j][1]);
        }
    }

    fout << w() <<endl;
}

#include <iostream>
#include <fstream>
#include <string>
#include <locale>
#include <algorithm>

using namespace std;

int** table;
int LSS_len = 0;
string result = "";

int checkLSS(string base, string comp)
{
	int len_base, len_comp;
	int MAX;
	string str;

	base = "00" + base;
	comp = "00" + comp;

	len_base = base.length();
	len_comp = comp.length();

	table = new int*[len_comp];
	for(int i=0; i<len_comp; i++)
	{
		table[i] = new int[len_base];
	}

	for(int i=0; i<len_base; i++)
	{
		table[0][i] = 0;
		table[1][i] = 0;
	}

    cout <<"    ";
	for(int i=2; i<len_base; i++)
	{
        cout << base[i] << " ";
	}


	MAX = 0;

	cout << endl << endl;
	for(int i=2; i< len_comp; i++)
	{
        MAX = 0;

		table[i][0] = 0;
		table[i][1] = 0;

		cout << comp[i] << "   ";
		for(int j=2; j<len_base; j++)
		{
			if(comp[i] == base[j])
			{
			    if(table[i-1][j-1] > table[i-2][j-1])
                {
                    MAX = table[i-1][j-1] + 1;
                    table[i][j] = MAX;
                }
                else
                {
                    MAX = table[i-2][j-1] + 1;
                    table[i][j] = MAX;
                }
			}
			else
            {
			    if(comp[i] == base[j-1])
                {
                    table[i][j] = MAX;
                }
                else
                {
                    MAX = 0;
                    table[i][j] = MAX;
                }

			}

			if(LSS_len < MAX)
			{
				LSS_len = MAX;
			}

			cout << table[i][j] << " ";
		}
		cout << endl;
	}
    cout << LSS_len << endl;
	return LSS_len;
}

string findMAX(string base, string comp)
{
	int len_base, len_comp;

	base = "00" + base;
	comp = "00" + comp;

	len_base = base.length();
	len_comp = comp.length();

	int len = LSS_len;
	int k = LSS_len-1;

	char r[LSS_len];
	//char* r = new char[len];
	int temp_i, temp_j;


    char temp = 't';
    for(int i = len_comp-1; i>=2; i--)
    {
        for(int j=len_base-1; j>=2;j--)
        {
            if((table[i][j] == len) && (comp[i] == base[j]))
            {
                if(temp < comp[i])
                {
                    r[k] = temp;
                    temp_i = i;
                    temp_j = j;
                }
                else
                {
                    temp = comp[i];
                    r[k] = comp[i];
                    temp_i = i;
                    temp_j = j;
                }
            }
        }
    }

    cout <<temp_i << " " << temp_j << endl;

    for(len = len-1; len > 0; len--)
    {
        //cout << r[k] << endl;
        k--;
        temp = 't';
//        cout << "k : " <<  k << endl;
//        cout << "len : " << len<< endl;

        for(int i = temp_i-1; i>= temp_i - 2; i--)
        {
            for(int j = temp_j-1; j>= temp_j -2; j--)
            {
                if((table[i][j] == len) && (comp[i] == base[j]))
                {
                    if(temp < comp[i])
                    {
                        r[k] = temp;
                        temp_i = i;
                        temp_j = j;
                    }
                    else
                    {
                        temp = comp[i];
                        r[k] = temp;
                        temp_i = i;
                        temp_j = j;
                    }
                }
            }
        }
    }

    //cout << r[0] << endl;
//    for(int i = 0; i<LSS_len; i++)
//    {
//        cout << r[i];
//    }

    string s;

    for(int i = 0; i< LSS_len; i++)
        s += r[i];
    return s;

}

int main()
{
    string x;
    string y;
    string str;
    int r;

    ifstream in("dna.inp");
    ofstream out("dna.out");

    in >> x;
    in >> y;


    r = checkLSS(x,y);
    str = findMAX(x,y);

    out << str;

    in.close();
    out.close();

	return 0;
}

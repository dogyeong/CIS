#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

int k;
int value;

int* minnut = new int[4];
int* resultBin = new int[20];


int convertNum(int k)
{
    int num = 0;

    for(int i=0; i<k; i++)
    {
        num = num + pow(2,i);
    }

    return num;
}

int* convertBin(int num)
{
    int* bin = new int[20];
    int cnt = 0;

    if(num > 1)
    {
        while(num > 0)
        {
            bin[cnt] = num%2;
            num = num/2;
            ++cnt;
        }
    }

    else if(num == 1)
    {
        bin[0] = 0;
        bin[1] = 0;
        bin[2] = 1;
    }

    else if(num == 0)
    {
        bin[0] = 0;
        bin[1] = 0;
        bin[2] = 0;
    }

    return bin;
}

void diet(int* bin, int* p, int* f, int* s, int* v, int* c, int num)
{
    int* tempResult = new int[5];

    tempResult[0] = 0;
    tempResult[1] = 0;
    tempResult[2] = 0;
    tempResult[3] = 0;
    tempResult[4] = 0;

    if(num < 0)
        return;

    //cout << "num : "<<num << endl;
    for(int i=0; i<k; i++)
    {
        if(bin[i] == 1)
        {
            tempResult[0] += p[i];
            tempResult[1] += f[i];
            tempResult[2] += s[i];
            tempResult[3] += v[i];
            tempResult[4] += c[i];

            if(tempResult[4] > value)
                return;
        }
    }


    if(tempResult[0] > minnut[0] && tempResult[1] > minnut[1] &&
       tempResult[2] > minnut[2] && tempResult[3] > minnut[3] )
    {
        if(tempResult[4] < value)
        {
            value = tempResult[4];
            resultBin = bin;
            //cout << "value : " << value << endl;
        }
    }
}

int main()
{
    ifstream in("diet.inp");
    ofstream out("diet.out");

    int num;
    int* bin = new int[20];

    int* p;
    int* f;
    int* s;
    int* v;
    int* c;

    in >> k;
    //k = 3;
    cout << k << endl;

    value = 10000;

    num = convertNum(k);
    bin = convertBin(num);

    p = new int[k];
    f = new int[k];
    s = new int[k];
    v = new int[k];
    c = new int[k];

    for(int i=0; i<4; i++)
    {
        in >> minnut[i];
    }

    for(int i=0; i<k; i++)
    {
        in >> p[i];
        in >> f[i];
        in >> s[i];
        in >> v[i];
        in >> c[i];
        cout << i+1 << " : " << p[i] << " " << f[i] << " " << s[i] << " " << v[i] << " " << c[i];
        cout << endl;
    }
    cout << endl;

    for(int i=num; i>=0; i--)
    {
        if(i != num)
            bin = convertBin(i);
        diet(bin, p, f, s, v, c, i);
    }

    for(int i=0; i<k; i++)
    {
        if (resultBin[i] == 1)
            out << i+1 << " ";
    }

    return 0;
}

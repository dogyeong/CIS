#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

using namespace std;

class Point{
public:
    double x;
    double y;
};

double dist(vector<Point> P, int i, int j){
	return sqrt(pow(P[i].x - P[j].x, 2) + pow(P[i].y - P[j].y, 2));
}


int findMinDist(vector<Point> P, int start, int num, double temp, int& w)
{
    int len;
    int index;
    double d;
    double prev;

    prev = temp;
    for(int i=1; i<=num+1; i++)
    {
        d = dist(P, start, i);

        if((d < temp) && (d != 0) && (d != prev))
        {
            temp = d;
            index = i;
        }
    }
    len = ceil(temp);

    if(len > w)
        w = len;

    cout << len << " "<< index << endl;
    if(index < num+1) return findMinDist(P, index, num, temp, w);
    else return len;
}


int main(){
	ifstream in;
	ofstream out;
	int n, z;   // ������ �� n, ������ ��ǥ z
	double temp;
	int len;
	int w=0;

	in.open("battery.inp");
	in >> n;
	in >> z;

	vector<Point> P(n+2);
	Point start;
	Point End;

	P[0].x = 0;
	P[0].y = 0;
	P[n+1].x = z;
	P[n+1].y = z;

	for(int i=1; i<n+1; i++)
    {
        in >> P[i].x;
        in >> P[i].y;

        //cout << P[i].x << " " << P[i].y << endl;
    }
	in.close();

    temp = dist(P, 0, n+1);   // ������ ~ ���� �Ÿ�

	len = findMinDist(P, 0, n, temp, w);
	cout << w;


	out.open("battery.inp");


	return 0;
}

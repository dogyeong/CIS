#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <set>
#include <climits>
#include <iterator>

#define isqrt(value) int(ceil(sqrt(double(value))))

using namespace std;

struct Point {
    int x;
    int y;
};

int dist(Point p1, Point p2) {
    return (p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y);
}
int dist(Point p) {
    return p.x*p.x + p.y*p.y;
}

bool operator<(const Point& a, const Point& b) {
    return dist(a) < dist(b);
}

class Edge;
class Vertex;

class Vertex {
public:
    Point p;
    vector<Edge*> edges;
    Edge* beforeEdge;
//    vector <Edge*>parentEdges;
    int minimumDistance;
    Vertex(Point p) {
        this->p = p;
    }
    void setup() {
        minimumDistance = INT_MAX;
        beforeEdge = NULL;
    }
    void setBeforeVertex(Vertex* beforeVertex);
    Edge* getEdge(Vertex* otherVertex);
};


class Edge {
public:
    Vertex *v1;
    Vertex *v2;
    int distance = -1;

    Edge(Vertex *v1, Vertex *v2) {
        this->v1 = v1;
        this->v2 = v2;
        this->distance = dist(v1->p, v2->p);
    }
public:
    Vertex* getOther(Vertex* v) {
        if (v == v1) return v2;
        else return v1;
    }
};

Edge* Vertex::getEdge(Vertex* otherVertex) {
    int size = edges.size();
    for (int i=0; i<size; i++) {
        Edge *edge = edges[i];
        if (edge->getOther(this) == otherVertex) {
            return edge;
        }
    }
}

bool comparePtrToNode(Edge* a, Edge* b) { return ((*a).distance < (*b).distance); }
bool comparePtrToVertex(Vertex* a, Vertex* b) { return (dist((*a).p) < dist((*b).p)); }


class VertexManager {
public:
    Vertex *startVertex;
    Vertex *endVertex;
    vector<Vertex*> vertexes;
    VertexManager(Point startPoint, vector<Point> points, Point endPoint) {
        int psize = points.size();
        startVertex = new Vertex(startPoint);
        vertexes.push_back(startVertex);
        for (int i=0; i<psize; i++) {
            Point p = points[i];
            vertexes.push_back(new Vertex(p));
        }
        endVertex = new Vertex(endPoint);
        vertexes.push_back(endVertex);

        //sort(vertexes.begin(), vertexes.end(), comparePtrToVertex);

        int vsize = vertexes.size();
        if (vsize != 1) {
            for (int i=0; i<vsize-1; i++) {
                Vertex *v1 = vertexes[i];
                for (int j = i+1; j < vsize; j++) {
                    Vertex *v2 = vertexes[j];
                    Edge *edge = new Edge(v1, v2);
                    v1->edges.push_back(edge);
                    v2->edges.push_back(edge);
                }
                sort(v1->edges.begin(), v1->edges.end(), comparePtrToNode);
                v1->setup();
            }
        }
    }

    void start() {
        vector<Vertex*> usedVertexes;
        vector<Vertex*> leftVertexes = this->vertexes;
        Vertex* startVertex = leftVertexes[0];
        leftVertexes.erase(leftVertexes.begin());
        Vertex* currentVertex = leftVertexes[0];
        leftVertexes.erase(leftVertexes.begin());
        currentVertex->minimumDistance = currentVertex->getEdge(startVertex)->distance;
        usedVertexes.push_back(currentVertex);


        this->triv(usedVertexes, leftVertexes, this->endVertex);
    }

    void triv(vector<Vertex*> usedVertexes, vector<Vertex*> leftVertexes, Vertex *endVertex) {
        if (leftVertexes.size()==0) return;
        Vertex *currentVertex = leftVertexes[0];
        leftVertexes.erase(leftVertexes.begin());


        //cout << "------------------------------------------------" << endl;
        //cout << "-> size: " << usedVertexes.size() << ", [" << currentVertex->p.x << ", " << currentVertex->p.y << "]" << endl;

        int vsize = usedVertexes.size();
        int distance;
        int minindex = -1;
        int minWeight = INT_MAX;
        int maxWeight;
        int mindistance = INT_MAX;

        for (int i=0; i<vsize; i++) {
            distance = dist(usedVertexes[i]->p, currentVertex->p);
            maxWeight = max(usedVertexes[i]->minimumDistance, distance);
            if (minWeight > maxWeight || (minWeight == maxWeight && mindistance > distance)) {
                minWeight = maxWeight;
                mindistance = distance;
                minindex = i;
            }
        }

        if (minindex==-1) {
            cout << "minindex is -1!!!!!" << endl;
        }
        Vertex *beforeVertex = usedVertexes[minindex];
        Edge *beforeEdge = currentVertex->getEdge(beforeVertex);

        currentVertex->minimumDistance = max(beforeEdge->distance, beforeVertex->minimumDistance);
        currentVertex->beforeEdge = beforeEdge;
//        beforeVertex->parentEdges.push_back(beforeEdge);


        //cout << "=>" << currentVertex->minimumDistance;
        //cout << " [" << currentVertex->beforeEdge->getOther(currentVertex)->p.x << ", " << currentVertex->beforeEdge->getOther(currentVertex)->p.y << "]" << endl;

        checkUpdate(currentVertex);

        //cout << "=>" << currentVertex->minimumDistance;
        //cout << " [" << currentVertex->beforeEdge->getOther(currentVertex)->p.x << ", " << currentVertex->beforeEdge->getOther(currentVertex)->p.y << "]" << endl;


        usedVertexes.push_back(currentVertex);

        //cout << isqrt(currentVertex->minimumDistance) << endl;

        if (endVertex == currentVertex) {
            return;
        }

        triv(usedVertexes, leftVertexes, endVertex);
    }

    void checkUpdate(Vertex *currentVertex) {
        //cout << "\t[" << currentVertex->p.x << ", " << currentVertex->p.y << "]  " << endl; ;

        for (int i=0; i<currentVertex->edges.size(); i++) {
            Edge *checkingEdge = currentVertex->edges[i];
            Vertex *checkingVertex = checkingEdge->getOther(currentVertex);
            if (!checkingVertex->beforeEdge) continue;


            if (currentVertex->minimumDistance < checkingVertex->minimumDistance ) {
                Edge *checkingEdge = checkingVertex->getEdge(currentVertex);
                //cout << "\t\tin1" << endl;
                if (checkingEdge->distance < checkingVertex->minimumDistance) {
                    //cout << "\t\tin2" << endl;

                    //cout << "\t\t::::" << checkingVertex->minimumDistance;

                    Edge *nextCheckingEdge = checkingVertex->beforeEdge;
                    Edge *be = checkingVertex->beforeEdge;
                    checkingVertex->beforeEdge = checkingEdge;
                    checkingVertex->minimumDistance = max(checkingEdge->distance, currentVertex->minimumDistance);


                    //cout << " -> " << checkingVertex->minimumDistance << endl;

                    if (nextCheckingEdge) {
                        Vertex *nextCheckingVertex = nextCheckingEdge->getOther(checkingVertex);
                        checkUpdate(checkingVertex);
                    }
                }
            }
        }

    }

};

int main() {
    string inputPath = "battery.inp"; //battery
    string outputPath = "battery.out";
    ifstream infile(inputPath);
    ofstream outfile(outputPath);


    int num, z;
    infile >> num >> z;

    Point p;
    p.x = 0;
    p.y = 0;

    Point zp;
    zp.x = z;
    zp.y = z;

    int x, y;
    vector<Point> points;

    //cout << "num: " << num << endl;
    for (int i=0; i<num; i++) {
        infile >> x >> y;
        Point p;
        p.x = x;
        p.y = y;
        points.push_back(p);
    }
    sort(points.begin(), points.end());








    VertexManager *vertexManager = new VertexManager(p, points, zp);
    vertexManager->start();



    Vertex *v = vertexManager->endVertex;
//    while (true) {
//        cout << "[" << v->p.x << ", " << v->p.y << "] - " << v->minimumDistance << endl;
//        v = v->beforeEdge->getOther(v);
//        if (!v) break;
//    }

//    cout << "========" << endl;
//    cout << isqrt(vertexManager->endVertex->minimumDistance) << endl;
//    cout << "========" << endl;



    outfile << isqrt(vertexManager->endVertex->minimumDistance) << endl;



    infile.close();
    outfile.close();


    return 0;
}
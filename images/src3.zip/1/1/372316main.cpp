#include <iostream>

using namespace std;

int main() {
    cout << 1 << endl;
    return 0;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int num = -1;
    string strs[10];
    cin >> num;
    for (int i=0; i<num; i++) {
        cin >> strs[i];
    }

    for (int i=0; i<num; i++) {
        // string str = strs[i];
        int result = 1;
        int i1 = 0;
        int i2 = strs[i].length()-1;
        int leftRemoved = -1;
        int rightRemoved = -1;
        while (true) {
            if (strs[i][i1] != strs[i][i2]) {
                if (leftRemoved == -1) {
                    leftRemoved = i1;
                    i1++;
                    result = 2;
                    continue;
                } else if (rightRemoved == -1) {
                    i1 = leftRemoved;
                    i2 = strs[i].length()-1 - leftRemoved;
                    rightRemoved = i2;
                    i2--;
                    result = 2;
                    continue;
                } else {
                    result = 3;
                    break;
                }
            }

            i1++;
            i2--;
            if (i1 >=i2) {
                break;
            }
        }
        cout << result << endl;
    }


    return 0;
}
#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int num = -1;
//    string strs[10];
    cin >> num;
//    for (int i=0; i<num; i++) {
//        cin >> strs[i];
//    }

    for (int i=0; i<num; i++) {
         string str;// = strs[i];
         cin >> str;
        int result = 1;
        int i1 = 0;
        int i2 = str.length()-1;
        int leftRemoved = -1;
        int rightRemoved = -1;
        while (true) {
            if (str[i1] != str[i2]) {
                if (leftRemoved == -1) {
                    leftRemoved = i1;
                    i1++;
                    result = 2;
                    continue;
                } else if (rightRemoved == -1) {
                    i1 = leftRemoved;
                    i2 = str.length()-1 - leftRemoved;
                    rightRemoved = i2;
                    i2--;
                    result = 2;
                    continue;
                } else {
                    result = 3;
                    break;
                }
            }

            i1++;
            i2--;
            if (i1 >=i2) {
                break;
            }
        }
        cout << result << endl;
    }


    return 0;
}
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

struct Node {
    char c;
    Node *before;
    int length;

    Node() {
        c = ' ';
        before = NULL;
        length = 0;
    }
};



Node dp[1001][1001];

void printAll(int t1size, int t2size) {
    // log
    for (int i=0; i<t1size; i++) {
        for (int j=0; j<t2size; j++) {
            cout << dp[i][j].length << " ";
        }
        cout << endl;
    }
    cout << endl;
}


int main() {

    ios::sync_with_stdio(false);

    string inputPath = "dna.inp";
    string outputPath = "dna.out";
    ifstream infile(inputPath);
    ofstream outfile(outputPath);


    string text1;
    getline(infile, text1);

    string text2;
    getline(infile, text2);

//    cout << text1 << endl;
//    cout << text2 << endl;

    int t1size = text1.size();
    int t2size = text2.size();

    for (int i=t1size-1; i>=0; i--) {
        for (int j = t2size - 1; j >= 0; j--) {
            dp[i][j].length = 0;
            dp[i][j].c = ' ';
            dp[i][j].before = NULL;
        }
    }

    Node *maxNode;
//    Node *totalMaxNode = NULL;
    int maxi, maxj;
    maxj = -1;
    maxi = -1;
    for (int i=t1size-1; i>=0; i--) {
        for (int j=t2size-1; j>=0; j--) {

//            cout << "[" << i << "," << j << "]" << endl;
//            cout << "  <" << dp[696][314].length << "," << dp[696][314].c << ">" << endl;

            if (text1[i] == text2[j]) {
                maxNode = NULL;
                if (i+1 < t1size && j+1 < t2size) {
                    maxNode = (*(dp+i+1)+j+1);//&(dp[i+1][j+1]);
                }

                if (maxNode == NULL && i+2 < t1size && j+1 < t2size) {
                    maxNode = (*(dp+i+2)+j+1);//&(dp[i+2][j+1]);
                } else if (maxNode != NULL && i+2 < t1size && j+1 < t2size) {
                    if (maxNode->length < dp[i+2][j+1].length) {
                        maxNode = (*(dp+i+2)+j+1);//&(dp[i+2][j+1]);
                    } else if (maxNode->length == dp[i+2][j+1].length && maxNode->c < dp[i+2][j+1].c) { // this!!
                        Node *next1 = maxNode->before;
                        Node *next2 = dp[i+2][j+1].before;
                        while (next1) {
                            //cout << "! ";
                            if (next1->c < next2->c) {
                                maxNode = (*(dp+i+2)+j+1);//&(dp[i+2][j+1]);
                                break;
                            }

                            next1 = next1->before;
                            next2 = next2->before;
                        }
                        //cout << endl;
                    }
                }

                if (maxNode == NULL && i+1 < t1size && j+2 < t2size) {
                    maxNode = (*(dp+i+1)+j+2);
                } else if (maxNode != NULL && i+1 < t1size && j+2 < t2size) {
                    if (maxNode->length < dp[i+1][j+2].length) {
                        maxNode = (*(dp+i+1)+j+2);
                    } else if (maxNode->length == dp[i+1][j+2].length && maxNode->c < dp[i+1][j+2].c) { // this!!
                        Node *next1 = maxNode->before;
                        Node *next2 = dp[i+1][j+2].before;
                        while (next1) {
                            //cout << "! ";
                            if (next1->c < next2->c) {
                                maxNode = (*(dp+i+1)+j+2);//&(dp[i+2][j+1]);
                                break;
                            }

                            next1 = next1->before;
                            next2 = next2->before;
                        }
                        //cout << endl;
                    }
                }


                if (maxNode == NULL) {
                    dp[i][j].length = 1;
                    dp[i][j].c = text1[i];
                    dp[i][j].before = maxNode;
                } else {
                    dp[i][j].length = maxNode->length+1;
                    dp[i][j].c = text1[i];
                    dp[i][j].before = maxNode;
                }


                if (maxi == -1 && maxj == -1) {
                    maxi = i;
                    maxj = j;
                } else {
                    if (dp[maxi][maxj].length < dp[i][j].length) {
//                        cout << "1: " << " [" << maxi << "," << maxj << "] ->" << " [" << i << "," << j << "] " << dp[maxi][maxj].length << ", " << dp[i][j].length << endl;

                        maxi = i;
                        maxj = j;



                    } else if (dp[maxi][maxj].length == dp[i][j].length && dp[maxi][maxj].c < dp[i][j].c) { // this!!

//                        cout << "2: " << " [" << maxi << "," << maxj << "] ->" << " [" << i << "," << j << "] " << dp[maxi][maxj].length << ", " << dp[i][j].length << endl;
                        maxi = i;
                        maxj = j;
                    } else if (dp[maxi][maxj].length == dp[i][j].length && dp[maxi][maxj].c == dp[i][j].c) {
                        Node *next1 = dp[maxi][maxj].before;
                        Node *next2 = dp[i][j].before;
                        while (next1) {
                            if (next1->c < next2->c) {
                                maxi = i;
                                maxj = j;
                                break;
                            }

                            next1 = next1->before;
                            next2 = next2->before;
                        }
                    }
                }

            } else {
                dp[i][j].length = 0;
                dp[i][j].c = ' ';
                dp[i][j].before = NULL;
            }
        }
    }



//    // log
//    for (int i=t1size-1; i>=0; i--) {
//        for (int j=text2.size()-1; j>=0; j--) {
//            cout << dp[i][j].c << " ";
//        }
//        cout << endl;
//    }
//    cout << endl;

//    // log
//    for (int i=0; i<t1size; i++) {
//        for (int j=0; j<t2size; j++) {
//            cout << dp[i][j].length << " ";
//        }
//        cout << endl;
//    }
//    cout << endl;
//
//    cout << dp[maxi][maxj].length << endl;

    Node *next = NULL;
    if (maxi != -1 && maxj != -1) {
        next = &dp[maxi][maxj];
    }

    while(next != NULL) {
        if (next->c != ' ') {
//            cout << next->c;
            outfile << next->c;
        }
        next = next->before;
    }

    infile.close();
    outfile.close();


    return 0;
}
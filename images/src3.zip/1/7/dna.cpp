#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

struct Node {
    char c;
    Node *before;
    int length;

    Node() {
        c = ' ';
        before = NULL;
        length = 0;
    }
};



Node dp[1001][1001];

Node* compareNode(Node *maxNode, int i, int j, int deltai, int deltaj, int t1size, int t2size) {
    if (maxNode == NULL && i+deltai < t1size && j+deltaj < t2size) {
        if (dp[i+deltai][j+deltaj].length != 0) {
            maxNode = (*(dp+i+deltai)+j+deltaj);
        } else {
            maxNode = NULL;
        }
    } else if (maxNode != NULL && i+deltai < t1size && j+deltaj < t2size) {
        if (maxNode->length < dp[i+deltai][j+deltaj].length) {
            maxNode = (*(dp + i + deltai) + j + deltaj);
        } else if (maxNode->length == dp[i+deltai][j+deltaj].length && maxNode->c > dp[i+deltai][j+deltaj].c) {
            maxNode = (*(dp + i + deltai) + j + deltaj);
        } else if (maxNode->length == dp[i+deltai][j+deltaj].length && maxNode->c == dp[i+deltai][j+deltaj].c) {

            Node *next1 = maxNode->before;
            Node *next2 = dp[i+deltai][j+deltaj].before;

            while (next1 && next2) {

                if (next1->c > next2->c) {
                    maxNode = (*(dp+i+deltai)+j+deltaj);
                    break;
                } else if (next1->c < next2->c) {
                    break;
                }

                next1 = next1->before;
                next2 = next2->before;
            }



        }
    }
    return maxNode;
}


int main() {

    ios::sync_with_stdio(false);

    string inputPath = "dna.inp";
    string outputPath = "dna.out";
    ifstream infile(inputPath);
    ofstream outfile(outputPath);

//    vector<string> texts1 = {"cttttag", "gaacccg", "ttacctc", "acaccct", "acagacc", "ctggctt", "aatagtc", "atccgac", "tttgggg", "tagaaaa", "accgcgg", "tccctat", "attggct", "attgact", "gacgggt", "tgccagg", "cgccgct", "taagggc", "gagagcc", "cctgcag", "ttacgaa", "gtttggt", "tatagaa", "agggagt", "tagctcg", "gctaaac", "ttagcac", "gcgctca", "gtctttc", "ccggcgt", "cgaggcg", "cctttag", "caggcgg", "gcatgca", "tcggtac", "gtcacgg", "tcggacc", "aattagt", "aacggaa", "cgtccta", "cacataa", "cctgtga", "tggcgct", "gtagaag", "agcttat", "taagctg", "ctggtcc", "aatcgat", "ctctcta", "taccgtc", "aagtctt", "cttggtt", "aatactc", "cgctcgc", "cacacta", "aggcagg", "ggccgag", "acatttc", "cgactag", "tatacct", "tgtcaat", "ttcgtgc", "gctagta", "taaaggc", "cccaaat", "tgtacca", "aggggcc", "cgaaatg", "attggct", "cgagtac", "atagagg", "gaagcag", "acctgtt", "cctcaac", "gcgcaag", "aaatatt", "cggatct", "gctagag", "gcggggg", "ctgatta", "aaatcaa", "tgagacg", "cccacct", "gtcctct", "ttctcgc", "tccgagc", "ttcctct", "aacttag", "tatctgc", "cactcac", "cctgacg", "tcacgtt", "acactaa", "tcctacc", "gtagtca", "atgttta", "gtcagaa", "cggttgg", "atgctaa", "tccgtct", "gacaacta", "caacggac", "cgcgcgtt", "tctgtacg", "ttacgtgc", "cctataaa", "tcatcagc", "catcacgg", "tccgtgga", "tattagtg", "ttatcagt", "tgtacaaa", "gcatagcc", "gctagcac", "ttgaggcc", "catgtatg", "atagaagt", "gcgagttc", "tcacggcg", "gggtgttt", "acaagtca", "gggtcgcc", "tcaagctt", "aagaataa", "tcattgag", "cataaaga", "tgaagtga", "gcgcatca", "tctacctt", "ctgaaaac", "gcagcata", "accccatc", "gctactga", "ccatcgct", "ctttcgga", "aaggacta", "ttcaacat", "ttgtcctg", "actcacat", "cgcgatta", "cagcatga", "cctcgggg", "gaagaggg", "cactctcg", "caacctac", "acgcgcgt", "ggcaccat", "ctcactgc", "gatacttc", "tcagtatt", "ctcactcg", "atgatgtt", "gctagcgc", "cgcctcaa", "cgcctcag", "ctagaggc", "gtatggat", "tcagcctg", "gccggtcc", "gcggcgac", "caaataat", "ccacgatg", "cacaaaca", "gggtgggt", "gaacgctt", "ctctagcc", "tttaacat", "ttcttgta", "tggcaaat", "tcaatccg", "caaccgtg", "agtaaggg", "ctagtcaa", "cgagctcc", "cgtgtgat", "atccactg", "gcaacgta", "attgtact", "ctgctgtc", "acagagac", "ctgggatc", "ccctcgga", "acaccttt", "tgccatgc", "caaaagat", "agaggagc", "gatacaca", "caagactg", "acatcaag", "cgttatac", "tcattccg", "aacgctgt", "cgatagcg", "tatgggtt", "aatagcaa", "ttgacgct", "cggcctaa", "ttaaatac", "ttagcctg", "cgtaaccg", "acaaccccg", "ttagtcatt", "gcgcgctgc", "gctactcac", "tgtgggtgc", "cgccgtcct", "aggcgataa", "cctcgccag", "atctgtcca", "agtgtcgaa", "ttaggcatg", "cgctaggca", "aactttctc", "atttagccc", "gcaatcaat", "tgactgcga", "gaggcacta", "gttggtgcc", "acaaccata", "cgggtgagc", "tgcacatca", "tgagactat", "ctttcgccc", "gcggctccg", "gcatgcgcc", "ctgatgtat", "tgatccttg", "gcaaacgtg", "aagcattgt", "cgacaggaa", "ccttacggc", "acaggagtt", "gccaatgta", "gtaaaggaa", "tcgattgga", "acgacgctc", "gctatatct", "tcgacaatg", "ccgcccgtt", "agtacagta", "cctttaccg", "tggactaaa", "cactagaat", "gcggtgcca", "tcctagggc", "actctgacc", "tgcgcaaca", "acgcgacac", "ctcatcaac", "caaacattt", "gcaggttct", "cagcttatt", "tgtgagggc", "acacctgca", "tagcctgac", "tccagctgc", "tactagatg", "tattccacg", "acagatctg", "tgctgtccg", "atcggtgag", "catatggag", "caatagcat", "cgcgagagc", "cacacgacc", "tatcacttg", "agatcttgg", "ccgcgattc", "taggggacg", "cctccattt", "tgagcgtat", "gtgaagcat", "tcgttgtac", "gactatcgt", "gcctggcgt", "aaccgtatc", "ggtgctcac", "ttcgaaaag", "catagtagt", "gcaagcgac", "ggtcctgcc", "aacgctaaa", "tgcttgttc", "tcgaaattt", "ctaccatta", "taagccgaa", "actcgttgc", "ccagggcaa", "gagttaaac", "ctcagcagg", "aacgcagcc", "ggcccccat", "ttggaggat", "gcagtgtta", "cacgcacac", "gctcttgga", "cattggaac", "ttcatggaa", "tagtataac", "cggtcctcc"};
//    vector<string> texts2 = {"agtcaaa", "taccagg", "attaatc", "tggacgc", "tggacga", "ggcgtgc", "caccaaa", "tctctct", "tgttgcg", "gacttgc", "acctatg", "agacctg", "acgactt", "aattatt", "aatcagg", "tacagtt", "actggta", "gcttttc", "gacgagt", "cggccat", "cggggac", "gacactt", "gatgctc", "aacaagt", "gggcaaa", "gtcctag", "gctactc", "cccacgg", "attaagg", "gtgtcta", "aactctt", "ccagaat", "actacat", "gatatga", "ctcttat", "tctcgtg", "cagaggc", "attacca", "tccatca", "tcgacta", "ccctaaa", "ggggtag", "gtggttt", "cattaat", "tacaaga", "cctgtac", "agcaggc", "caaggta", "ctgaaga", "agacaga", "ctaagct", "ggttaat", "cgaacac", "atagagg", "actactt", "atgggta", "ggtctcc", "cagcccg", "tggcgaa", "atctcgt", "tcctaga", "cacccag", "attaaat", "agctaga", "cattacg", "tgtgggg", "ctgcagg", "ttgtacg", "gcaccca", "ggcacgt", "atcttta", "gcgtata", "tttatct", "tgcaggc", "gcacgag", "ataaaac", "cagacta", "tgccaaa", "cgaggaa", "ggcaaat", "gacacag", "acgttac", "gcctgat", "ttgtcgt", "accgaag", "agagcac", "gtagtca", "gcgtggg", "caggtcg", "cccccta", "attctat", "tgcgtag", "gctcgtc", "ctccaag", "ctgtata", "cgacgac", "cctgttt", "ttgtgta", "agaagtt", "cggcccc", "tagcacag", "taatatgt", "agtggcat", "gttacgtg", "tgcagcct", "gccctttc", "agtgaaca", "ccgtcgca", "ggactaga", "gactgccc", "ttaaccca", "tttttgtt", "tgaaggcc", "ttcaagtg", "caagcgta", "gttgatac", "ctatacca", "tgattaga", "tttaagac", "cggggtag", "acgacttc", "ggcctatg", "cggggatg", "ttaataaa", "ctgacgtc", "gtcgcaac", "gcggaagg", "atcgcatg", "ttataaac", "acaacgac", "gagctgca", "gcgagcag", "ctacttcg", "tgcactca", "atgcgcta", "ccgttccc", "ggattggt", "gtgagctg", "gtcgaaaa", "gagcatga", "gggctgtc", "gtcaagtc", "cgatcaat", "tcctctaa", "tcagtagc", "tgagtatg", "ggcacatc", "cgtatggt", "gcctgagt", "cagaaagc", "gcccgggt", "acgtggct", "actgggac", "ctgacacg", "tttctaag", "ggattgcc", "gaccaacg", "tcattcaa", "gaataggg", "atctacca", "ttattggt", "cagcgaca", "cttatggt", "gatcctag", "ggtcatct", "tagccgat", "gtaaagca", "ataaggaa", "cgcgctgc", "aaaaaatt", "gcccactt", "ggtccgac", "acgtgaat", "gaagtact", "tctaaaac", "caaaaaaa", "gttttgtg", "ccgcctac", "gcgaatga", "ctccaatt", "tggcgctt", "gccaataa", "agaacctg", "aatgttag", "tccgttgt", "tctgtaga", "tgtttgtg", "cgaatagt", "cgagagag", "cactttgc", "gaatatag", "aaagttaa", "gatgggag", "ctatcata", "ggcacagt", "gataatga", "tcttgaag", "gtcgccat", "gcatgggt", "gggatcgc", "aggacaaac", "agggcagtt", "gaaccaatc", "tacccgctt", "aatgcagaa", "accagattc", "ctggcgact", "aaggctgtg", "gatcttggt", "gatcacgca", "gactcactt", "aggcacctt", "ccgtagaat", "agagttgag", "aatcaagaa", "atgggtatg", "caggcggac", "tctaatttc", "gaattatta", "gatagggag", "aacggatag", "ccaaacggc", "gcagttagt", "actaacacc", "cgagagtag", "tttgaggcc", "atggtttgt", "attttaaga", "gtattgtcg", "agcgatagg", "tggggcctc", "ggcagttcg", "attttgggg", "tcagcttgg", "gagacacga", "agcctggga", "aatcacttg", "ctgcgctag", "gggcgtcag", "gcgtttact", "agccgtgtg", "gggagggca", "gctttatca", "ggtgtcaag", "taggcgtgg", "aagggagcc", "ggcctctct", "cgtaacgcc", "acagcctag", "taaacacta", "cgacggtgt", "attgatcct", "ctcatgcct", "tatgattaa", "agtgacatc", "tctcctgct", "ttaaggcct", "tgtatattc", "aacttccgc", "aatttgttt", "tgggcttcc", "ctggtctgg", "aattgggtc", "ttaagggcc", "cgtaagacg", "agtatacat", "tctgcacat", "tattaccta", "gcgcgcacc", "acctcgcaa", "gagttactg", "tagattttg", "actagagga", "atacatgat", "caagctctg", "tcctctgta", "gctgacaat", "ttccatctg", "gtatccgtc", "cctggattt", "atcggattg", "gccgtatat", "gaccgaaaa", "tacccggat", "agttcggct", "ggacaatca", "gtgcatctg", "ttcgcgaat", "ggatttctc", "caaggctcc", "gtagaactg", "tcttgcggg", "ccgtccacc", "catgataaa", "atgaggcct", "tcacgcagt", "gcagggttg", "tccaatgac", "tgggtacgg", "acgagagag"};
//    vector<string> answers = {"ag", "accg", "ttac", "acc", "acga", "cggc", "aaa", "tcc", "tttgg", "ga", "acc", "cct", "att", "attat", "acgg", "tcag", "cgt", "gc", "gagag", "cgca", "ac", "tt", "atg", "agt", "gc", "gcta", "gcac", "ccca", "tt", "ggct", "a", "ag", "ca", "atga", "ta", "tccgg", "cggc", "atta", "ac", "cgcta", "ccaaa", "gga", "gggt", "taa", "ac", "ctg", "cggc", "aa", "cta", "acg", "aagct", "ggtt", "aaac", "tg", "acact", "agga", "ggcc", "ac", "cga", "atcct", "tcaa", "cg", "ata", "agc", "cat", "tgt", "agg", "ag", "gc", "cagt", "at", "gaa", "act", "tca", "gccag", "aaaa", "cgact", "gcaa", "cggg", "at", "aaca", "acg", "cct", "gtct", "ccg", "gagc", "tc", "ctg", "tcg", "ccca", "cta", "cgt", "cct", "ctcc", "gtata", "ag", "cg", "ttgg", "agt", "cgc", "acaca", "aag", "ggct", "gtacg", "act", "cctt", "atac", "ctcc", "ctga", "atg", "ttaca", "tgt", "gaagcc", "cag", "agc", "gtat", "ata", "gatt", "tagc", "ggggt", "acatc", "ggcc", "ag", "aaaaa", "ctgag", "caa", "gaagg", "cgcat", "ttac", "aaac", "gagct", "cac", "ctactg", "cacc", "tcg", "ct", "at", "gctg", "tcaa", "gcata", "gctg", "tc", "aa", "cctct", "tac", "ggt", "ggcacat", "ctatg", "gat", "caga", "cccg", "agtgt", "ctggc", "cgcc", "ctag", "ga", "ag", "tca", "gg", "cac", "tat", "cacga", "a", "gt", "gctt", "tagcc", "taaca", "ga", "ggc", "aat", "cact", "ga", "agtaa", "gagtc", "tta", "ca", "gt", "tac", "gcg", "caa", "tgggt", "cc", "aacct", "atg", "gt", "gaga", "gt", "caaat", "caag", "ctttc", "att", "aagtt", "gatgg", "tat", "gcaa", "tag", "ctaa", "at", "gctg", "gacc", "acaac", "agcatt", "cc", "taccc", "tgc", "ccgtc", "ggcgat", "ctg", "atctgt", "gtca", "cat", "aggca", "aat", "attag", "aatcaa", "atgga", "aggac", "tc", "ata", "gggag", "aac", "aac", "ttg", "ccc", "cagg", "tgag", "tgt", "aaa", "gattgt", "cgaagg", "cctc", "ggagtt", "att", "tag", "cga", "agcct", "atact", "tcgcag", "cgcg", "cgta", "accg", "ggca", "aca", "gggtca", "taggc", "gacc", "gcc", "cgaac", "acac", "aaacat", "caggtt", "ttat", "tagc", "tga", "tact", "tccgct", "taag", "tattc", "aatcg", "tgtt", "tggg", "ttgg", "aatg", "aagc", "aagac", "tatact", "gact", "attc", "gggac", "cctcca", "ggtat", "tagat", "ctga", "acatgt", "gcctg", "ccgta", "gctac", "ttca", "gtat", "cga", "ggt", "cctaa", "gc", "cgat", "att", "gcaa", "atctg", "cggaa", "gatt", "cagc", "aacg", "ct", "gt", "catgta", "agcc", "cc", "ttg", "tcatga", "tgta", "cgg"};





    string text1;
    getline(infile, text1);

    string text2;
    getline(infile, text2);



    int t1size = text1.size();
    unsigned long t2size = text2.size();

    for (int i=t1size-1; i>=0; i--) {
        for (int j=t2size-1; j>=0; j--) {
            dp[i][j].length = 0;
            dp[i][j].c = ' ';
            dp[i][j].before = NULL;
        }
    }

    Node *maxNode;


    int maxi, maxj;
    maxj = -1;
    maxi = -1;
    for (int i=t1size-1; i>=0; i--) {
        for (int j=t2size-1; j>=0; j--) {

            if (text1[i] == text2[j]) {
                maxNode = NULL;

                maxNode = compareNode(maxNode, i, j, 1, 1, t1size, t2size);
                maxNode = compareNode(maxNode, i, j, 2, 1, t1size, t2size);
                maxNode = compareNode(maxNode, i, j, 1, 2, t1size, t2size);
                maxNode = compareNode(maxNode, i, j, 2, 2, t1size, t2size);

                if (maxNode == NULL) {
                    dp[i][j].length = 1;
                    dp[i][j].c = text1[i];
                    dp[i][j].before = maxNode;
                } else {
                    dp[i][j].length = maxNode->length+1;
                    dp[i][j].c = text1[i];
                    dp[i][j].before = maxNode;
                }


                if (maxi == -1 && maxj == -1) {
                    maxi = i;
                    maxj = j;
                } else {
                    if (dp[maxi][maxj].length < dp[i][j].length) {
                        maxi = i;
                        maxj = j;

                    } else if (dp[maxi][maxj].length == dp[i][j].length && dp[maxi][maxj].c > dp[i][j].c) { // this!!
                        maxi = i;
                        maxj = j;
                    } else if (dp[maxi][maxj].length == dp[i][j].length && dp[maxi][maxj].c == dp[i][j].c) {

                        Node *next1 = dp[maxi][maxj].before;
                        Node *next2 = dp[i][j].before;
                        while (true) {
                            if (next1 && next2 && next1->c > next2->c) {
                                maxi = i;
                                maxj = j;
                                break;
                            } else if (next1 && next2 && next1->c < next2->c) {
                                break;
                            } else if (!next1 && !next2) {
                                break;
                            } else if (!next1 && next2) {
                                maxi = i;
                                maxj = j;
                                break;
                            } else if (!next2 && next1) {
                                break;
                            } else {
                                next1 = next1->before;
                                next2 = next2->before;
                            }
                        }
                    }
                }

            } else {
                dp[i][j].length = 0;
                dp[i][j].c = ' ';
                dp[i][j].before = NULL;
            }
        }
    }


    Node *next = NULL;
    if (maxi != -1 && maxj != -1) {
        next = &dp[maxi][maxj];
    }

    while(next != NULL) {
        if (next->c != ' ') {
//            cout << next->c;
            outfile << next->c;
        }
        next = next->before;
    }

    infile.close();
    outfile.close();


    return 0;
}
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

struct Node {
    char c;
    Node *before;
    int length;

    Node() {
        c = ' ';
        before = NULL;
        length = 0;
    }
};



Node dp[1001][1001];

void printAll(int t1size, int t2size) {
    // log
    for (int i=0; i<t1size; i++) {
        for (int j=0; j<t2size; j++) {
            cout << dp[i][j].length << " ";
        }
        cout << endl;
    }
    cout << endl;
}

Node* compareNode(Node *maxNode, int i, int j, int deltai, int deltaj, int t1size, int t2size) {
    if (maxNode == NULL && i+deltai < t1size && j+deltaj < t2size) {
        maxNode = (*(dp+i+deltai)+j+deltaj);
    } else if (maxNode != NULL && i+deltai < t1size && j+deltaj < t2size) {
        if (maxNode->length < dp[i+deltai][j+deltaj].length) {
            maxNode = (*(dp+i+deltai)+j+deltaj);
        } else if (maxNode->length == dp[i+deltai][j+deltaj].length && maxNode->c > dp[i+deltai][j+deltaj].c) { // this!!
            Node *next1 = maxNode->before;
            Node *next2 = dp[i+deltai][j+deltaj].before;
            while (next1 && next2) {
                //cout << "! ";
                if (next1->c > next2->c) {
                    maxNode = (*(dp+i+deltai)+j+deltaj);//&(dp[i+2][j+1]);
                    break;
                }

                next1 = next1->before;
                next2 = next2->before;
            }
            //cout << endl;
        }
    }
    return maxNode;
}


int main() {

    ios::sync_with_stdio(false);

    string inputPath = "dna.inp";
    string outputPath = "dna.out";
    ifstream infile(inputPath);
    ofstream outfile(outputPath);


    string text1;
    getline(infile, text1);

    string text2;
    getline(infile, text2);

//    cout << text1 << endl;
//    cout << text2 << endl;

    int t1size = text1.size();
    int t2size = text2.size();

    for (int i=t1size-1; i>=0; i--) {
        for (int j=t2size-1; j>=0; j--) {
            dp[i][j].length = 0;
            dp[i][j].c = ' ';
            dp[i][j].before = NULL;
        }
    }

    Node *maxNode;
//    Node *totalMaxNode = NULL;


    int maxi, maxj;
    maxj = -1;
    maxi = -1;
    for (int i=t1size-1; i>=0; i--) {
//        cout << "----- " << i << endl;
        for (int j=t2size-1; j>=0; j--) {

            if (text1[i] == text2[j]) {
                maxNode = NULL;

                maxNode = compareNode(maxNode, i, j, 1, 1, t1size, t2size);
                maxNode = compareNode(maxNode, i, j, 2, 1, t1size, t2size);
                maxNode = compareNode(maxNode, i, j, 1, 2, t1size, t2size);
                maxNode = compareNode(maxNode, i, j, 2, 2, t1size, t2size);

                if (maxNode == NULL) {
                    dp[i][j].length = 1;
                    dp[i][j].c = text1[i];
                    dp[i][j].before = maxNode;
                } else {
                    dp[i][j].length = maxNode->length+1;
                    dp[i][j].c = text1[i];
                    dp[i][j].before = maxNode;
                }


                if (maxi == -1 && maxj == -1) {
                    maxi = i;
                    maxj = j;
                } else {
                    if (dp[maxi][maxj].length < dp[i][j].length) {
//                        cout << "1: " << " [" << maxi << "," << maxj << "] ->" << " [" << i << "," << j << "] " << dp[maxi][maxj].length << ", " << dp[i][j].length << ", " << dp[i][j].c << endl;

                        maxi = i;
                        maxj = j;

//                        Node *next = &(dp[i][j]);
//                        while(next != NULL) {
//                            if (next->c != ' ') {
//                                cout << next->c;
//                            }
//                            next = next->before;
//                        }
//                        cout << endl;

                    } else if (dp[maxi][maxj].length == dp[i][j].length && dp[maxi][maxj].c > dp[i][j].c) { // this!!

//                        Node *next = &(dp[i][j]);
//                        while(next != NULL) {
//                            if (next->c != ' ') {
//                                cout << next->c;
//                            }
//                            next = next->before;
//                        }
//                        cout << endl;

//                        cout << "2: " << " [" << maxi << "," << maxj << "] ->" << " [" << i << "," << j << "] " << dp[maxi][maxj].length << ", " << dp[i][j].length << ", " << dp[i][j].c << endl;
                        maxi = i;
                        maxj = j;
                    } else if (dp[maxi][maxj].length == dp[i][j].length && dp[maxi][maxj].c == dp[i][j].c) {
//                        cout << "3: " << " [" << maxi << "," << maxj << "] ->" << " [" << i << "," << j << "] " << dp[maxi][maxj].length << ", " << dp[i][j].length << ", " << dp[i][j].c << endl;
                        Node *next1 = dp[maxi][maxj].before;
                        Node *next2 = dp[i][j].before;
                        while (true) {
                            if (next1 && next2 && next1->c > next2->c) {
                                maxi = i;
                                maxj = j;
//                                cout << "???" << endl;
                                break;
                            } else if (!next1 && !next2) {
                                continue;
                            } else if (!next1 && next2) {
                                maxi = i;
                                maxj = j;
                                break;
                            } else if (!next2 && next1) {
                                break;
                            }

                            next1 = next1->before;
                            next2 = next2->before;
                        }
                    }
                }

            } else {
                dp[i][j].length = 0;
                dp[i][j].c = ' ';
                dp[i][j].before = NULL;
            }
        }
    }



//    // log
//    for (int i=t1size-1; i>=0; i--) {
//        for (int j=text2.size()-1; j>=0; j--) {
//            cout << dp[i][j].c << " ";
//        }
//        cout << endl;
//    }
//    cout << endl;

//    // log
//    for (int i=0; i<t1size; i++) {
//        for (int j=0; j<t2size; j++) {
//            cout << dp[i][j].length << " ";
//        }
//        cout << endl;
//    }
//    cout << endl;
//
//    cout << dp[maxi][maxj].length << endl;

    Node *next = NULL;
    if (maxi != -1 && maxj != -1) {
        next = &dp[maxi][maxj];
    }

    while(next != NULL) {
        if (next->c != ' ') {
//            cout << next->c;
            outfile << next->c;
        }
        next = next->before;
    }

    infile.close();
    outfile.close();


    return 0;
}
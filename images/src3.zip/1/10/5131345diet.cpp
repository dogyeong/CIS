#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stack>
#include <algorithm>
#include <limits>

using namespace std;

class Food;
const int num_property = 4;
int k;
vector <int>min_nuts;
vector<Food*> food_array;

class Food {
public:
    vector<int> nutrients;
    int price;
    int index;

    bool operator > (const Food *food) const
    {
        return (price > food->price);
    }
};

int num = 0;
class Node {
public:
    Node *parent = NULL;
    Food *food = NULL;
    vector <int>left_nut_val;
    int stacked_cost = 0;
};


int min_cost_result = 500*20;
vector<int> min_foods_result_sorted;

stack <Node*> waiting_nodes;

Node *get_waiting_node() {
    if (waiting_nodes.empty()) {
        return new Node();
    } else {
        Node *node = waiting_nodes.top();
        waiting_nodes.pop();
        node->parent = NULL;
        node->food = NULL;
        node->stacked_cost = 0;
        return node;
    }
}
void add_waiting_node(Node *node) {
    waiting_nodes.push(node);
    node->parent = NULL;
    node->food = NULL;
    node->stacked_cost = 0;
}

void update_min_routine(Node *node) {
    Node *tmp_node = node;
    vector <int>foods_result;
    foods_result.push_back(tmp_node->food->index);
    while (tmp_node->parent) {
        tmp_node = tmp_node->parent;
        foods_result.push_back(tmp_node->food->index);
    }
    sort(foods_result.begin(), foods_result.end());

    min_cost_result = node->stacked_cost;
    min_foods_result_sorted = foods_result;
    //min_node = node;
}

void check_and_update_min_routine(Node *node) {
    if (node->stacked_cost < min_cost_result) {
        update_min_routine(node);
    } else if (node->stacked_cost == min_cost_result) {
        Node *tmp_node = node;
        vector <int>foods_result;
        foods_result.push_back(tmp_node->food->index);
        while (tmp_node->parent) {
            tmp_node = tmp_node->parent;
            foods_result.push_back(tmp_node->food->index);
        }
        sort(foods_result.begin(), foods_result.end());

        int f_size = foods_result.size();
        int o_f_size = min_foods_result_sorted.size();
        for (int i=0; i<f_size; i++) {
            if (i==o_f_size) return; // nothing...
            else if (min_foods_result_sorted[i] < foods_result[i]) return; // nothing...
            else if (min_foods_result_sorted[i] == foods_result[i]) {
                // continue
            } else {
                // update
                update_min_routine(node);
                return;
            }
        }
    } else {
        // nothing...
    }
}


void check_recursively(Node *node, vector<Food *> left) {

    // Food *food = node->food;



    // CUT if bigger than min_cost_result
    if (node->stacked_cost > min_cost_result) {
        add_waiting_node(node);
        return;
    }


    int left_nut_values_size = node->left_nut_val.size();
    bool all_negative_sign = true;
    for (int i=0; i<left_nut_values_size; i++) {
        if (node->left_nut_val[i] > 0) all_negative_sign = false;
    }
    if (all_negative_sign) {
        // update
        check_and_update_min_routine(node);
        add_waiting_node(node);
        return;
    }


    int left_size = left.size();
    for (int i=0; i<left_size; i++) {
        Node *next_node = get_waiting_node();
        next_node->parent = node;
        next_node->food = left[i];
        next_node->left_nut_val = node->left_nut_val;
        next_node->stacked_cost = node->stacked_cost + next_node->food->price;


//        int maxj = -1;
//        int maxVal = 0;
        for (int j=0; j<next_node->left_nut_val.size(); j++) {
            next_node->left_nut_val[j] -= next_node->food->nutrients[j];

//            if (maxj==-1 || maxVal < next_node->left_nut_val[j]) {
//                maxj = j;
//                maxVal = next_node->left_nut_val[j];
//            }
        }

        // left node update
//        Food *left_food = left[i];
        vector<Food*> next_left_food = left;
        next_left_food.erase(next_left_food.begin()+i);

        check_recursively(next_node, next_left_food);
    }
    add_waiting_node(node);
}

bool compareFood(Food* a, Food* b) { return (a->price < b->price); }

int main() {
    string inputPath = "diet.inp"; //diet
    string outputPath = "diet.out";
    ifstream infile(inputPath);
    ofstream outfile(outputPath);

    infile >> k;

    for (int i=0; i<num_property; i++) {
        int m = -1;
        infile >> m;
        min_nuts.push_back(m);
    }

    for (int i=0; i<k; i++) {
        vector <int> nuts;
        for (int j=0; j<num_property; j++) {
            int nut = -1;
            infile >> nut;
            nuts.push_back(nut);
        }
        int price = -1;
        infile >> price;
        Food *food = new Food();
        food->price = price;
        food->nutrients = nuts;
        food->index = i+1;

        food_array.push_back(food);
    }

    sort(food_array.begin(), food_array.end(), compareFood);



//    cout << "-------foods---------" << endl;
//    // print
//    for (Food *food: food_array) {
////        for (int nut: food->nutrients) {cout << nut << " ";}
//        cout << food->price << endl;
//        cout << endl;
//    }
//    cout << "--------------------" << endl;

    // ==========================================
    // ==========================================
    // ==========================================



    vector <Node*>nodes;
    for (int i=0; i<food_array.size(); i++) {
        Node *node = get_waiting_node();
        node->food = food_array[i];
        node->parent = NULL;
        node->left_nut_val = min_nuts;
        node->stacked_cost = node->food->price;
        for (int j=0; j<node->left_nut_val.size(); j++) {
            node->left_nut_val[j] -= node->food->nutrients[j];
        }
        nodes.push_back(node);
    }






    // trivial
    int node_size = nodes.size();
    for (int i=0; i<node_size; i++) {
        Node *node = nodes[i];
        vector <Food *>left_foods = food_array;
        left_foods.erase(left_foods.begin()+i);

        // really trivial!!
        check_recursively(node, left_foods);
    }

//    cout << "------------------" << endl;
//    cout << min_cost_result << endl;
    int size = min_foods_result_sorted.size();
    for (int i=0; i<size; i++) {
        int index = min_foods_result_sorted[i];
//        cout << index << " ";

        if (i!=min_foods_result_sorted.size()-1) {
//            cout << index << " ";
            outfile << index << " ";
        } else {
//            cout << index;
            outfile << index;
        }
    }
//    cout << endl;
//    cout << "------------------" << endl;






    infile.close();
    outfile.close();

    return 0;
}
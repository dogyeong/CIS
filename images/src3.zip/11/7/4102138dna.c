#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int** arr;

void reverseString(char* s) {
  int i;
  int size = strlen(s);
  char temp;

  for (i = 0;i<size/2; i++) {
    temp = s[i];
    s[i] = s[(size-1)-i];
    s[(size-1)-i] = temp;
  }
}

int max_num(int a, int b)
{
    return a >= b ? a:b ;
}

void recur_arr(char* a, char* b, char* result,char** pfront_result, int i, int j, int k,int max_result)
{

    int num1 = arr[i-1][j-1];
    int num2 = arr[i-1][j-2];
    int num3 = arr[i-2][j-1];
    int num4 = arr[i-2][j-2];
    int num5 = max_result-k;

    if(k==max_result) {

        reverseString(result);

        if(strcmp(*pfront_result,result)>1){
                    strcpy(*pfront_result,result);
        }
        reverseString(result);
    }

    if(a[j-1]==b[i-1] && num5 == num1){
        result[k] = a[j-1];
        recur_arr(a,b,result,pfront_result,i-1,j-1,k+1,max_result);
    }
    if(a[j-2]==b[i-1] && num5 == num2){
        result[k] = a[j-2];
        recur_arr(a,b,result,pfront_result,i-1,j-2,k+1,max_result);
    }
    if(a[j-1]==b[i-2] && num5 == num3){
        result[k] = a[j-1];
        recur_arr(a,b,result,pfront_result,i-2,j-1,k+1,max_result);
    }
    if(a[j-2]==b[i-2] && num5 == num4){
        result[k] = a[j-2];
        recur_arr(a,b,result,pfront_result,i-2,j-2,k+1,max_result);
    }
}

int compare(char* a, char* b,int i, int j)
{
    if (i<=3) return 1;
    else if(j<=3) return 1;
    else if((a[j-2]==b[i-2] || a[j-1]==b[i-2] || a[j-2]==b[i-1] ||a[j-1]==b[i-1])||(arr[i-2][j-2]==0 &&arr[i-2][j-1]==0 &&arr[i-1][j-2]==0 &&arr[i-1][j-1]==0) ){
        return 1;
    }
    else return 0;
}

int max_arr(int i, int j){
    int result = 0;
    int num1 = arr[i-1][j-1];
    int num2 = arr[i-1][j-2];
    int num3 = arr[i-2][j-1];
    int num4 = arr[i-2][j-2];

    num1 = max_num(num1,num2);
    num3 = max_num(num3,num4);
    result = max_num(num1,num3);

    return result;
}

int main()
{
    int i,j;
    int a_len;
    int b_len;
    int max_result=0;
    char a[1002];
    char b[1002];
    char* front_result;
    char* result;

    FILE* fp1 = fopen("dna.inp", "rt");
    FILE* fp2 = fopen("dna.out", "wt");

    if(fp1==NULL){
        puts("File calling failed");
        return -1;
    }
    if(fp2==NULL){
        puts("File calling failed");
        return -1;
    }

    fscanf(fp1,"%s",a);
    fscanf(fp1,"%s",b);

    a_len = strlen(a);
    b_len = strlen(b);

    for(i=a_len+1;i>1;i--) a[i]=a[i-2];
    for(i=b_len+1;i>1;i--) b[i]=b[i-2];

    a_len +=2;
    b_len +=2;
    a[0]='1';
    a[1]='2';
    b[0]='3';
    b[1]='4';

    arr = (int**)calloc(b_len,sizeof(int*));
    for(i=0;i<b_len;i++){
        arr[i] = (int*)calloc (a_len,sizeof(int));
    }

    for(i=2;i<b_len;i++){
        for(j=2;j<a_len;j++){
            if(a[j]==b[i]&&compare(a,b,i,j)){
                arr[i][j] = max_arr(i,j) + 1;
                max_result = arr[i][j] > max_result ? arr[i][j] : max_result;
            }
        }
    }

    front_result = (char*)calloc(max_result+1,sizeof(char));
    result = (char*)calloc(max_result+1,sizeof(char));

	char** pfront_result = &front_result;
    for(i=0;i<max_result;i++){
        front_result[i] = 'z';
    }


    for(i=0;i<b_len;i++){
        for(j=0;j<a_len;j++){
            if(a[j]==b[i] && arr[i][j]==max_result){

              //  printf("%d %d\n",i,j);
                result[0] = a[j];
                recur_arr(a,b,result,pfront_result,i,j,1,max_result);
            }
        }
    }

/*
    for(i=2;i<b_len;i++){
        for(j=2;j<a_len;j++){
            printf("%d ",arr[i][j]);
        }
        printf("\n");
    }*/
    //printf("a: %s\nb: %s\n",a,b);
  //  printf("LSS_result : %s\n",front_result);
   // printf("max_result : %d\n",max_result);
  //  for(i=0; i<max_result; i++) fprintf(fp2,"%c",front_result[i]);
  //  fprintf(fp2,"\n");
	printf("%s\n",*pfront_result);
    fprintf(fp2,"%s",*pfront_result);

    free(arr);
    free(result);
    free(front_result);
    fclose(fp1);
    fclose(fp2);
    return 0;
}

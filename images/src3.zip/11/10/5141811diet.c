#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int ea = 0;
int min[4];
int**ingre;
int sum[4] = {0,0,0,0};
int result=0;
int* cur_arr;
int* result_arr;
int check=0;

void copy_paste()
{
    int i;
    for(i=0;i<ea;i++){
        result_arr[i] = -1;
    }
    for(i=0;i<ea;i++){
        if(cur_arr[i]==-1) break;
        else result_arr[i] = cur_arr[i];
    }
}

int file_check(FILE* fp)
{
    if(fp==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    else return 0;
}

void diet(int start,int temp)
{
    int i,j;
    for(i=start;i<ea;i++){
        for(j=0;j<4;j++) sum[j] += ingre[i][j];
        temp+=ingre[i][4];
        cur_arr[check++] = i;
        if(sum[0]>=min[0] && sum[1]>=min[1] && sum[2]>=min[2] && sum[3]>=min[3]){
            if(temp<result){
                copy_paste();
                result = temp;
            }
        }
        else    diet(i+1,temp);
        for(j=0;j<4;j++) sum[j] -= ingre[i][j];
        temp-=ingre[i][4];
        cur_arr[--check] = -1;
    }
}


int main()
{
    int i,j;
    FILE* fp1 = fopen("diet.inp", "rt");
    FILE* fp2 = fopen("diet.out", "wt");
    file_check(fp1);
    file_check(fp2);

    fscanf(fp1,"%d", &ea);

    for(i=0; i<4; i++) fscanf(fp1,"%d",&min[i]);


    ingre = (int**)calloc(ea,sizeof(int*));
    for(i=0;i<ea;i++) ingre[i] = (int*)calloc(5,sizeof(int));
    for(i=0;i<ea;i++){
        for(j=0;j<5;j++){
            fscanf(fp1,"%d",&ingre[i][j]);
        }
    }
    cur_arr = (int*)calloc(ea,sizeof(int));
    result_arr = (int*)calloc(ea,sizeof(int));

    for(i=0;i<ea;i++)   cur_arr[i] = -1;
    for(i=0;i<ea;i++)   result+= ingre[i][4];

    diet(0,0);

    for(i=0; i<ea; i++){
        if(result_arr[i]==-1) break;
        else fprintf(fp2,"%d ",result_arr[i]+1);
    }

    fclose(fp1);
    fclose(fp2);
    return 0;
}

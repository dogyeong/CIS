#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main()
{
    char sentence_no[3];
    int real_sentence_no;
    char sentence[10000];
    char sentence_re[10000];
    int len,len2;
    int i,j,k,l,m;
    int check=0;


    FILE* fp1 = fopen("palin.inp", "rt");
    FILE* fp2 = fopen("palin.out", "wt");
    if(fp1==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    if(fp2==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    fgets(sentence_no,10,fp1);
    //real_sentence_no = sentence_no[0] - 0x30;
    real_sentence_no = atoi(sentence_no); // ���� ����

    printf("������ ����: %d\n", real_sentence_no);

    for(i=0; i<real_sentence_no; i++)
    {
        fgets(sentence, 10000, fp1);  //���� �ҷ�����

        len = strlen(sentence)-1; // ���ڿ����� ũ��� \n�� �� ũ��� -1��
        len2 = len-1;
        sentence[len] = NULL; // \n�� NULL�� ���� �������ڿ��� ����
//        printf("%d:%s, %d\n",i+1,sentence,len);
        for(j=0; j<len/2; j++){
            if(sentence[j] == sentence[len-1-j]){
               // printf("%d",j);
                if(j!=(len/2)-1){
                    continue;
                }
                else{
                    printf("ȸ����\n");
                    fputc('1',fp2);
                    fputc('\n',fp2);

                }
            }
            else {
                    for(k=0; k<len; k++){
                        if(check==1){ // ����ȸ���̸� �ٸ� ���� �˻�
                            check=0;
                            break;
                        }
                        strcpy(sentence_re,sentence);
                        for(l=k; l<len; l++){
                            sentence_re[l] = sentence_re[l+1];
                        }
                        //printf("%s\n",sentence_re);
                        for(m=0; m<(len-1)/2; m++){
                            if(sentence_re[m] == sentence_re[(len-1)-1-m]){
                                if(m!=((len-1)/2-1)){
                                    continue;
                                }
                                else{
                                    printf("����ȸ����\n");
                                    check=1; //����ȸ��
                                    fputc('2',fp2);
                                    fputc('\n',fp2);
                                    break;
                                }
                            }
                            else{
                                check=2;//ȸ����, ����ȸ���� �ƴ�
                                break;
                            }
                        }



                    }
                    if(check==2){
                        printf("ȸ����, ����ȸ���� �ƴ�\n");
                        fputc('3',fp2);
                        fputc('\n',fp2);
                    }
                    break;
            }
        }


    }


/*
    fgets(sentence, 100, fp1);
    sentence_len = strlen(sentence);
    sentence[sentence_len-1] = NULL;
    printf("2:%s\n",sentence);

    fgets(sentence, 100, fp1);
    sentence_len = strlen(sentence);
    sentence[sentence_len-1] = NULL;
    printf("3:%s\n",sentence);
*/

    fclose(fp1);
    fclose(fp2);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int battery(int station, int *point, int distance, int start){
    int i;
    int j;
    int check=1;
    int result;
    int **set = (int**)malloc(sizeof(int*)*(station));
    int k,l;
    for(int i=0; i<station; i++){
        set[i] = (int*)malloc (sizeof(int) * station);
    }



    for(i=0; i<2*station; i+=2){
        for(j=0; j<2*station; j+=2){
           set[i/2][j/2]= (int)sqrt(pow(point[i]-point[j],2) + pow(point[i+1] - point[j+1],2));
        }
    }

    distance= (distance + start)/2;
    if((start == distance) && start!=0){

        printf("%d\n",start);
        return start;
    }

   // printf("distance: %d, start: %d\n",distance, start);

    for(i=0; i<station; i++){
        for(j=0; j<station; j++){
            if((i==j) || (set[i][j]==0)){
                continue;
            }
            else if((j==(station-1)) && (set[i][j] > distance) ) {
                //for(k=0; k<station; k++){
                  //  for(l=0; l<station; l++){
                    //    if(k!=l && set[k][l]==0)
                      //      printf("arr[%d][%d] = %d, arr[%d][%d] = %d\n",k,l,set[k][l],l,k,set[l][k]);
              //      }
              //  }
                free(set);
                return 1 * battery(station, point, 2*distance, distance);
            }
            else if(set[i][j]<=distance){
                set[j][i]=0; //���� ���� 0���� ����� ����Ҽ��ְ� �����.
                break;
            }
            else {
                    continue;
            }
        }
    }
    free(set);
    return 1 * battery(station,point, distance ,start);
}



int main()
{

    int station, depart;
    int distance;
    int point[2004];  // point x , y
    int i,j,k;
    int min;
    int sum=0;
    int result;

    FILE* fp1 = fopen("battery.inp", "rt");
    FILE* fp2 = fopen("battery.out", "wt");

    if(fp1==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    if(fp2==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    fscanf(fp1,"%d %d", &station, &depart); // ������ ���� ������ ��ǥ �ҷ�����

    for(i=0; i<2*station; i+=2){ // point �ҷ�����
        fscanf(fp1, "%d %d", &point[i], &point[i+1]);
    }


    point[i] = 0; // start point x
    point[i+1]= 0; // start point y

    i+=2;

    point[i] = depart;
    point[i+1] = depart;

    station+=2;
    distance = (int)sqrt(pow(depart,2)+pow(depart,2)); //start���� depart������ �Ÿ�


    min = battery(station, point, distance, 0);
    fprintf(fp2,"%d",min+2);
    printf("min distance: %d\n",min);



    printf("distance: %d\n", distance);
    printf("%d %d\n",station, depart);

    fclose(fp1);
    fclose(fp2);
    return 0;
}


/*
int battery(int station, int *point, int distance, int start){
    int i;
    int j;
    int check=1;
    int result;
    int *set = (int*)malloc(sizeof(int)*(station*station));
    int k,l;



    for(i=0; i<2*station; i+=2){
        for(j=0; j<2*station; j+=2){
           set[((i/2)*station)+(j/2)]= (int)sqrt(pow(point[i]-point[j],2) + pow(point[i+1] - point[j+1],2));
        }
    }

    distance= (distance + start)/2;
    if((start == distance) && start!=0){

        printf("%d\n",start);
        return start;
    }

    printf("distance: %d, start: %d\n",distance, start);

    for(i=0; i<station; i++){
        for(j=0; j<station; j++){
            if((i==j) || (set[((i)*station)+(j)]==0)) continue;
            else if((j==(station-1)) && (set[((i)*station)+(j)] > distance)) {
                for(k=0; k<station; k++){
                    for(l=0; l<station; l++){
                        if(k!=l && set[k*station+l]==0)
                            printf("arr[%d][%d] = %d, arr[%d][%d] = %d\n",k,l,set[k*station+l],l,k,set[l*station+k]);
                    }
                }
                free(set);
                return 1 * battery(station, point, 2*distance, distance);
            }
            else if(set[((i)*station)+(j)]<=distance){
                set[((j)*station)+(i)]=0; //���� ���� 0���� ����� ����Ҽ��ְ� �����.
                break;
            }
            else continue;
        }
    }
    free(set);
    return 1 * battery(station,point, distance ,start);


}*/

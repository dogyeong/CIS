#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int battery(int station, int (*point)[2], int distance){
    int i;
    int j;
    int k;

    int result;
    distance/=2;

    for(k=distance; k>1; k/=2){
        for(i=0; i<=2*station; i+=2){
            for(j=0; j<=2*station; j+=2){
                    if(i==j) continue;
                    result= (int)sqrt(pow(point[i]-point[j],2) + pow(point[i+1] - point[j+1],2));
                    if(result<=k){
                        break;
                    }
                    else{
                        if(j==(2*station)){
                            return k;
                        }
                    }
            }
        }
    }
    return 10000;
}

int battery2(int station, int *point, int min){
    int i;
    int j;
    int k;

    double result;
    printf("hello world!\n");

    for(k=(min*2); k>min; k--){
        for(i=0; i<=2*station; i+=2){
            for(j=0; j<=2*station; j+=2){
                    if(i==j) continue;

                    result= sqrt(pow(point[i]-point[j],2) + pow(point[i+1] - point[j+1],2));
                    /*if(k==117 ) {
                            printf("%d: %d, %d, %d, %d, result: %d\n", i,point[i],point[i+1],point[j],point[j+1],result);
                            //printf("%d\n",result);
                    }*/
                    if(result<=k){
                        break;
                    }
                    else{
                        if(j==(2*station)){
                            return k;
                        }
                    }
            }
        }
    }
    return 10000;
}

int main()
{

    int station, depart;
    int distance;
    int point[1001][2];  // point x , y
    int i,j,k;
    int min;
    int value;
    double result;
    int check=0;

    point[0][0] = 0; // start point x
    point[0][1] = 0; // start point y


    FILE* fp1 = fopen("battery.inp", "rt");
    FILE* fp2 = fopen("battery.out", "wt");

    if(fp1==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    if(fp2==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }

    fscanf(fp1,"%d %d", &station, &depart); // ������ ���� ������ ��ǥ �ҷ�����

    point[1][0] = depart;
    point[1][1] = depart;

    for(i=0; i<station; i++){ // point �ҷ�����
        fscanf(fp1, "%d %d", &point[i+2][0], &point[i+2][1]);
    }
    distance = (int)sqrt(pow(depart,2)+pow(depart,2)); //start���� depart������ �Ÿ�
    distance/=2;

    for(k=distance; k>1; k/=2){
        if(check==1) break;
        for(i=0; i<=station; i++){
            if(check==1) break;
            for(j=0; j<=station; j++){
                    if(i==j) continue;

                    result= (int)sqrt(pow(point[i][0]-point[j][0],2) + pow(point[i][1]-point[j][1],2));

                    if(result<=k){
                        break;
                    }
                    else{
                        if(j==(station)){
                            min= k;
                            check=1;
                            break;
                        }
                    }
            }
        }
    }
    //min = battery(station, &point, distance);
    //value = battery2(station, &point, min);

    check=0;



    for(k=min*2; k>min; k--){
        if(check==1) break;
        for(i=0; i<=station; i++){
            if(check==1) break;
            for(j=0; j<=station; j++){
                    if(i==j) continue;

                    result= sqrt( pow(point[i][0]-point[j][0],2) + pow(point[i][1]-point[j][1],2) );

                    if(result<=k){
                        break;
                    }
                    else{
                        if(j==(station)){
                            value= k;
                            check=1;
                            break;
                        }
                    }
            }
        }
    }





    printf("min distance: %d\n",min);
    printf("value distance: %d\n",value);
    fprintf(fp2,"%d",value+1);

    printf("distance: %d\n", distance);
    printf("%d %d\n",station, depart);

    fclose(fp1);
    fclose(fp2);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int battery(int station, int *point, int distance){
    int i;
    int j;
    int k;

    int result;
    distance/=2;

    for(k=distance; k>1; k/=2){
        for(i=0; i<=2*station; i+=2){
            for(j=0; j<=2*station; j+=2){
                    if(i==j) continue;
                    result= (int)sqrt(pow(point[i]-point[j],2) + pow(point[i+1] - point[j+1],2));
                    if(result<=k){
                        break;
                    }
                    else{
                        if(j==(2*station)){
                            return k;
                        }
                    }
            }
        }
    }
    return 10000;
}

int battery2(int station, int *point, int min){
    int i;
    int j;
    int k;

    double result;
    printf("hello world!\n");

    for(k=(min*2); k>min; k--){
        for(i=0; i<=2*station; i+=2){
            for(j=0; j<=2*station; j+=2){
                    if(i==j) continue;

                    result= sqrt(pow(point[i]-point[j],2) + pow(point[i+1] - point[j+1],2));
                    /*if(k==117 ) {
                            printf("%d: %d, %d, %d, %d, result: %d\n", i,point[i],point[i+1],point[j],point[j+1],result);
                            //printf("%d\n",result);
                    }*/
                    if(result<=k){
                        break;
                    }
                    else{
                        if(j==(2*station)){
                            return k;
                        }
                    }
            }
        }
    }
    return 10000;
}

int main()
{
    int station, depart;
    int distance;
    int point[1001][2];  // point x , y
    int i;
    int min;
    int value;
    point[0][0] = 0; // start point x
    point[0][1] = 0; // start point y


    FILE* fp1 = fopen("battery.inp", "rt");
    FILE* fp2 = fopen("battery.out", "wt");

    if(fp1==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    if(fp2==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }

    fscanf(fp1,"%d %d", &station, &depart); // ������ ���� ������ ��ǥ �ҷ�����

    for(i=0; i<station; i++){ // point �ҷ�����
        fscanf(fp1, "%d %d", &point[i+1][0], &point[i+1][1]);
    }
    distance = (int)sqrt(pow(depart,2)+pow(depart,2)); //start���� depart������ �Ÿ�

    min = battery(station, &point, distance);
    value = battery2(station, &point, min);
    printf("min distance: %d\n",min);
    printf("value distance: %d\n",value);
    fprintf(fp2,"%d",value+1);

    printf("distance: %d\n", distance);
    printf("%d %d\n",station, depart);

    fclose(fp1);
    fclose(fp2);
    return 0;
}

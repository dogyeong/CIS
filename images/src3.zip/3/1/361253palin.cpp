/#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;
int palin(string& word){

    for(int i=0 ; i<word.size()/2 ; i++){
        if(word.at(i) != word.at(word.length()-i-1)){
            return 2;
           }
    }
    return 1;
}

int sudopalin(string& word){

    int i;
    string subword1;
    string subword2;

    for(i=0 ; i<word.length()/2 ; i++){
        if(word.at(i) != word.at(word.length()-i-1)){
            break;
           }
    }

    subword1 = word.substr(i,word.length()-i*2-1);
    subword2 = word.substr(i+1,word.length()-i*2-1);

    if(palin(subword1)==1){
        return 2;
    }
    if(palin(subword2)==1){
        return 2;
    }
    return 3;
}





int main()
{
    ifstream ifs("palin.inp");
    ofstream ofs("palin.out");
    vector<string> word;
    string s;
    int amount;

    ifs >> amount;
    for(int i=0 ; i<amount ; i++){
        ifs >> s;
        word.push_back(s);
    }

    for(int i=0 ; i<amount ; i++){
        int j = palin(word.at(i));
        if(j==1){
            ofs << j << endl;
        }
        else{
            j= sudopalin(word.at(i));
            ofs << j << endl;
        }
    }

    ifs.close();
    ofs.close();

    return 0;

}


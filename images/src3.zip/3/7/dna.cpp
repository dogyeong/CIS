#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <tuple>

using namespace std;
string findAnsr(int val, int x, int y, string str1, string str2, int** LCS){
    string temp;
    int flag;
    temp.push_back(str1.at(x-2));
    while(val>1){
        int mx=0;
        for(int i=x-1;i>=x-2;i--){
            for(int j=y-1;j>=y-2;j--){
                if(mx < LCS[i][j])
                    mx=LCS[i][j];
            }
        }
        vector<tuple<char,int,int>> tp;
        for(int i=x-1;i>=x-2;i--){
            for(int j=y-1;j>=y-2;j--){
                if(LCS[i][j] == mx && str1.at(i-2)==str2.at(j-2)){
                    tp.push_back(make_tuple(str1.at(i-2),i,j));
                }
            }
        }

        if(tp.size()>1){
            if(get<0>(tp.at(0))>get<0>(tp.at(1))){
                temp.push_back(get<0>(tp.at(1)));
                x=get<1>(tp.at(1));
                y=get<2>(tp.at(1));
                val--;
            }
            else{
                temp.push_back(get<0>(tp.at(0)));
                x=get<1>(tp.at(0));
                y=get<2>(tp.at(0));
                val--;
            }
        }
        else{
            temp.push_back(get<0>(tp.at(0)));
            x=get<1>(tp.at(0));
            y=get<2>(tp.at(0));
            val--;
       }

       // cout << "val = " <<val <<endl;
       // cout << "str: " << temp <<endl;
       // cout << "a, b : " << x-2 << "," << y-2 <<endl;

    }
    reverse(temp.begin(),temp.end());
    //cout << "ansr : " <<temp << endl;
    return temp;
}

string LCS(string s1, string s2){

    int height = s1.length()+2, width = s2.length()+2;
    int **LCS;
    LCS = (int**) malloc ( sizeof(int*) * height );
    for(int i=0; i<height; i++){
        LCS[i] = (int*) malloc ( sizeof(int) * width );
    }

    for(int i=0;i<s1.length()+2;++i)
        for(int j=0;j<s2.length()+2;++j)
            LCS[i][j] =0;


    string str1 = s1;
    string str2 = s2;
    string ansr;

    for(int i = 2; i <= str1.length()+1; i++){
        for(int j = 2; j <= str2.length()+1; j++){
            if(str1.at(i-2) == str2.at(j-2)){
                int mx=0;
                for(int a=i-2;a<i;a++)
                    for(int b=j-2;b<j;b++)
                       if(mx < LCS[a][b])
                            mx=LCS[a][b];
                LCS[i][j] = mx+1;
    //            cout <<  LCS[i][j]  << " ";
            }
            else{
    //         cout << "0 ";
            }
        }
      //  cout <<endl;
    }



    int val=0,x,y=0;
    for(int i = str1.length()+1; i >=2; i--){
        for(int j=str2.length()+1; j>=2; j--){
            if(val<LCS[i][j]){
                val  = LCS[i][j];
            }
        }
    }
    vector<tuple<int,int>> cord;
    for(int i = str1.length()+1; i >=2; i--){
        for(int j=str2.length()+1; j>=2; j--){
            if(val==LCS[i][j] && str1.at(i-2)==str2.at(j-2) ){
                cord.push_back(make_tuple(i,j));
            }
        }
    }
    vector<string> ansrs;
    for(int i=0;i<cord.size();++i){
        ansrs.push_back( findAnsr(val,get<0>(cord.at(i)),get<1>(cord.at(i)),str1,str2,LCS) );
    }


    sort(ansrs.begin(),ansrs.end());



    return ansrs.at(0);
}

int main()
{
    string s1, s2;
    ifstream ifs("dna.inp");
    ifs >> s1;
    ifs >> s2;
    ifs.close();

    s1= LCS(s2,s1);
    ofstream ofs("dna.out");
    ofs << s1;

    return 0;
}

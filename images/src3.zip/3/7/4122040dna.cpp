#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>


using namespace std;


string LCS(string s1, string s2){

    int height = s1.length()+2, width = s2.length()+2;
    int **LCS;
    LCS = (int**) malloc ( sizeof(int*) * height );
    for(int i=0; i<height; i++){
        LCS[i] = (int*) malloc ( sizeof(int) * width );
    }

    for(int i=0;i<s1.length()+2;++i)
        for(int j=0;j<s2.length()+2;++j)
            LCS[i][j] =0;


    string str1 = s1;
    string str2 = s2;
    string ansr;

    for(int i = 2; i <= str1.length()+1; i++){
        for(int j = 2; j <= str2.length()+1; j++){
            if(str1.at(i-2) == str2.at(j-2)){
                int mx=0;
                for(int a=i-2;a<i;a++)
                    for(int b=j-2;b<j;b++)
                       if(mx < LCS[a][b])
                            mx=LCS[a][b];
                LCS[i][j] = mx+1;
          //      cout <<  LCS[i][j]  << " ";
            }
            else{
            //    cout << "0 ";
            }
        }
       // cout <<endl;
    }



    int val=0,x,y=0;
    for(int i = str1.length()+1; i >=2; i--){
        for(int j=str2.length()+1; j>=2; j--){
            if(val<LCS[i][j]){
                val  = LCS[i][j];
            }
        }
    }
    for(int i = str1.length()+1; i >=2; i--){
        for(int j=str2.length()+1; j>=2; j--){
            if(val==LCS[i][j] && str1.at(i-2)==str2.at(j-2) ){
                x = i;
                y = j;
                break;
            }
        }
    }
    //cout << "sizee : "<<str1.length()-1 << " " << str2.length()-1<<endl;
    //cout << "start : "<<x-2<<" " <<y-2<<endl;
    string temp;
    int flag;
    temp.push_back(str1.at(x-2));
    while(val>1){
        int mx=0;
        for(int i=x-1;i>=x-2;i--){
            for(int j=y-1;j>=y-2;j--){
                if(mx < LCS[i][j])
                    mx=LCS[i][j];
            }
        }
        flag=0;
        for(int i=x-1;i>=x-2;i--){
            for(int j=y-1;j>=y-2;j--){
                if(LCS[i][j] == mx && str1.at(i-2)==str2.at(j-2)){
                    temp.push_back(str1.at(i-2));
                    x=i;
                    y=j;
                    val--;
                    flag=1;
                    break;
                }
            }
            if(flag==1)
                break;
        }
       // cout << "val = " <<val <<endl;
       // cout << "str: " << temp <<endl;
       // cout << "a, b : " << x-2 << "," << y-2 <<endl;

    }
    reverse(temp.begin(),temp.end());
    //cout << "ansr : " <<temp << endl;
    return temp;


}








int main()
{
    string s1, s2;
    ifstream ifs("dna.inp");
    ifs >> s1;
    ifs >> s2;
    ifs.close();

    s1 = LCS(s2,s1);
    ofstream ofs("dna.out");
    ofs << s1;

    return 0;
}

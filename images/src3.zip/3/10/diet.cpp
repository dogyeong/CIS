#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <math.h>

using namespace std;
int sumI[5]={0,0,0,0,0};
int stand[4];
int minCost=1000000;
vector<int> what;
vector<int> awsr;
bool comp(){
    for(int i=0;i<4;++i){

        if(sumI[i]<stand[i]){
            return false;
        }
    }
    return true;
}
void clearSumI(){
    for(int i=0;i<5;++i)
        sumI[i]=0;
}
void findMin(vector<vector<int>> ingred, int num)
{
    int sNum = pow(2, num);
    int counter, i;

    for(counter = 0; counter < sNum; counter++)
    {

        for(int i = 0; i < num; i++)
        {

            if(counter & (1 << i)){
                what.push_back(ingred.at(i).at(5));
                for(int j=0;j<5;++j){
                    sumI[j]+=ingred.at(i).at(j);
                }

            }
        }
        if(comp()){
            if(sumI[4]<minCost){
                minCost = sumI[4];
                awsr=what;
            }
        }

        what.clear();
        clearSumI();
    }
    sort(awsr.begin(),awsr.end());

}

bool compare(vector<int> a, vector<int> b){
    return a.at(4) < b.at(4);
}

void print(vector<vector<int>> ingred, int num){
    for(int i=0;i<num;++i){
        for(int j=0;j<6;++j){
            cout << ingred.at(i).at(j) <<" ";
        }
        cout << endl;
    }
}


int main()
{

    int num;
    int temp;

    vector<vector<int>> ingred;
    vector<int> vTemp;
    ifstream ifs("diet.inp");
    ofstream ofs("diet.out");
    ifs >> num;

    for(int i=0;i<4;++i){
        ifs >> temp;
        stand[i]=temp;
    }
    for(int i=0;i<num;++i){
        for(int j=0;j<5;++j){
            ifs >> temp;
            vTemp.push_back(temp);
        }
        vTemp.push_back(i+1);
        ingred.push_back(vTemp);
        vTemp.clear();
    }

    sort(ingred.begin(), ingred.end(), compare);
    findMin(ingred,num);

    for(int i=0;i<awsr.size();++i){
        ofs << awsr.at(i) << " " ;
    }

    ofs.close();
    ifs.close();

    return 0;
}

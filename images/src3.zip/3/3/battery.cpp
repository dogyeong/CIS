#include <iostream>
#include <fstream>
#include <vector>
#include <tuple>
#include <cmath>
#include <algorithm>
#include <queue>
#include <time.h>

using namespace std;

double dist(tuple<int,int> i, tuple<int,int> j){
    return sqrt(pow(get<0>(i)-get<0>(j),2)+pow(get<1>(i)-get<1>(j),2));
}

bool canArrive(int weight, vector<tuple<int,int>> points, int dest){

    queue<tuple<int,int>> q;
    q.push(make_tuple(0,0));
    while(!q.empty()){
        for(int i= points.size()-1; 0<=i ; --i){
            if(get<0>(q.front())- weight <= get<0>(points.at(i)) &&  get<0>(points.at(i)) <= get<0>(q.front()) + weight){
                if(get<1>(q.front())- weight <= get<1>(points.at(i)) &&  get<1>(points.at(i)) <= get<1>(q.front()) + weight){
                    if( dist(q.front(),points.at(i)) <= (int)weight){
                        if(points.at(i) == make_tuple(dest,dest)){
                            return true;
                        }
                        q.push(points.at(i));
                        points.erase(points.begin()+i);


                    }
                }
            }


        }
        q.pop();
    }
    return false;
}


double findMinWeight(vector<tuple<int,int>> points, int dest){
    double left,mid,right;

    left = 0;
    right = sqrt(2)*dest;

    while(left  <= right){
        mid = left + (right - left) / 2;
        if(canArrive(mid,points,dest)){
            if(!canArrive(mid-1,points,dest))
               return mid;
            right = mid - 1;
        }
        else{
            if(canArrive(mid+1,points,dest))
               return mid+1;
            left = mid + 1;
        }
    }
    return -1;
}

int main()
{
    //time_t start, end;
    //double result;
    //start = clock();
    ifstream ifs("battery.inp");
    ofstream ofs("battery.out");

    int num, dest;
    int x,y;
    vector<tuple<int,int>> points;

    ifs >> num >> dest;

    for(int i=0 ; i < num ; ++i){
        ifs >> x >> y;
        points.push_back(make_tuple(x,y));
    }
    ifs.close();


    points.push_back(make_tuple(dest,dest));

    int minWeight = int(findMinWeight(points,dest));
    ofs << minWeight;
    ofs.close();

    //end = clock();
    //result = (double)(end - start);
    //printf("clock : %g\n", result);
    //cout << "ansr : " <<minWeight;
    return 0;
}

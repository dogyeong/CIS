#include <iostream>
#include <fstream>
#include <vector>
#include <tuple>
#include <cmath>
#include <algorithm>
#include <queue>


using namespace std;

double dist(tuple<int,int> i, tuple<int,int> j){
    return sqrt(pow(get<0>(i)-get<0>(j),2)+pow(get<1>(i)-get<1>(j),2));
}
bool canArrive(int weight, vector<tuple<int,int>> points, int dest){

    queue<tuple<int,int>> q;
    q.push(make_tuple(0,0));
    while(!q.empty()){
        for(int i=0; i< points.size() ; ++i){
            if(get<0>(q.front())- weight <= get<0>(points.at(i)) &&  get<0>(points.at(i)) <= get<0>(q.front()) + weight){
                if(get<1>(q.front())- weight <= get<1>(points.at(i)) &&  get<1>(points.at(i)) <= get<1>(q.front()) + weight){
                    if( dist(q.front(),points.at(i)) <= (double)weight){
                        if(points.at(i) == make_tuple(dest,dest)){

                            return true;
                        }
                        q.push(points.at(i));
                        points.erase(points.begin()+i);
                    }
                }
            }
        }
        q.pop();
    }

    return false;
}


int findMinWeight(vector<tuple<int,int>> points, int dest){
    int left,mid,right;
    left = 0;
    right = sqrt(2)*dest;

    while(left +20 <= right){
        mid = left + (right - left) / 2;
        if(canArrive(mid,points,dest)){
            right = mid - 1;
        }
        else{
            left = mid + 1;
        }
    }
    for(int i = right ; right >= left; --right){
        if(canArrive(right,points,dest)==true && canArrive(right-1,points,dest)==false){
            return right;
        }
    }
}

int main()
{
    ifstream ifs("battery.inp");
    ofstream ofs("battery.out");

    int num, dest;
    int x,y;
    vector<tuple<int,int>> points;

    ifs >> num >> dest;

    for(int i=0 ; i < num ; ++i){
        ifs >> x >> y;
        points.push_back(make_tuple(x,y));
    }
    ifs.close();

    sort(points.begin(),points.end());
    points.push_back(make_tuple(dest,dest));

    int minWeight = findMinWeight(points,dest);

    ofs << minWeight;
    ofs.close();
    return 0;
}

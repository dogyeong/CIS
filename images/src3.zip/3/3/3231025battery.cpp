#include <iostream>
#include <fstream>
#include <vector>
#include <tuple>
#include <cmath>
#include <algorithm>
#include <queue>


using namespace std;

double dist(tuple<double,double> i, tuple<double,double> j){
    return sqrt(pow(get<0>(i)-get<0>(j),2)+pow(get<1>(i)-get<1>(j),2));
}
bool canArrive(double weight, vector<tuple<double,double>> podoubles, double dest){

    queue<tuple<double,double>> q;
    q.push(make_tuple(0,0));
    while(!q.empty()){
        for(int i=0; i< podoubles.size() ; ++i){
            if( dist(q.front(),podoubles.at(i)) <= weight){
                if(podoubles.at(i) == make_tuple(dest,dest)){
                    return true;
                }
                q.push(podoubles.at(i));
                podoubles.erase(podoubles.begin()+i);
            }
        }
        q.pop();
    }
    return false;
}


double findMinWeight(vector<tuple<double,double>> podoubles, double dest){
    double left,mid,right;
    left = 0;
    right = sqrt(2)*dest;

    while(left  <= right){
        mid = left + (right - left) / 2;
        if(canArrive(mid,podoubles,dest)){
            if(!canArrive(mid-1,podoubles,dest))
               return mid;
            right = mid - 1;
        }
        else{
            left = mid + 1;
        }
    }
}

int main()
{
    ifstream ifs("battery.inp");
    ofstream ofs("battery.out");

    double num, dest;
    double x,y;
    vector<tuple<double,double>> podoubles;

    ifs >> num >> dest;

    for(double i=0 ; i < num ; ++i){
        ifs >> x >> y;
        podoubles.push_back(make_tuple(x,y));
    }
    ifs.close();

    sort(podoubles.begin(),podoubles.end());
    podoubles.push_back(make_tuple(dest,dest));

    double minWeight = findMinWeight(podoubles,dest);


    ofs << minWeight;
    ofs.close();
    return 0;
}

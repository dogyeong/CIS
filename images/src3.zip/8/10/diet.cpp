// author: SungYun Jo, @extJo at github
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

struct Ingredient {
  int protein;
  int fat;
  int carbohydrate;
  int vitamin;
  int price;
};

int Number, prevSum;
int *selected, minIngredient[4];
vector<int> result;
Ingredient s, *list;

void parseInputFile() {
  ifstream in("diet.inp");

  s.protein = s.fat = s.carbohydrate = s.vitamin = 0;

  in >> Number;

  selected = new int[Number];
  list = new Ingredient[Number];

  in >> minIngredient[0] >> minIngredient[1] >> minIngredient[2] >> minIngredient[3];

  for(int i = 0; i < Number; i++){
    in >> list[i].protein >> list[i].fat >> list[i].carbohydrate >> list[i].vitamin >> list[i].price;
    prevSum += list[i].price;
    selected[i] = 0;
    result.push_back(i + 1);
  }
}

void findCombination(int count, int sum){
  if(sum >= prevSum) return;
  if(count >= Number) return;

  for(int i=count; i < Number; i++){
    s.protein += list[i].protein;
    s.fat += list[i].fat; 
    s.carbohydrate += list[i].carbohydrate;
    s.vitamin += list[i].vitamin;
    selected[i]++;
    count++;
    sum += list[i].price;

    if (s.protein >= minIngredient[0] && s.fat >= minIngredient[1] && s.carbohydrate >= minIngredient[2] && s.vitamin >= minIngredient[3]) {
      if (sum < prevSum) {
        prevSum = sum;
        result.clear();
        
        for(int j = 0; j < Number; j++) {
          if(selected[j] == 1) result.push_back(j+1);
        }
      } else if(sum == prevSum) {
        int number = 0;
        for (int j=0; j < Number; j++) {
          if (selected[j] == 1) {
            number++;
          }
        }

        if (number < result.size()) {
          result.clear();
          for (int j = 0; j < Number; j++) {
            if (selected[j] == 1) result.push_back(j+1);
          }
        }
      }
    }

    findCombination(count, sum);

    s.protein -= list[i].protein;
    s.fat -= list[i].fat;
    s.carbohydrate -= list[i].carbohydrate;
    s.vitamin -= list[i].vitamin;
    selected[i]--;
    sum -= list[i].price;
  }
}

void writeResultFile(vector<int> result) {
  ofstream resultFile("diet.out");

  if (resultFile.is_open()) {
    for (int i = 0; i < result.size() - 1; i++) {
      resultFile << result[i] << " ";
    }
    resultFile << result[result.size() - 1];
  }

  resultFile.close();
}

int main(void) {
  parseInputFile();
  findCombination(0, 0);
  writeResultFile(result);

  return 0;
}
// author: SungYun Jo, @extJo at github
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <limits>
using namespace std;

struct Point {
  int x, y;

  Point() : x(0), y(0) {};
  Point(int x, int y) : x(x), y(y) {};
  bool operator==(const Point& a) const {
    return (x == a.x) && (y == a.y);
  }
  bool operator!=(const Point& a) const {
    // return (x != a.x) || (y != a.y);
    return !(*this == a);
  }
};

double getDistance(Point a, Point b) {
  return sqrt((pow((a.x - b.x), 2) + pow((a.y - b.y), 2)));
}

struct Line {
  Point a, b;
  double length;
  
  Line(Point a, Point b) : a(a), b(b) { length = getDistance(a, b); };
  bool isContain(Point &p) {
    return (a == p) || (b == p);
  }
  bool isConnect(Line &l) {
    return (a == l.a) || (a == l.b) || (b == l.a) || (b == l.b);
  }
  bool isLeft(Point &p) {
    return a == p;
  }
};

void parseInputFile(vector<Point> &points, Point &start, Point &end) {
  ifstream in("battery.inp");

  in.is_open();

  int numberOfPoint, endPoint;
  in >> numberOfPoint >> endPoint;

  start = Point(0, 0);
  points.push_back(start);
  for (int i = 0; i < numberOfPoint; i++) {
    int x, y;
    in >> x >> y;

    points.push_back(Point(x, y));
  }
  end = Point(endPoint, endPoint);
  points.push_back(end);

  in.close();
}

void writeResultFile(double result) {
  ofstream resultFile("battery.out");

  if(resultFile.is_open()) {
    resultFile << result;
  }

  resultFile.close();
}

int sortPartition(vector<Point> &points, int left, int right) {
  const int mid = left + (right - left) / 2;
  const Point pivot = points.at(mid);

  points.at(mid) = points.at(left);
  points.at(left) = pivot;

  int i = left + 1;
  int j = right;
  
  while (i <= j) {
      while(i <= j && points.at(i).x <= pivot.x) {
          i++;
      }

      while(i <= j && points.at(j).x > pivot.x) {
          j--;
      }

      if (i < j) {
        Point temp1 = points.at(i);
        points.at(i) = points.at(j);
        points.at(j) = temp1;
      }
  }

  Point temp2 = points.at(i - 1);
  points.at(i - 1) = points.at(left);
  points.at(left) = temp2;

  return i - 1;
}
void quicksort(vector<Point> &points, const int left, const int right){
  int part = sortPartition(points, left, right);

  if (left < part - 1) {
      quicksort(points, left, part - 1);
  }
  if (part + 1 < right) {
      quicksort(points, part + 1, right);
  }
}

Point getMiddlePoint(Point a, Point b) {
  return Point(ceil((a.x + b.x)/2), ceil((a.y + b.y)/2));
}

Point findNearestPoint(vector<Point> &points, Point point) {
  double minDistance = numeric_limits<double>::infinity();
  Point nearestPoint;

  for(auto it = points.cend(); it != points.cbegin(); --it) {
    double currentDistance = getDistance(point, *it);
      if (currentDistance < minDistance) {
        minDistance = currentDistance;
        nearestPoint = *it;
    }
  }
  return nearestPoint;
}

// 도착지 부터 0,0 의 path를 찾자!
// start 가 오른쪽 상단, end가 아랫쪽 하단
void findPath(vector<Point> &points, Point current, Point end, vector<Point> &exploredChargers) {
  if (current == end) {
    return;
  } else {
    double minDistance = getDistance(current, end);
    Point nextPoint;
    int minIndex;

    for(auto it = points.cend(); it != points.cbegin(); --it) {
      double currentDistance = getDistance(current, *it);
      if (currentDistance < minDistance) {
        minDistance = currentDistance;
        minIndex = distance(points.cbegin(), it);
        nextPoint = *it;
        // cout << points.size() << " : " << minIndex << endl;
      }
    }

    // cout << points.size() << " " << currentPoint.x << " , " << currentPoint.y << " : " << minIndex << endl;

    cout << points.size() << " - [" << current.x << "," << current.y << "] - [" << end.x << "," << end.y << "] - [" << nextPoint.x << "," << nextPoint.y << "]" << " - minIndex : " << minIndex << " - minDistance : " << minDistance << endl;

    exploredChargers.push_back(nextPoint);
    points.erase(points.cbegin() + minIndex);
    
    points.shrink_to_fit();

    findPath(points, nextPoint, end, exploredChargers);   
  }
}

double findWeight(vector<Point> &exploredChargers) {
  double maxDistance;

  for (int i = 0; i < exploredChargers.size() - 1; i++) {
    double nextDistance = getDistance(exploredChargers.at(i), exploredChargers.at(i+1));

    if (nextDistance > maxDistance) {
      maxDistance = nextDistance;
    }
  }

  return ceil(maxDistance);
}

/* ===================================== **/


// 거리 제약이 안먹히는 거 같음 확인
vector<Line> makeLineSpace(vector<Point> &points, int distanceLimit) {
  vector<Line> space;
  vector<Point> pointSpace1 = points;
  vector<Point> pointSpace2 = points;

  for(Point p1 : pointSpace1) {
    for(Point p2 : pointSpace2) {
      if ((p1 != p2) && (getDistance(p1, p2) <= distanceLimit)) { space.push_back(Line(p1, p2)); }
    }
    pointSpace2.erase(pointSpace2.begin());
  }
  return space;
}

bool isFullConnect(vector<Line> &lines, Point start, Point end) {
  Point nextStart;

  // cout << lines.size() << " - start: [" << start.x << "," << start.y << "] - end: [" << end.x << "," << end.y << "]" << endl;

  for (auto it = lines.begin(); it != lines.end(); ++it) {
    // cout << "[" << it->a.x << "," << it->a.y << "]" << " - " << "[" << it->b.x << "," << it->b.y << "]" << endl;

    if (it->isLeft(start)) {
      nextStart = it->b;
      // cout << nextStart.x << "," << nextStart.y << endl;
      lines.erase(it);
      lines.shrink_to_fit();

      if (nextStart == end) {
        return true;
      }

      return isFullConnect(lines, nextStart, lines.at(lines.size()/2).a) || isFullConnect(lines, lines.at(lines.size()/2).b, end);
    }
  }

  return false;
}

bool canArrive(vector<Line> &lines, Point start, Point end) {
  int left, right = -1;
  
  for (int i = 0; i < lines.size(); i++) {
    if (lines.at(i).isContain(start)) { left = i; }
    if (lines.at(i).isContain(end)) { right = i; }
  }

  if (left == -1 || right == -1) {
    return false;
  }
  return isFullConnect(lines, start, end);
}

int main() {
  vector<Point> points;
  Point start, end;
  // vector<Point> exploredChargers;

  parseInputFile(points, start, end);
  quicksort(points, 0, points.size() - 1);

  // vector<Point> t1 = points;
  // vector<Point> t2 = points;

  // findPath(points, end, start, exploredChargers);

  // Point nearestMiddlePoint = findNearestPoint(points, getMiddlePoint(points.front(), points.back()));
  // cout << nearestMiddlePoint.x << "," << nearestMiddlePoint.y << endl;
  // findPath(t1, points.back(), nearestMiddlePoint, exploredChargers);
  // cout << "=============" << endl;
  // findPath(t2, nearestMiddlePoint, points.front(), exploredChargers);

  // writeResultFile(ceil(findWeight(exploredChargers)));

  vector<Point> a;
  a.push_back(Point(0, 0));
  a.push_back(Point(3, 1));
  a.push_back(Point(1, 7));
  a.push_back(Point(2, 5));
  a.push_back(Point(6, 2));
  a.push_back(Point(12, 2));
  a.push_back(Point(10, 5));
  a.push_back(Point(11, 9));
  a.push_back(Point(14, 7));
  a.push_back(Point(15, 10));
  a.push_back(Point(5, 13));
  a.push_back(Point(9, 12));
  a.push_back(Point(9, 15));
  a.push_back(Point(13, 15));
  a.push_back(Point(16, 16));

  // start = Point(0, 0);
  // end = Point(16, 16);
  int distanceLimit = 0;
  for (; distanceLimit < getDistance(start, end); distanceLimit++) {
    // cout << "=========================================" << distanceLimit << endl;
    vector<Line> space = makeLineSpace(points, distanceLimit);
    if (canArrive(space, start, end)) break;
  }

  writeResultFile(distanceLimit);

  return 0;
}

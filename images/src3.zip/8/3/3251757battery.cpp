// author: SungYun Jo, @extJo at github
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>

using namespace std;

struct Point {
  int x, y;

  Point() : x(0), y(0) {};
  Point(int x, int y) : x(x), y(y) {};
};

double getDistance(Point a, Point b) {
  return sqrt((pow((a.x - b.x), 2) + pow((a.y - b.y), 2)));
}

bool isReachable(vector<Point> &points, double distance, int index, vector<bool> &exploredPoints, vector<bool> &deadPoints) {
  if (index == points.size() - 1) {
    return true;
  }

  for (int i = 0; i < points.size(); ++i) {
    if (!exploredPoints.at(i) && !deadPoints.at(i) && getDistance(points.at(i), points.at(index)) <= distance) {
        exploredPoints.at(i) = 1;
        
        if(isReachable(points, distance, i, exploredPoints, deadPoints)) {
          return true;
        }

        exploredPoints.at(i) = false;
    }
  }

  deadPoints.at(index) = true;

  return false;       
}

double findPath(vector<Point> &points, Point &endPoint, double lowDistance, double highDistance) {
  if ((int)ceil(lowDistance) == (int)ceil(highDistance)) {
    return ceil(highDistance);
  }

  double middleDistance = (lowDistance + highDistance) / 2.0;
  
  vector<bool> exploredPoints(points.size(), false);
  vector<bool> deadPoints(points.size(), false);

  if (isReachable(points, middleDistance, 0, exploredPoints, deadPoints)) {
    return findPath(points, endPoint, lowDistance, middleDistance);
  }

  return findPath(points, endPoint, middleDistance, highDistance);
}

void parseInputFile(vector<Point> &points, Point &start, Point &end) {
  ifstream in("battery.inp");

  in.is_open();

  int numberOfPoint, endPoint;
  in >> numberOfPoint >> endPoint;

  start = Point(0, 0);
  points.push_back(start);
  for (int i = 0; i < numberOfPoint; i++) {
    int x, y;
    in >> x >> y;

    points.push_back(Point(x, y));
  }
  end = Point(endPoint, endPoint);
  points.push_back(end);

  in.close();
}

void writeResultFile(double result) {
  ofstream resultFile("battery.out");

  if (resultFile.is_open()) {
    resultFile << result;
  }

  resultFile.close();
}

int main(void) {
  vector<Point> points;
  Point start, end;

  parseInputFile(points, start, end);
  writeResultFile(findPath(points, end, 0.0, getDistance(start, end)));

  return 0;
}
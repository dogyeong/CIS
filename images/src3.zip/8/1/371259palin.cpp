// author: SungYun Jo, @extJo at github
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;

struct fileModel {
   // int number;
   vector<string> stringInputs;
};

fileModel parseInputFile() {
   fileModel input = fileModel();
   ifstream in("palin.inp");

   in.is_open();

   string number;
   getline(in, number);
   // number.pop_back();

   // input.number = stoi(number);

   string line;
   while(getline(in, line)) {
      line.pop_back();
      input.stringInputs.push_back(line);
   }

   in.close();

   return input;
}

void writeResultFile(vector<string> results) {
   ofstream resultFile("palin.out");

   if(resultFile.is_open()) {
      for(auto result: results) {
         resultFile << result << endl;
      }
   }

   resultFile.close();
}

int palinChecker(string str, bool lastChance = false) {
   int result = 1;
   int length = str.length();

   bool isPalin = true;
   for(size_t i = 0; i < length / 2 && isPalin; i++) {
      isPalin = str[i] == str[length - i - 1];
      result = isPalin ? 1 : 3;

      if(!isPalin && !lastChance) {
         string strWithoutLeftChar, strWithoutRightChar;
         strWithoutLeftChar.assign(str).erase(i, 1);
         strWithoutRightChar.assign(str).erase(length - i - 1, 1);

         int leftResult = palinChecker(strWithoutLeftChar, true);
         int rightResult = palinChecker(strWithoutRightChar, true);

         result = leftResult == 1 || rightResult == 1 ? 2 : 3;
      }
   }

   return result;
}

int main() {
   fileModel input = parseInputFile();

   vector<string> results;

   for(auto inputString: input.stringInputs) {
      results.push_back(to_string(palinChecker(inputString)));
   }

   writeResultFile(results);

   return 0;
}

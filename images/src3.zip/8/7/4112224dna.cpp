// author: SungYun Jo, @extJo at github
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

const int max(const int a, const int b) {
  return (a < b) ? b : a;
}

int getMax(int a, int b, int c, int d) {
  return max(max(max(a, b), c), d);
}

string longestString(string a, string b) {
  if (a.size() > b.size()) {
    return a;
  } else if (a.size() == b.size()) {
    return (a > b) ? b : a;
  } else {
    return b;
  }
}

string getLongestString(string a, string b, string c, string d) {
  return longestString(a, longestString(b, longestString(c, d)));
}

vector<vector<int>> getLssTable(string &first, string &second, vector<vector<string>> &strT) {
  vector<vector<int>> table(second.length() + 2, vector<int>(first.length() + 2, 0));

  vector<vector<string>> strTable(second.length() + 2, vector<string>(first.length() + 2, ""));

  for (int i = 2; i < second.length() + 2; i++) {
    for (int j = 2; j < first.length() + 2; j++) {
      if (second[i - 2] == first[j - 2]) {
        strTable[i][j] = getLongestString(strTable[i-2][j-2], strTable[i-1][j-2], strTable[i-2][j-1], strTable[i-1][j-1]) + second[i -2];

        table[i][j] = getMax(table[i-2][j-2], table[i-1][j-2], table[i-2][j-1], table[i-1][j-1]) + 1;
      }
    }
  }

  strT = strTable;
  return table;
}

string getLssString(vector<vector<int>> &table, string &first, string &second, vector<vector<string>> &strTable) {
  int maxOfFirst = 0;
  int maxOfSecond = 0;
  string result;
  
  // get max lss
  for (int i = 2; i < table.size(); i++) {
    for (int j = 2; j < table[i].size(); j++) {
      if (table[maxOfSecond][maxOfFirst] < table[i][j]) {
        maxOfSecond = i;
        maxOfFirst = j;
      } else if (table[maxOfSecond][maxOfFirst] == table[i][j]) {
        if (first[maxOfFirst - 2] > first[j - 2]) {
          maxOfSecond = i;
          maxOfFirst = j;
        }
      }
    }
  }

  result = strTable[maxOfSecond][maxOfFirst];

  return result;
}

void parseInputFile(string &first, string &second) {
  ifstream in("dna.inp");

  in.is_open();

  in >> first;
  in >> second;

  in.close();
}

void writeResultFile(string result) {
  ofstream resultFile("dna.out");

  if (resultFile.is_open()) {
    resultFile << result;
  }

  resultFile.close();
}

int main(void) {
  string first, second, result;
  vector<vector<int>> table;
  vector<vector<string>> strTable;

  parseInputFile(first, second);
  table = getLssTable(first, second, strTable);

  // cout << "               ";
  // for (auto c : first) {
  //   cout << c << "    ";
  // }

  // cout << endl;

  // for (int i = 0; i < table.size(); i++) {
  //   if (i > 1) {
  //     cout << second.at(i - 2) << "    ";
  //   } else {
  //     cout << "     ";
  //   }
    
  //   for (int j = 0; j < table[i].size(); j++) {
  //     cout << table[i][j] << "    ";
  //   }
  //   cout << endl;
  // }

  // cout << getLssString(table, first, second) << endl;

  result = getLssString(table, first, second, strTable);
  
  writeResultFile(result);

  return 0;
}
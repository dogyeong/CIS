// author: SungYun Jo, @extJo at github
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

string longestString(string a, string b) {
  if (a.size() > b.size()) {
    return a;
  } else if (a.size() == b.size()) {
    return (a > b) ? b : a;
  } else {
    return b;
  }
}

string getLongestString(string a, string b, string c, string d) {
  return longestString(a, longestString(b, longestString(c, d)));
}

vector<vector<string>> getLssTable(string &first, string &second) {
  vector<vector<string>> table(second.length() + 2, vector<string>(first.length() + 2, ""));

  for (int i = 2; i < second.length() + 2; i++) {
    for (int j = 2; j < first.length() + 2; j++) {
      if (second[i - 2] == first[j - 2]) {
        table[i][j] = getLongestString(table[i-2][j-2], table[i-1][j-2], table[i-2][j-1], table[i-1][j-1]) + second[i -2];
      }
    }
  }

  return table;
}

string getLssString(string &first, string &second, vector<vector<string>> &table) {
  int maxOfFirst = 0;
  int maxOfSecond = 0;
  string result;
  
  // find max lss
  for (int i = 2; i < table.size(); i++) {
    for (int j = 2; j < table[i].size(); j++) {
      if (table[maxOfSecond][maxOfFirst].size() < table[i][j].size()) {
        maxOfSecond = i;
        maxOfFirst = j;
      } else if (table[maxOfSecond][maxOfFirst].size() == table[i][j].size()) {
        if (first[maxOfFirst - 2] > first[j - 2]) {
          maxOfSecond = i;
          maxOfFirst = j;
        }
      }
    }
  }

  result = table[maxOfSecond][maxOfFirst];

  return result;
}

void parseInputFile(string &first, string &second) {
  ifstream in("dna.inp");

  in.is_open();

  in >> first;
  in >> second;

  in.close();
}

void writeResultFile(string result) {
  ofstream resultFile("dna.out");

  if (resultFile.is_open()) {
    resultFile << result;
  }

  resultFile.close();
}

int main(void) {
  string first, second, result;
  vector<vector<string>> table;

  parseInputFile(first, second);
  table = getLssTable(first, second);
  result = getLssString(first, second, table);
  writeResultFile(result);

  return 0;
}
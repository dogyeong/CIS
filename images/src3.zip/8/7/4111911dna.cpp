// author: SungYun Jo, @extJo at github
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

const int max(const int a, const int b) {
  return (a < b) ? b : a;
}

int getMax(int a, int b, int c = 0, int d = 0) {
  return max(max(max(a, b), c), d);
}

vector<vector<int>> getLssTable(string &first, string &second) {
  vector<vector<int>> table(second.length() + 2, vector<int>(first.length() + 2, 0));

  for (int i = 2; i < second.length() + 2; i++) {
    for (int j = 2; j < first.length() + 2; j++) {
      if (second[i - 2] == first[j - 2]) {
        table[i][j] = getMax(table[i-2][j-2], table[i-1][j-2], table[i-2][j-1], table[i-1][j-1]) + 1;
      }
    }
  }

  return table;
}

string getLssString(vector<vector<int>> &table, string &first, string &second) {
  int maxOfFirst = 0;
  int maxOfSecond = 0;
  string result = "";

  // get max lss
  for (int i = 2; i < table.size(); i++) {
    for (int j = 2; j < table[i].size(); j++) {
      if (table[maxOfSecond][maxOfFirst] < table[i][j]) {
        maxOfSecond = i;
        maxOfFirst = j;
      } else if (table[maxOfSecond][maxOfFirst] == table[i][j]) {
        if (first[maxOfFirst - 2] > first[j - 2]) {
          maxOfSecond = i;
          maxOfFirst = j;
        }
      }
    }
  }

  // find string
  while(table[maxOfSecond][maxOfFirst] != 0) {
    int currentLss = table[maxOfSecond][maxOfFirst];
    result = second.at(maxOfSecond - 2) + result;

    vector<int> tempSecond;
    vector<int> tempFirst;
    vector<char> tempChar;

    // 1. currentLss -1 값을 가지는 녀석을 찾는다
    // 2. 여러 개라면 char로 비교 한다
    // 3. 해당하는 녀석의 index로 변경한다

    if (table[maxOfSecond - 1][maxOfFirst - 1] == (currentLss - 1)) {
      tempSecond.push_back(maxOfSecond - 1);
      tempFirst.push_back(maxOfFirst - 1);
      tempChar.push_back(second.at(maxOfSecond - 3));
    }

    if (table[maxOfSecond - 2][maxOfFirst - 1] == (currentLss - 1)) {
      tempSecond.push_back(maxOfSecond - 2);
      tempFirst.push_back(maxOfFirst - 1);
      tempChar.push_back(second.at(maxOfSecond - 4));
    }

    if (table[maxOfSecond - 1][maxOfFirst - 2] == (currentLss - 1)) {
      tempSecond.push_back(maxOfSecond - 1);
      tempFirst.push_back(maxOfFirst - 2);
      tempChar.push_back(second.at(maxOfSecond - 3));
    }

    if (table[maxOfSecond - 2][maxOfFirst - 2] == (currentLss - 1)) {
      tempSecond.push_back(maxOfSecond - 2);
      tempFirst.push_back(maxOfFirst - 2);
      tempChar.push_back(second.at(maxOfSecond - 4));
    }

    int priorityIndex = 0;
    for (int k = 0; k < tempChar.size() - 1; k++) {
      if (tempChar[k] > tempChar[k+1]) {
        priorityIndex = k+1;
      }
    }

    maxOfSecond = tempSecond[priorityIndex];
    maxOfFirst = tempFirst[priorityIndex];
  }

  return result;
}

void parseInputFile(string &first, string &second) {
  ifstream in("dna.inp");

  in.is_open();

  in >> first;
  in >> second;

  in.close();
}

void writeResultFile(string result) {
  ofstream resultFile("dna.out");

  if (resultFile.is_open()) {
    resultFile << result;
  }

  resultFile.close();
}

int main(void) {
  string first, second, result;
  vector<vector<int>> table;

  parseInputFile(first, second);
  table = getLssTable(first, second);
  writeResultFile(getLssString(table, first, second));

  // cout << "               ";
  // for (auto c : first) {
  //   cout << c << "    ";
  // }

  // cout << endl;

  // for (int i = 0; i < table.size(); i++) {
  //   if (i > 1) {
  //     cout << second.at(i - 2) << "    ";
  //   } else {
  //     cout << "     ";
  //   }
    
  //   for (int j = 0; j < table[i].size(); j++) {
  //     cout << table[i][j] << "    ";
  //   }
  //   cout << endl;
  // }

  // cout << getLssString(table, first, second) << endl;

  return 0;
}
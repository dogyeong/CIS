input = open('./palin.inp', 'r')
output = open('./palin.out', 'w')

count = int(input.readline())

def isPalindrome(str):
    if (not str or len(str) == 0):
        return '3'

    half = int(len(str) / 2)
    isPseudo = False
    i = 0
    j = len(str) - 1

    while (i < half):
        if (str[i] != str[j] and not isPseudo):
            isPseudo = True
            if (str[i] == str[j - 1]): j -= 1
            elif (str[i + 1] == str[j]): i += 1
            else: return '3'
        i += 1
        j -= 1

    if (isPseudo): return '2'
    return '1'

for _ in range(count):
    str = input.readline().rstrip()
    output.write(isPalindrome(str) + '\n')

output.close()
input.close()

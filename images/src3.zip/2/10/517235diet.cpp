#include <climits>
#include <fstream>
#include <vector>

using namespace std;

int length;
vector<int> threshold;
vector<vector<int>> nutrients;
vector<int> min_nutrient_set;
int min_cost = INT_MAX;

vector<int> sum(vector<int> nutrient_index) {
  vector<int> nutrient_sum(5, 0);
  for (int i = 0; i < nutrient_index.size(); i++) {
    int index = nutrient_index[i];
    for (int j = 0; j < 5; j++) {
      nutrient_sum[j] += nutrients[index][j];
    }
  }
  return nutrient_sum;
}

bool is_enough_nutrient(vector<int> nutrient_index) {
  vector<int> nutrient_sum = sum(nutrient_index);
  bool is_enough = true;
  for (int i = 0; i < 4; i++) {
    if (nutrient_sum[i] < threshold[i]) {
      is_enough = false;
    }
  }
  return is_enough;
}

int cost(vector<int> nutrient_index) {
  vector<int> nutrient_sum = sum(nutrient_index);
  return nutrient_sum[4];
}

bool is_smaller_than_min_cost(vector<int> nutrient_index) {
  return cost(nutrient_index) < min_cost;
}

vector<int> iterative_diet(vector<int> nutrient_index, int cur_index) {
  vector<int> new_nutrient_index(nutrient_index);
  new_nutrient_index.push_back(cur_index);

  if (is_enough_nutrient(new_nutrient_index)) {
    if (is_smaller_than_min_cost(new_nutrient_index)) {
      min_cost = cost(new_nutrient_index);
      return new_nutrient_index;
    }
    return min_nutrient_set;
  }

  for (int i = cur_index + 1; i < length; i++) {
    min_nutrient_set = iterative_diet(new_nutrient_index, i);
  }
  return min_nutrient_set;
}

vector<int> diet() {
  for (int i = 0; i < length; i++) {
    vector<int> t;
    iterative_diet(t, i);
  }
  return min_nutrient_set;
}

int main() {
  ifstream ifs("3.inp");
  ofstream ofs("diet.out");

  ifs >> length;
  int value;
  for (int i = 0; i < 4; i++) {
    ifs >> value;
    threshold.push_back(value);
  }

  for (int i = 0; i < length; i++) {
    vector<int> temp;
    for (int j = 0; j < 5; j++) {
      ifs >> value;
      temp.push_back(value);
    }
    nutrients.push_back(temp);
  }

  diet();

  for (int i = 0; i < min_nutrient_set.size(); i++) {
    ofs << min_nutrient_set[i] + 1 << " ";
  }

  ofs.close();
  ifs.close();
  return 0;
}

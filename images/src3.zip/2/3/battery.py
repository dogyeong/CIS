import math

class Node:
    def __init__(self, x, y, parent = None):
        self.x = x
        self.y = y
        self.parent = parent
    def isAncestor(self, node):
        if (self.x == node.x and self.y == node.y):
            return True
        elif (self.parent):
            return self.parent.isAncestor(node)
        return False
    def getDistance(self, node):
        return math.sqrt((self.x - node.x) ** 2 + (self.y - node.y) ** 2)

class Problem:
    def __init__(self, nodes, z):
        self.nodes = nodes
        self.z = z
    def getAccessibleNodes(self, referenceNode, maxDistance):
        accessibleNodes = []
        for i in range(len(self.nodes)):
            distance = referenceNode.getDistance(self.nodes[i])
            upper = self.nodes[i].x >= referenceNode.x or self.nodes[i].y >= referenceNode.y
            isAncestor = referenceNode.isAncestor(self.nodes[i])
            if ((distance <= maxDistance and distance > 0) and upper and not isAncestor):
                accessibleNodes.append(self.nodes[i])
        return accessibleNodes
    def isSolution(self, accessibleNodes, maxDistance):
        targetNode = Node(self.z, self.z)
        for i in range(len(accessibleNodes)):
            if (targetNode.getDistance(accessibleNodes[i]) <= maxDistance):
                return True
        return False


input = open('./battery.inp', 'r')
output = open('./battery.out', 'w')
distanceMap = {}
file = input.readlines()
file = list(map(lambda x: x.strip().split(), file))
file = list(map(lambda x: list(map(lambda y: int(y), x)), file))
n = file[0][0]
z = file[0][1]
nodes = list(map(lambda x: Node(x[0], x[1]), file[1:]))
problem = Problem(nodes, z)

def recursiveSearch(node, maxDistance):
    accessibleNodes = problem.getAccessibleNodes(node, maxDistance)
    if (problem.isSolution(accessibleNodes, maxDistance)):
        return True
    elif (len(accessibleNodes) == 0):
        return False

    for i in range(len(accessibleNodes)):
        child = accessibleNodes[i]
        childNode = Node(child.x, child.y, node)
        result = recursiveSearch(childNode, maxDistance)
        if (result):
            return True
    return False

def search(z):
    initialNode = Node(0, 0)
    minDistance = 0
    maxDistance = z
    currentDistance = math.floor(z / 4)
    success = False

    while (True):
        success = recursiveSearch(initialNode, currentDistance)
        distanceMap[currentDistance] = success

        if (success):
            maxDistance = currentDistance
            if (currentDistance - 1 in distanceMap and distanceMap[currentDistance - 1] is False):
                return currentDistance
        else:
            minDistance = currentDistance
            if (currentDistance + 1 in distanceMap and distanceMap[currentDistance + 1] is True):
                return currentDistance

        currentDistance = math.floor((minDistance + maxDistance) / 2)

w = search(z)
output.write(str(w))

output.close()
input.close()

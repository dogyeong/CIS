#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

class Station {
public:
    Station(int x = 0, int y = 0): x(x), y(y) {}

    double GetDistance(const Station& s) const {
        return sqrt((x - s.x) * (x - s.x) + (y - s.y) * (y - s.y));
    }
    void SetPosition(int x, int y) {
        this->x = x;
        this->y = y;
    }
private:
    int x;
    int y;
};

bool IsAccessible(
    vector<Station> const& stations,
    double distance,
    int pos,
    vector<int>& explored,
    vector<int>& deadend
) {
    if (pos == stations.size() - 1) {
        return true;
    }

    for (int i = 0; i < stations.size(); ++i) {
        bool needToCheck = explored[i] + deadend[i] == 0;
        bool accessible = stations[i].GetDistance(stations[pos]) <= distance;
        if (needToCheck && accessible) {
            explored[i] = 1;
            if (IsAccessible(stations, distance, i, explored, deadend)) {
                return true;
            }
            explored[i] = 0;
        }
    }
   deadend[pos] = 1;
   return false;
}

double Search(
    vector<Station> const& stations,
    Station const& dest,
    double bottom,
    double top
) {
    if (ceil(bottom) == ceil(top)) {
        return ceil(top);
    }

    double mid = (bottom + top) / 2.0;
    vector<int> explored(stations.size(), 0);
    vector<int> deadend(stations.size(), 0);
    if (IsAccessible(stations, mid, 0, explored, deadend)) {
        return Search(stations, dest, bottom, mid);
    }
   return Search(stations, dest, mid, top);
}

int main(void) {
    ifstream ifs("battery.inp");
    ofstream ofs("battery.out");
    int n, z;
    int x, y;

    ifs >> n >> z;

    Station origin(0, 0);
    Station dest(z, z);
    vector<Station> station(n + 2);
    station[0] = origin;
    station[n + 1] = dest;
    for (int i = 1; i <= n; ++i) {
        ifs >> x >> y;
        station[i].SetPosition(x, y);
    }

    double d = Search(station, origin, 0.0, origin.GetDistance(dest));

    ofs << d << endl;
    ofs.close();
    ifs.close();

    return 0;
}

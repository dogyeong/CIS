def print_matrix(t):
    for i in range(0, len(t)):
        for j in range(0, len(t[0])):
            print(t[i][j], end='  ')
        print()

def lss(a, b):
    length_a = len(a) + 2
    length_b = len(b) + 2
    lss_table = [[0 for x in range(length_b)] for y in range(length_a)]
    str_table = [[[''] for x in range(length_b)] for y in range(length_a)]

    for i in range(2, length_a):
        for j in range(2, length_b):
            if (a[i - 2] == b[j - 2]):
                max_lss = max(lss_table[i - 1][j - 1],
                              lss_table[i - 1][j - 2],
                              lss_table[i - 2][j - 1],
                              lss_table[i - 2][j - 2]) + 1
                lss_table[i][j] = max_lss
                str_table[i][j] = []

                if (max_lss == lss_table[i - 1][j - 1] + 1):
                    str_table[i][j] += list(map(lambda x: x + b[j - 2], str_table[i - 1][j - 1]))
                if (max_lss == lss_table[i - 1][j - 2] + 1):
                    str_table[i][j] += list(map(lambda x: x + b[j - 2], str_table[i - 1][j - 2]))
                if (max_lss == lss_table[i - 2][j - 1] + 1):
                    str_table[i][j] += list(map(lambda x: x + b[j - 2], str_table[i - 2][j - 1]))
                if (max_lss == lss_table[i - 2][j - 2] + 1):
                    str_table[i][j] += list(map(lambda x: x + b[j - 2], str_table[i - 2][j - 2]))

    max_lss = 0
    substrings = []
    for i in range(0, length_a):
        if (max_lss < lss_table[i][length_b - 1]):
            max_lss = lss_table[i][length_b - 1]

    for j in range(0, length_b):
        if (max_lss < lss_table[length_a - 1][j]):
            max_lss = lss_table[length_a - 1][j]

    for i in range(0, length_a):
        if (max_lss == lss_table[i][length_b - 1]):
            substrings += str_table[i][length_b - 1]

    for j in range(0, length_b):
        if (max_lss == lss_table[length_a - 1][j]):
            substrings += str_table[length_a - 1][j]

    return substrings

def dna(a, b):
    substrings = lss(a, b)
    substrings = substrings[:]
    substrings.sort()
    return substrings[0]

input = open('./dna.inp', 'r')
output = open('./dna.out', 'w')
a = input.readline().rstrip()
b = input.readline().rstrip()
result = dna(a, b)
output.write(result)

output.close()
input.close()

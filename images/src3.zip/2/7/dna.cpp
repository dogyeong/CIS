#include <fstream>
#include <vector>

using namespace std;

string l(string a, string b) {
    int size_a = a.size();
    int size_b = b.size();
    if (size_a > size_b) return a;
    else if (size_a == size_b) return (a < b) ? a : b;
    else return b;
}

string longest(string a, string b, string c, string d) {
    return l(a, l(b, l(c, d)));
}

string lss(string a, string b) {
    vector<vector<string>> table(b.length() + 2, vector<string>(a.length() + 2, ""));

    for (int i = 2; i < b.length() + 2; i++) {
        for (int j = 2; j < a.length() + 2; j++) {
            if (a[j - 2] == b[i - 2]) {
                table[i][j] = longest(table[i - 2][j - 2],
                                      table[i - 1][j - 2],
                                      table[i - 2][j - 1],
                                      table[i - 1][j - 1]) + b[i - 2];
            }
        }
    }

    int max_a = 0, max_b = 0;
    for (int i = 2; i < table.size(); i++) {
        for (int j = 2; j < table[i].size(); j++) {
            int max_size = table[max_b][max_a].size();
            int cur_size = table[i][j].size();

            if (max_size < cur_size) {
                max_b = i;
                max_a = j;
            } else if (max_size == cur_size) {
                if (a[max_a - 2] > a[j - 2]) {
                    max_b = i;
                    max_a = j;
                }
            }
        }
    }

    return table[max_b][max_a];
}

int main() {
    string a, b, result;

    ifstream ifs("dna.inp");
    ofstream ofs("dna.out");

    ifs >> a >> b;
    result = lss(a, b);
    ofs << result;

    ofs.close();
    ifs.close();

    return 0;
}

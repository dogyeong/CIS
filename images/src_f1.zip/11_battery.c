
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int **set;
int *visit;
int dfs(int station,int x,int pivot){
    if(set[x][station]<=pivot)
        return 1;
    int sum=0;
    for(int i=0;i<=station;++i){
        if(sum!=0)
            break;
        if(i==x||visit[i]==1){
            continue;
        }
        else if(set[x][i]<=pivot){
            visit[i]=1;
            sum= dfs(station,i,pivot);
        }
    }
    return sum;
}
int battery(int station, int *point, int pivot, int left,int right){
    int i;
    int j;
    int check=1;
    int result;
    int k,l;

    if((right-left)<=1){
        //printf("%d\n",left);
        return pivot;
    }

    //printf("distance: %d, left: %d, right:%d \n",pivot, left,right);
    visit = (int*)calloc(station+2,sizeof(int*)*(station+2));

    if(dfs(station,0,pivot)){
        //printf("big\n");
        return 1 * battery(station,point, (pivot+left)/2 ,left,pivot);
    }
    else{
        //printf("small\n");
        return 1 * battery(station, point, (pivot+right)/2, pivot,right);
    }
/*
    for(i=0; i<=station; i++){
        visit[i]=1;
        for(j=0; j<=station;j++){
            if((i==j)||(visit[j]==1)){
                continue;
            }
            else if(set[i][station]<=pivot){
                printf("big\n");
                return 1 * battery(station,point, (pivot+left)/2 ,left,pivot);
            }
            else if(j==station) {
                free(visit);
                printf("%d %d :",i,j); printf("%d :",set[i][j]);
                if(set[i][j] <= pivot){
                    printf("big\n");
                    return 1 * battery(station,point, (pivot+left)/2 ,left,pivot);
                }
                printf("small\n");
               return 1 * battery(station, point, (pivot+right)/2, pivot,right);
            }
            else if(set[i][j]<=pivot){
                //visit[i]=1;
                visit[j]=1;
                i=j-1;
                break;
            }
        }
    }*/
}
int main()
{

    int station, depart;
    int distance;
    int point[2004];  // point x , y
    int i,j,k;
    int min;
    int sum=0;
    int result;


    FILE* fp1 = fopen("battery.inp", "rt");
    FILE* fp2 = fopen("battery.out", "wt");

    if(fp1==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    if(fp2==NULL){
        puts("���� ȣ�� ����");
        return -1;
    }
    fscanf(fp1,"%d %d", &station, &depart); // ������ ���� ������ ��ǥ �ҷ�����

    point[0] = 0; // start point x
    point[1]= 0; // start point y
    for(i=2; i<=2*station; i+=2){ // point �ҷ�����
        fscanf(fp1, "%d %d", &point[i], &point[i+1]);
    }
    station+=1;
    point[i] = depart;
    point[i+1] = depart;
    set = (int**)malloc(sizeof(int*)*(station+2));
    for(int i=0; i<=station; i++){
        set[i] = (int*)malloc (sizeof(int) * station+2);
    }
    for(i=0; i<=2*station; i+=2){
        for(j=0; j<=2*station; j+=2){
           set[i/2][j/2]= ceil(sqrt(pow(point[i]-point[j],2) + pow(point[i+1] - point[j+1],2)));
        }
    }

    distance = ceil(sqrt(pow(depart,2)+pow(depart,2))); //start���� depart������ �Ÿ�
    min = battery(station, point, distance/2, 0,distance);
    fprintf(fp2,"%d",min+1);
    //printf("min distance: %d\n",min);


    free(set);
    fclose(fp1);
    fclose(fp2);
    return 0;
}

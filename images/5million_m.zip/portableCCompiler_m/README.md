Portable C Compiler
===================

This is a copy of the Portable C Compiler source from http://pcc.ludd.ltu.se/

The source history was imported from a CVS snapshot, `pcc-cvs-20180920.tgz` from http://pcc.ludd.ltu.se/ftp/pub/pcc/,
using the `cvs2git` tools.

Please note: *THIS IS NOT MY CODE!* It's here purely as a way to make this interesting codebase
more accessible. I'm not intending to make a fork of `pcc` or to become its maintainer.

Hence *I am unable to fix any problems* arising from this code, except possibly those relating
to the CVS import.

The source is BSD licensed. Please see `COPYING` for the exact terms.



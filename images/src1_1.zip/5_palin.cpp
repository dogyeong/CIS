#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int checkFunc(string st, int check)
{

    int stLength = st.length();
    int checkCnt = 0;
    int result = check;
    if(result == 3)
        return 3;
    for(int i=0; i<(stLength/2); i++)
    {
        if((st[i] != st[stLength-i-1])&&(st[i] == st[stLength-i-2]))
        {
            st.erase(stLength-i-1, 1);
            result = checkFunc(st,check+1);
            return result;
        }
        else if(((st[i] != st[stLength-i-1])&&(st[i+1] == st[stLength-i-1])))
        {
            st.erase(i, 1);
            result = checkFunc(st, check+1);
            return result;
        }
        else if(st[i] != st[stLength-i-1])
        {
            return 3;
        }

    }

    return result;

}
int main()
{
    ifstream fin("palin.inp");
    ofstream fout("palin.out");
    int num, resultnum;
    string temp;
    fin >> num;
    for(int i=0; i < num; i++)
    {
        fin >> temp;
        resultnum = checkFunc(temp,1);
        fout << resultnum << endl;
    }
    return 0;
}

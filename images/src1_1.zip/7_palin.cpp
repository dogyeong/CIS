#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

int is_palindorme(char* line){
    int len = strlen(line);
    int first, last;
    int num;

    num = 0;
    first = 0;
    last = len-1;
    for(int i = 0; i < len/2; i++)
    {
        if(line[first] != line[last])
        {
            if(line[first+1] == line[last])
            {
                num ++;
                first++;
            }
            else if(line[first] == line[last-1])
            {
                num++;
                last--;
            }
            else return 3;
        }

        first++;
        last--;
    }

    if(num == 0) return 1;
    else if(num == 1) return 2;
    else if(num > 1) return 3;
    else return 4;
}

int main()
{
    int check;
    char line[1000000];
    ifstream in("palin.inp");
    ofstream out("palin.out");


    if(in.is_open()) {
        in.getline(line,sizeof(line));

        while(in.getline(line,sizeof(line)))
        {
            //cout << line << endl;
            check = is_palindorme(line);

            switch(check)
            {
            case 1:
                cout << "1" << endl;
                out << "1" << endl;
                break;
            case 2:
                cout << "2" << endl;
                out << "2" << endl;
                break;
            case 3:
                cout << "3" << endl;
                out << "3" << endl;
                break;
            case 4:
                cout << "Error" << endl;
                break;
            }


        }
    }
    else {
        cout << "error" << endl;
    }

    in.close();
    out.close();
    return 0;
}

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class palin {
	private static String sentence = "";
	palin(){
		sentence="";
	}
	public static void setsentence(String _sentence) {
		sentence =_sentence;
	}
	public static String makereverse(String _sentence) {
		String reverse ="";
		for(int i=_sentence.length()-1;i>=0;i--) 
			reverse = reverse+ _sentence.charAt(i);
		return reverse;
	}
	public static String makesubstring(int i) {
		String newsentence = "";
		if(i==0)	newsentence = sentence.substring(1);
		else if(i==newsentence.length()-1) newsentence = newsentence.substring(0,sentence.length()-1);
		else	newsentence =sentence.substring(0,i)+sentence.substring(i+1);	
		return newsentence;
	}
	private static boolean checkpseudo() {
		String newsentence1, newsentence2= "";
		int _len = sentence.length();
		int i, j=0;
		for( i=0, j= _len-1;i<_len/2&&j>_len/2
				&&sentence.charAt(i)==sentence.charAt(j);i++ ,j--);
		if(!(i<_len/2&&j>_len/2)) return false;
		newsentence1 = makesubstring(i);
		newsentence2 = makesubstring(j);
		
		return checkpalindrome(newsentence1)||checkpalindrome(newsentence2);
	}
	public static boolean checkpalindrome() {
		int len = sentence.length();
		String s1= sentence.substring(0,len/2);
		String s2= ""; 
		if(len%2==0) s2 = sentence.substring(len/2);
		else s2=sentence.substring(len/2+1);
		s2 = makereverse(s2);
		if(s1.equals(s2)) return true;
		return false;
	}
	public static boolean checkpalindrome(String _sentence) {
		int len = _sentence.length();
		String s1= _sentence.substring(0,len/2);
		String s2= ""; 
		if(len%2==0) s2 = _sentence.substring(len/2);
		else s2=_sentence.substring(len/2+1);
		s2 = makereverse(s2);
		if(s1.equals(s2)) return true;
		return false;
	}
	public static void main(String[] args)throws IOException{
		palin p = new palin();
		File file = new File("palin.inp");
		File outputfile = new File("palin.out");
		
		Scanner input = new Scanner(file);
		PrintWriter fw = new PrintWriter(outputfile);
		int N =input.nextInt();
		input.nextLine();
		
		while(input.hasNext()&&(N <=10 && N>=3)) {
			p.setsentence(input.nextLine());
			if(p.checkpalindrome())
				fw.println(1);
			else if(p.checkpseudo())
				fw.println(2);
			else
				fw.println(3);
		}
		fw.close();
	}
}

﻿// diet_3.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <vector>
using namespace std;
int n;
int** ks;
int* happy, *peace;//기준.
int* r, * t;
int l = 0, k = 0;
bool flag = false;


bool diet(int di)
{
	/*for (int i = 0; i < k; i++)
		cout << r[i] << " ";
	cout << di<<endl;
	*/
	if (di == n + 1) return false;
	/*지금거를 넣었을때 더하기.
	지금거를 넣었는데 이것까지로 비용이 초과되면 cut return false
	영양소 기준에 충족되면 cut 그리고 비용이 더 적으면 기준 바꾸기. 그리고 int 에 추가. return true . 아니면 reurn false.
	충족 안되면 다음거 부르고 트루면 int 에 추가.
	*/
	//만약 지금거를 넣었는데 기준보다 비용이 높으면 cut
	if (happy[4] < peace[4] + ks[di][4])	flag = false;
	/*for (int i = 0; i < k; i++)
		cout << r[i] << " ";
	cout << di<<"   "<<happy[4] <<"~"<< peace[4]<<"   " <<ks[di][4]<<endl;*/
	int i = 0;
	for (i = 0; i < 4 &&
		ks[0][i] <= peace[i] + ks[di][i]; i++);//영양소 비교.
	if (i >= 4 && happy[4] >= peace[4] + ks[di][4]) {
		//cout << peace[1] << " " << ks[di][1];

		for (int j = 0; j < 5; j++)
			happy[j] = (peace[j] + ks[di][j]);
		r[k] = di;
		//cout << peace[1] << " " << ks[di][1]<<di<<endl;

		for (int j = 0; j < k+1; j++)
			t[j] = r[j];
		r[k] = 0;
		l = k + 1;
		for (int i = 0; i < k+1; i++)
			cout << t[i] << " ";
		//cout << peace[1];
		cout << endl;
		flag = true;
	}
	//영양소 기준은 충족하지만 비용이 bad.
	else if (i >= 4) flag = false;
	else if (i < 4) {
		int a= k;
		r[k++] = di;
		for (int j = 0; j < 5; j++)
			peace[j] += ks[di][j];
		diet(di + 1);
		k = a;
		r[k] = 0;
		for (int j = 0; j < 5; j++)
			peace[j] -= ks[di][j];
	}
	diet(di + 1);
	//지금거를 안 넣었을때 ekdmarj qnfmrl
	return flag;
}

int main()
{

	ifstream inp("2.inp");

	inp >> n;
	ks = new int* [n + 1];
	happy = new int[5];
	peace = new int[5];

	memset(happy, 0, sizeof(int) * 5);
	memset(peace, 0, sizeof(int) * 5);
	r = new int[n];
	t = new int[n];
	for (int i = 0; i < n + 1; i++) {
		ks[i] = new int[5];
		memset(ks[i], 0, sizeof(int) * 5);
	}

	for (int i = 0; i < n + 1; i++) {
		for (int j = 0; j < 5; j++) {
			if (i == 0 && j == 4) ks[i][j] = 0;
			else inp >> ks[i][j];
			//cout<<ks[i][j]<<" ";
		}
	}
	for (int i = 1; i < n + 1; i++)
		happy[4] += ks[i][4];
	//cout<<ks[0][4];
	inp.close();

	diet(1);
	ofstream out("2.out");
	for (int i = 0; i < l; i++)
		out << t[i] << " ";
	out.close();

	return 0;
}

// 프로그램 실행: <Ctrl+F5> 또는 [디버그] > [디버깅하지 않고 시작] 메뉴
// 프로그램 디버그: <F5> 키 또는 [디버그] > [디버깅 시작] 메뉴

// 시작을 위한 팁: 
//   1. [솔루션 탐색기] 창을 사용하여 파일을 추가/관리합니다.
//   2. [팀 탐색기] 창을 사용하여 소스 제어에 연결합니다.
//   3. [출력] 창을 사용하여 빌드 출력 및 기타 메시지를 확인합니다.
//   4. [오류 목록] 창을 사용하여 오류를 봅니다.
//   5. [프로젝트] > [새 항목 추가]로 이동하여 새 코드 파일을 만들거나, [프로젝트] > [기존 항목 추가]로 이동하여 기존 코드 파일을 프로젝트에 추가합니다.
//   6. 나중에 이 프로젝트를 다시 열려면 [파일] > [열기] > [프로젝트]로 이동하고 .sln 파일을 선택합니다.


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class battery {
	static int Points[][];
	static int pred = 0;
	static int xd = 0;

	public static int getlen(int[] p1,int[] p2 ) {
		return (int) Math.ceil(Math.sqrt((Math.pow(p1[0]-p2[0],2)+Math.pow(p1[1]-p2[1],2))));
	}
	
	public static boolean hoppingZ(int []p, int d, int z) {
		boolean arrive_Z = false;
		
		for(int i=1;i<=z;++i) {
			if((Points[i][2] ==0) && getlen(p,Points[i])<=d) {
				Points[i][2]=1;
				if(Points[i]==Points[z] || hoppingZ(Points[i],d,z))
					arrive_Z = true;
			}	
		}
		return arrive_Z;
	}
	public static int nextZ(int []p,int d, int z) {
		if(Math.abs(pred-xd)<=1)	return pred;
		
		if(p==Points[0])
			for(int i=1;i<=z;i++)
				Points[i][2]=0;
		
		if(hoppingZ(p,d,z)) {
			pred = d;
			return nextZ(p,(pred+xd)/2,z);
		}
		else {
			xd=d;
			return nextZ(p,(pred+xd)/2,z);
		}
	}
	
	public static void main(String[] args) throws IOException {
		
		File file = new File("battery.inp");
		File outputfile = new File("battery.out");
		
		Scanner input = new Scanner(file);
		PrintWriter fw = new PrintWriter(outputfile);
		
		int n = input.nextInt();
		int z = input.nextInt();
		
		Points = new int[n+2][3];	
		
		Points[0][0]=0;
		Points[0][1]=0;
		Points[0][2] =1;
		while(input.hasNext()) {
			for(int i=1;i<n+1;i++) {
				Points[i][0]=input.nextInt();
				Points[i][1]=input.nextInt();
				Points[i][2] =0;
			}
		}
		Points[n+1][0]=z;
		Points[n+1][1]=z;
		Points[n+1][2] =0;
		System.out.println(n);
		
		pred = getlen(Points[0],Points[n+1]);
		
		fw.println(nextZ(Points[0], getlen(Points[0], Points[n+1])/2,n+1));
		
		fw.close();
	}
}

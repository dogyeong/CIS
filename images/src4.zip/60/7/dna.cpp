#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int MAX(int** lcs, int i, int j,string** s){
    int m = lcs[i-2][j-2];
    int li =i-2 , ki=j-2;
    for(int k = i-2;k<i;k++){
        for(int l = j-2;l<j;l++){
            if(m<=lcs[k][l]){
                m = lcs[k][l];
                if(s[k][l].length()>s[li][ki].length() || (s[k][l].length()<=s[li][ki].length() && s[k][l].compare(s[li][ki])<0)){
                    li=k;
                    ki=l;
                 }
            }
        }
    }
    //cout << m << endl;
    if((s[li][ki].compare("z"))!=0)
        s[i][j]=s[li][ki];
    return m;
}
string result(int **lcs, string** s, int len1, int len2)
{
    int m = lcs[2][2];
    int li = 2, ki =2;
    for (int i=0;i<len1; i++){
        for(int j=0;j<len2;j++)
            if(m<=lcs[i][j]){
                    m = lcs[i][j];
                    li=i;
                    ki=j;
            }
    }
    //cout<<"result:" <<m<<endl;
    return s[li][ki];
}
string LCS(string s1,string s2)
{
    int len1 = s1.size()+2;
    int len2 = s2.size()+2;
    int** lcs ;
    lcs= new int*[len1];
    string** s;
    s = new string*[len1];

    for(int i=0;i<len1;i++){
        lcs[i] = new int[len2];
        s[i] = new string[len2];
    }

    for(int i=0;i<len1;i++){
        for(int j=0;j<len2;j++){
            if(i==0 || j==0 || i==1 || j==1 ){
                lcs[i][j]=0;
                s[i][j]="z";
                continue;
            }
            else s[i][j]="";
        }
    }
    for(int i=2;i<len1;i++){
        for(int j=2;j<len2;j++){
            if(s1[i-2]==s2[j-2]) {
                    lcs[i][j]=MAX(lcs, i,j,s)+1;
                    s[i][j]+=s2[j-2];
            }
            else lcs[i][j]=0;
        }
    }
    return result(lcs, s, len1, len2);
}
int main()
{

    string s1,s2 ;
    ifstream inp("dna.inp");
    //ifstream inp("dan.inp");

    inp >> s1 >> s2;
    inp.close();

    //ofstream out("dna.out");
    ofstream out("dna.out");
    out<<LCS(s1,s2)<<endl;
   // cout<<LCS(s1,s2)<<endl;
    out.close();

    return 0;
}

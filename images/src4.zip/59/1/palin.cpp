#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
int palindrome(string inp)
{
	for (int i = 0; i < inp.length();i++) {
		if (inp[i] != inp[inp.length() - 1 - i])
			return 0;
	}
	return 1;
}

int pseudo_palindrome(string inp)
{
	string part1;
	string part2;
	int length = inp.length()-1;
	for (int i = 0; i < inp.length();i++) {
		part1 = inp.substr(0, i);
		part2 = inp.substr(i + 1, length--);
		part1 = part1 + part2;
		if (palindrome(part1) == 1)
			return 1;
	}
	return 0;
}

int main()
{

	vector<string> inp;
	ifstream ifile;
	ifile.open("palin.inp");
	char line[20000];
	if (ifile.is_open())
	{
		while (ifile.getline(line, sizeof(line)))
		{
			inp.push_back(line);
		}
	}
	ifile.close();

	ofstream ofile("palin.out");
	for (int i = 1;i <= atoi(inp[0].c_str());i++) {
		if (palindrome(inp[i]) == 1)
			ofile << "1" << endl;
		else if (pseudo_palindrome(inp[i]) == 1)
			ofile << "2" << endl;
		else
			ofile << "3" << endl;
	}
	ofile.close();
}

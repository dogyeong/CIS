#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <math.h>
#include <stack>
using namespace std;

int cap = 0;
int cnt = 0;
int n = 0;
int t = 0;
int cap2 = 0;
stack<int> s;

void addEdge(vector<int> adj[], int x, int y) {
	adj[cnt].push_back(x);
	adj[cnt].push_back(y);
	adj[cnt].push_back(0);
	cnt++;
}

void search(vector<int> adj[], int v) {
	if (adj[v][0] == t && adj[v][1] == t) {
		cout << "clear!" << endl;
		cap2=cap;
		cap = 1999;
		return;
	}
	int i;
	int j = 0;
	adj[v][2] = 1;
	for (i = 0;i < n+2;i++) {
		if (sqrt(pow(adj[v][0] - adj[i][0], 2) + pow(adj[v][1] - adj[i][1], 2)) <= cap&&adj[i][2] == 0) {
			s.push(i);
			j = i;
			i = 1000;
		}
	}
	cout << adj[v][0] << "," << adj[v][1] << endl;
	if (i == 1001)search(adj, j);
	else if (i == n+2) {
		if (s.empty())return;
		int k = s.top();
		s.pop();
		search(adj, k);
	}
}
int main() {
	int temp[2];
	vector<int> adj[1000];
	addEdge(adj, 0, 0);

	ifstream inp("battery.inp");
	inp >> n;
	inp >> t;
	for (int i = 0;i < n;i++) {
		inp >> temp[0];
		inp >> temp[1];
		addEdge(adj, temp[0], temp[1]);
	}
	inp.close();
	addEdge(adj, t, t);
	for(cap=0;cap<1000;cap++)
	search(adj, 0);
	ofstream out("battery.out");
	out << cap2;
	out.close();
}

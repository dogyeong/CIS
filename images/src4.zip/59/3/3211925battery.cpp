#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <math.h>
#include <stack>
#include <algorithm>
using namespace std;
int n;
int z;
int cap = 1;
int reccnt = 0;
stack<int> s;
struct point {
	int x, y, distance;
	int visited = 0;
	int num;
};

bool cmp(const point&p1, const point &p2) {
	if (p1.distance < p2.distance)
		return true;
	else
		return false;
}

int search(struct point *pnt, int v) {
	if (pnt[v].x == z&&pnt[v].y == z) {

		return 1;
	}
	pnt[v].visited = 1;
	for (int i = 0;i < n + 2;i++)
	{
		pnt[i].distance = pow(pnt[v].x - pnt[i].x, 2) + pow(pnt[v].y - pnt[i].y, 2);
	}
	sort(pnt, pnt + n + 2, cmp);


	int i;
	int j = 0;
	for (i = 0;i < n + 2;i++) {
		if (pnt[i].distance <= pow(cap, 2) && pnt[i].visited == 0) {
			s.push(pnt[0].num);

			j = i;
			i = 1500;
		}
		else if (pnt[i].distance > pow(cap, 2))
			i = 2000;
	}

	if (i == 1501) { search(pnt, j); }
	else {
		if (s.empty())return 0;
		int k = 0;

		for (int i = 0;i < n + 2;i++) {
			if (pnt[i].num == s.top())
			{
				k = i;
				i = n + 2;
			}
		}
		s.pop();

		search(pnt, k);
	}
}

int rec(struct point *pnt, double a,double b,double c) {
	if (reccnt == 8) {ofstream out("battery.out"); out<<ceil(b); return 0;}

	cap = b;
	reccnt++;
	  for (int i = 0;i < n + 2;i++) {
        pnt[i].visited = 0;
        pnt[i].distance = pow(pnt[i].x, 2) + pow(pnt[i].y, 2);
        }
        		while( false == s.empty( ) )
    {
        s.pop( );
    }
      sort(pnt, pnt + n + 2, cmp);
	int val=search(pnt, 0);

	if (val==1) rec(pnt, a,(a+b)/2,b);
	else rec(pnt, b, (b + c) / 2, c);
}

int main() {
	point pnt[1000];
	ifstream inp("battery.inp");
	inp >> n >> z;
	for (int i = 0;i < n;i++) {
		inp >> pnt[i].x >> pnt[i].y;
		pnt[i].distance = pow(pnt[i].x, 2) + pow(pnt[i].y, 2);
		pnt[i].num = i;
	}
	inp.close();
	pnt[n].x = 0;
	pnt[n].y = 0;
	pnt[n].distance = 0;
	pnt[n].num = n;
	pnt[n + 1].x = z;
	pnt[n + 1].y = z;
	pnt[n + 1].distance = 2 * pow(z, 2);
	pnt[n + 1].num = n + 1;

	sort(pnt, pnt + n + 2, cmp);

	int ab = 0;
	while (ab == 0) {
		cap = cap * 2;
		ab = search(pnt, 0);
		for (int i = 0;i < n + 2;i++) {
			pnt[i].visited = 0;
			pnt[i].distance = pow(pnt[i].x, 2) + pow(pnt[i].y, 2);

		}
		while( false == s.empty( ) )
    {
        s.pop( );
    }
		  sort(pnt, pnt + n + 2, cmp);
	}

	double cap2 = cap * 3 / 4;
	rec(pnt,cap/2,cap2,cap);

}

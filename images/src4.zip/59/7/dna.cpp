#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <algorithm>
#include <stack>
#include <vector>

using namespace std;
struct point {
	int x, y;
};

string LSS(string cmp1, string cmp2) {
	vector<vector<int> >arr;

	arr.assign(1100, vector<int>(1100, 0));

	int i, j;


	if (cmp1[1] == cmp2[1] && cmp1[0] == cmp2[0])arr[2][2] = 1;

	for (i = 3;i <= cmp1.length();i++)
		for (j = 2;j <= 2;j++) {
			if (cmp1[i - 1] == cmp2[j - 1]) {
				int val = 0;
				if (cmp1[i - 2] == cmp2[j - 2]) { int tmp = arr[i - 1][j - 1] + 1;if (tmp > val)val = tmp; }
				if (cmp1[i - 3] == cmp2[j - 2]) { int tmp = arr[i - 2][j - 1] + 1;if (tmp > val)val = tmp; }
				arr[i][j] = val;
			}
		}

	for (i = 2;i <= 2;i++)
		for (j = 3;j <= cmp2.length();j++) {
			if (cmp1[i - 1] == cmp2[j - 1]) {
				int val = 0;

				if (cmp1[i - 2] == cmp2[j - 2]) { int tmp = arr[i - 1][j - 1] + 1;if (tmp > val)val = tmp; }
				if (cmp1[i - 2] == cmp2[j - 3]) { int tmp = arr[i - 1][j - 2] + 1;if (tmp > val)val = tmp; }
				arr[i][j] = val;
			}
		}

	for (i = 3;i <= cmp1.length();i++)
		for (j = 3;j <= cmp2.length();j++) {
			if (cmp1[i - 1] == cmp2[j - 1]) {
				int val = 0;
				if (cmp1[i - 2] == cmp2[j - 2]) { int tmp = arr[i - 1][j - 1] + 1;if (tmp > val)val = tmp; }
				if (cmp1[i - 2] == cmp2[j - 3]) { int tmp = arr[i - 1][j - 2] + 1;if (tmp > val)val = tmp; }
				if (cmp1[i - 3] == cmp2[j - 2]) { int tmp = arr[i - 2][j - 1] + 1;if (tmp > val)val = tmp; }
				if (cmp1[i - 3] == cmp2[j - 3]) { int tmp = arr[i - 2][j - 2] + 1;if (tmp > val)val = tmp; }
				arr[i][j] = val;
			}
		}




	int max = 0;
	for (i = 1;i <= cmp1.length();i++)
		for (j = 1;j <= cmp2.length();j++)
			if (arr[i][j] > max)
				max = arr[i][j];

	point pnt[1100];
	int max_copy = max;
	int cnt_max = 0;

	int m, n = 0;
	for (i = 1;i <= cmp1.length();i++)
		for (j = 1;j <= cmp2.length();j++)
			if (arr[i][j] == max)
			{
				pnt[cnt_max].x = i;
				pnt[cnt_max].y = j;
				cnt_max++;
			}

	stack<char> s[1100];
	string ans[1100];
	for (int cnt = 0;cnt < cnt_max;cnt++)
	{

		s[cnt].push(cmp1[(pnt[cnt].x) - 1]);
		while (arr[pnt[cnt].x][pnt[cnt].y] != 0) {
			int d1 = 0;
			int d2 = 0;
			int ran1 = 2;
			int ran2 = 2;
			if (pnt[cnt].x == 2)
				ran1 = 1;
			if (pnt[cnt].y == 2)
				ran2 = 1;
			if (pnt[cnt].x == 1)
			{

				break;
			}
			if (pnt[cnt].y == 1)
			{

				break;
			}
			char tmp = '~';
			for (i = 1;i <= ran1;i++)
				for (j = 1;j <= ran2;j++)
					if (arr[(pnt[cnt].x) - i][(pnt[cnt].y) - j] == (max - 1) && cmp1[(pnt[cnt].x) - i - 1] == cmp2[(pnt[cnt].y) - j - 1])
						if (cmp1[(pnt[cnt].x) - i - 1] < tmp) {
							tmp = cmp1[(pnt[cnt].x) - i - 1];
							d1 = i; d2 = j;
						}
			s[cnt].push(tmp);
			pnt[cnt].x = pnt[cnt].x - d1;
			pnt[cnt].y = pnt[cnt].y - d2;

			max--;
		}
		max = max_copy;

		while (!s[cnt].empty()) {
			ans[cnt] = ans[cnt] + s[cnt].top();
			s[cnt].pop();
		}
	}

	for (int cnt = 1;cnt < cnt_max;cnt++) {
		for (i = 0;i < ans[cnt].length();i++) {
			if (ans[cnt][i] < ans[0][i])
			{
				ans[0] = ans[cnt];
				break;
			}
		}
	}

	return ans[0];
}


int main() {
	string dna1;
	string dna2;
	ifstream inp("dna.inp");
	inp >> dna1;
	inp >> dna2;
	inp.close();

	ofstream out("dna.out");
	out << LSS(dna1, dna2);
	out.close();

}

#include <bits/stdc++.h>
using namespace std;

int food[20][5];
int goal[4];
int n;
int dop = INT_MAX;
int dop2 = 0;
int dop3 = 0;
void cal(int answer) {
	int arr[5] = { 0, };
	int shift = 1;
	int cnt =0;
	for (int i = 0; i < n; i++) {
		if ((answer & shift) != 0) {
			for (int k = 0;k<5;k++) {
				arr[k] = arr[k] + food[i][k];
			}
			cnt++;
		}
		shift <<= 1;
	}
	if (arr[0] >= goal[0] && arr[1] >= goal[1] && arr[2] >= goal[2] && arr[3] >= goal[3])
		if (arr[4]<dop) { dop = arr[4];dop2 = answer; }
		else if (arr[4] == dop && cnt <= dop3) {
			shift = 1;
			for (int i = 0;i<n;i++) {
				if ((dop2&shift)<(answer&shift)) {
					dop = arr[4];dop2 = answer; dop3=cnt; break;
				}
				else if ((dop2&shift)>(answer&shift))break;
				shift <<= 1;
			}
		}
}

int main() {
	ifstream inp("diet.inp");

	inp >> n;
	for (int i = 0;i<4;i++)
		inp >> goal[i];
	for (int i = 0; i < n; i++) {
		for (int j = 0;j<5;j++)
			inp >> food[i][j];
	}
	inp.close();

	int answer = (1 << n);
	for (int i = answer;i<answer * 2 - 1;i++)
		cal(i);

	ofstream out("diet.out");
	int shift = 1;
	for (int i = 0; i < n; i++) {
		if ((dop2 & shift) != 0) out << i + 1 << " ";
		shift <<= 1;
	}
	out.close();
}

#include <bits/stdc++.h>
using namespace std;

int find_route(vector< vector<int> >& mat, pair<int, int>& p, string d1, string d2) {
    int count = 0;
    int max_r, max_c, rhs = mat[p.first][p.second] - 1;
    while(mat[p.first][p.second] > 0) {
        if(mat[p.first-1][p.second-1] == rhs) {
            count++;
        }
        if(mat[p.first-1][p.second-2] == rhs) {
            count++;
        }
        if(mat[p.first-2][p.second-1] == rhs) {
            count++;
        }
        if(mat[p.first-2][p.second-2] == rhs) {
            count++;
        }
    }
}

int find_big_element(vector< vector<int> >& mat, pair<int, int>& p, string d1, string d2) {
    int count = 0;
    if(p.first < 1 || p.second < 1)
        return -1;

    int max_r, max_c, rhs = mat[p.first][p.second] - 1;
    if(mat[p.first-1][p.second-1] == rhs) {
        cout << p.first-1 << " " << p.second-1 << d1[p.first-2] << " " << d2[p.second-2] << endl;
        count++;
        max_r = p.first-1;
        max_c = p.second-1;
    }
    if(mat[p.first-1][p.second-2] == rhs) {
        cout << p.first-1 << " " << p.second-2 << d1[p.first-2] << " " << d2[p.second-3] << endl;
        count++;
        max_r = p.first-1;
        max_c = p.second-2;
    }
    if(mat[p.first-2][p.second-1] == rhs) {
        cout << p.first-2 << " " << p.second-1 << d1[p.first-3] << " " << d2[p.second-2] <<endl;
        count++;
        max_r = p.first-2;
        max_c = p.second-1;
    }
    if(mat[p.first-2][p.second-2] == rhs) {
        cout << p.first-2 << " " << p.second-2 << d1[p.first-3] << " " << d2[p.second-3] << endl;
        count++;
        max_r = p.first-2;
        max_c = p.second-2;
    }
    /*
    if(count > 1) {
        if(mat[p.first-1][p.second-1] == rhs) {
            if(d1[max_r-1] > d1[p.first-2]) {
                max_r = p.first-1;
                max_c = p.second-1;
            }

        }
        if(mat[p.first-1][p.second-2] == rhs) {
            if(d1[max_r-1] > d1[p.first-2]) {
                max_r = p.first-1;
                max_c = p.second-2;
            }
        }
        if(mat[p.first-2][p.second-1] == rhs) {
            if(d1[max_r-1] > d1[p.first-3]) {
                max_r = p.first-2;
                max_c = p.second-1;
            }
        }
        if(mat[p.first-2][p.second-2] == rhs) {
            if(d1[max_r-1] > d1[p.first-3]) {
                max_r = p.first-2;
                max_c = p.second-2;
            }
        }

    }
    */
        p.first = max_r;
        p.second = max_c;

    return 1;
}
string get_semi_substr(string d1, string d2) {

    /*
    int mat[d1.size()+1][d2.size()+1];
    for(int i = 0; i < d1.size()+1; ++i)
        mat[i][0] = 0;
    for(int j = 0; j < d2.size()+1; ++j)
        mat[0][j] = 0;
    for(int i = 1; i < d1.size()+1; ++i) {
        if(d2[0] == d1[i-1])
            mat[i][1] = max( max(mat[i-1][0]+1, mat[i-1][1]), mat[i][0] );
        else
            mat[i][1] = max( max(mat[i-1][0], mat[i-1][1]), mat[i][0] );
    }
    for(int j = 1; j < d2.size()+1; ++j) {
        if(d1[0] == d2[j-1])
            mat[1][j] = max( max(mat[0][j-1]+1, mat[1][j-1]), mat[0][j] );
        else
            mat[1][j] = max( max(mat[0][j-1], mat[1][j-1]), mat[0][j] );
    }

    for(int i = 2; i < d1.size()+1; ++i) {
        for(int j = 2; j < d2.size()+1; ++j) {
            if(d1[i-1] == d2[j-1])
                mat[i][j] = max( max( max(mat[i-1][j], mat[i-2][j]), max(mat[i][j-1], mat[i][j-2]))
                                                             , mat[i-1][j-1]+1 );
            else
                mat[i][j] = max( max( max(mat[i-1][j], mat[i-2][j]), max(mat[i][j-1], mat[i][j-2]))
                                                             , mat[i-1][j-1] );

        }
    }
    */
    /*
    for(int i = 2; i < d1.size()+1; ++i) {
        for(int j = 2; j < d2.size()+1; ++j) {
            if(d1[i-1] == d2[j-1]) {
                if(mat[i-1][j-1] == mat[i-2][j-2])
                    mat[i][j] = max( max( max(mat[i-1][j], mat[i-2][j]), max(mat[i][j-1], mat[i][j-2]))
                                                             , mat[i-1][j-1]+1 );
                else
                    mat[i][j] = mat[i-1][j-1]+1;

            }

            else
                if(mat[i-1][j-1] == mat[i-2][j-2])
                    mat[i][j] = mat[i][j-1];
                else
                    mat[i][j] = max( max( max(mat[i-1][j], mat[i-2][j]), max(mat[i][j-1], mat[i][j-2]))
                                                             , mat[i-1][j-1] );

        }
    }
    */
    /*
    string LSS = "";
    int LSS_size = 0;
    int r, c;
    for(int i = 0; i < d1.size()+1; ++i) {
        int k = *max_element(mat[i], mat[i]+d2.size()+1);
        if(k > LSS_size)
            LSS_size = k;
    }
    int step = LSS_size-1;
    for(int i = 0; i < d1.size()+1; ++i)
        for(int j = 0; j < d2.size()+1; ++j)
            if(mat[i][j] == LSS_size) {
                r = i;
                c = j;
            }
    while(r > 1 && c > 1) {
        if(mat[r-1][c-1] == step) {
            if(mat[r-2][c-1] == step-1 || mat[r-1][c-2] == step-1) {
                LSS += d1[r-2];
                r = r-1;
                c = c-1;
            }
        }
        if(mat[r-2][c-1] == step) {
            if(mat[r-3][c-1] == step-1 || mat[r-2][c-2] == step-1) {
                LSS += d1[r-2];
                r = r-2;
                c = c-1;
            }
        }
        if(mat[r-1][c-2] == step) {
            if(mat[r-2][c-2] == step-1 || mat[r-1][c-3] == step-1) {
                LSS += d1[r-2];
                r = r-1;
                c = c-2;
            }
        }
        if(mat[r-2][c-2] == step) {
            if(mat[r-3][c-2] == step-1 || mat[r-2][c-3] == step-1) {
                LSS += d1[r-2];
                r = r-2;
                c = c-2;
            }
        }
    }
    */
    /*
    string LSS = "";
    int LSS_size = 0;
    for(int i = 0; i < d1.size()+1; ++i) {
        int k = *max_element(mat[i], mat[i]+d2.size()+1);
        if(k > LSS_size)
            LSS_size = k;
    }
    int step = 1;
    for(int i = 1; i < d1.size()+1; ++i) {
        for(int j = 1; j < d2.size()+1; ++j) {
                if(mat[i][j] == step) {
                    if(mat[i+1][j+1])


                }
                if(step > LSS_size)
                    break;
        }
    }
    cout << "LSS = " << LSS << endl;
    */
    vector< vector<int> > mat(d1.size()+1, vector<int>(d2.size()+1, 0));
    int LSS_size = 0;
    for(int i = 1; i < d1.size() + 1; ++i) {
        if(d1[i-1] == d2[0])
            mat[i][1] = 1;
        else
            mat[i][1] = -1;
    }
    for(int j = 1; j < d2.size() + 1; ++j) {
        if(d2[j-1] == d1[0])
            mat[1][j] = 1;
        else
            mat[1][j] = -1;
    }
    for(int i = 2; i < d1.size() + 1; ++i) {
        for(int j = 2; j < d2.size() + 1; ++j) {
            if(d1[i-1] == d2[j-1]) {
                if(mat[i-1][j-1] > 0 || mat[i-1][j-2] > 0 || mat[i-2][j-1] > 0 || mat[i-2][j-2] > 0) {
                    mat[i][j] = max(max(mat[i-1][j-1], mat[i-1][j-2]), max(mat[i-2][j-1], mat[i-2][j-2])) + 1;
                    if(mat[i][j] > LSS_size)
                        LSS_size = mat[i][j];
                }
                else
                    mat[i][j] = 1;
            }
            else
                mat[i][j] = -1;
        }
    }
    vector< pair<int, int> > p;
    for(int i = 0; i < d1.size() + 1; ++i) {
        for(int j = 0; j < d2.size() + 1; ++j) {
            if(mat[i][j] == LSS_size) {
                pair<int, int> pt;
                pt.first = i;
                pt.second = j;
                p.push_back(pt);
            }
        }
    }

    cout << LSS_size << endl;
    vector<string> LSSs;
    for(int i = 0; i < p.size(); ++i) {
        pair<int, int> pt = p[i];
        string LSS = "";
        LSS += d1[pt.first - 1];

        while(mat[pt.first][pt.second] != 1) {
            cout << "r = " << pt.first << " c = " << pt.second << endl;
            if(find_big_element(mat, pt, d1, d2))
                LSS += d1[pt.first - 1];
        }

        reverse(LSS.begin(), LSS.end());
        LSSs.push_back(LSS);

    }
    /*
    cout << "  ";

    for(int j = 0; j < d2.size()+1; ++j)
        cout << j << " ";
    cout << endl;
    for(int i = 0; i < d1.size()+1; ++i) {
        cout << i << " ";
        for(int j = 0; j < d2.size()+1; ++j) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }
    */
    for(int i = 0; i < LSSs.size(); ++i) {
        cout << LSSs[i] << endl;
    }
    return LSSs[0];
}

int main() {
    string dna1, dna2;
    ifstream ifs("3.inp");
    ifs >> dna1 >> dna2;

    string LSS = get_semi_substr(dna2, dna1);

    ofstream ofs("dna.out");
    ofs << LSS << endl;
    ofs.close();
    ifs.close();
    return 0;
}

#include <bits/stdc++.h>
using namespace std;

struct food {
    int num;
    int p, f, s, v;
    int c;
};

int mp, mf, ms, mv, mc;
vector<bool> sol;
int count(vector<bool>& v) {
	int c = 0;
	for(int i = 0; i < v.size(); ++i)
		if(v[i])
			c++;
	return c;
}
bool next(vector<bool>& v, int n, int zv) {
	if(count(v) == 0) {
		for(int i = 0; i < zv; ++i) {
			v[i] = true;
		}
		return true;
	}
	else {
		for(int i = v.size()-1; i > 0; --i) {
			if(!v[i] && v[i-1] && v[n-1] && !v[i+1]) {
				v[i] = true;
				v[i-1] = false;
				for(int j = i + 1; j < n; ++j) {
						v[j] = false;
				}
				int k = zv - count(v);
				int c = 0;
				for(int j = i + 1; j < n; ++j) {
					if(k > c) {
						c++;
						v[j] = true;
					}
					else
						break;
				}

				return true;
			}
			else if(!v[i] && v[i-1]) {
				v[i] = true;
				v[i-1] = false;
				return true;
			}
		}
	}
	return false;
}
bool is_valid(vector<bool>& vec, vector<food>& ch) {
    int p = 0, f = 0, s = 0, v = 0, cost = 0;
    for(int i = 0; i < vec.size(); ++i) {
        if(vec[i]) {
            p += ch[i].p;
            f += ch[i].f;
            s += ch[i].s;
            v += ch[i].v;
            cost += ch[i].c;
        }
    }

    if(p >= mp && f >= mf && s >= ms && v >= mv) {
        if(cost <= mc) {
            if(sol < vec)
                sol = vec;
            mc = cost;
        }
    }
}
int main() {
    ifstream ifs("diet.inp");
    int k;
    mc = INT_MAX;




    vector<food> choice;
    ifs >> k;
    ifs >> mp >> mf >> ms >> mv;
    food in;
    for(int i = 0; i < k; ++i) {
        in.num = i+1;
        ifs >> in.p >> in.f >> in.s >> in.v >> in.c;
        choice.push_back(in);
    }

    vector<bool> Case(k, 0);
    for(int i = 0; i < k; ++i) {
        while(next(Case, k, i+1)) {
            is_valid(Case, choice);
        }
        for(int j = 0; j < k; ++j) {
            Case[j] = false;
        }
    }
    ofstream ofs("diet.out");
    for(int i = 0; i < k; ++i) {
        if(sol[i])
            ofs << i+1 << " ";
    }

    ofs.close();
    ifs.close();
    return 0;
}

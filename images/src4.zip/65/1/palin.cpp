#include <bits/stdc++.h>
using namespace std;

int read_inp(string, vector<string>&);
int is_palin(string);


int main()
{
    int N;
    vector<string> words;
    N = read_inp("palin.inp", words);
    ofstream ofs("palin.out");
    for(int i = 0; i < words.size(); ++i) {
        ofs << is_palin(words[i]) << endl;
    }
    ofs.close();

    return 0;
}

int read_inp(string s, vector<string>& r)
{
    ifstream ifs(s);
    int N;
    ifs  >> N;

    string in;
    while(ifs >> in) {
        r.push_back(in);
    }
    ifs.close();
    return N;
}

int is_palin(string s)
{
    int count = 0;
    int i = 0;
    int j = s.length() - 1;

    while(i < j) {
        if(s[i] == s[j]) {
            i++;
            j--;
        }
        else {
            if(count == 0) {
                if((s[++i] == s[j]) || (s[--i] == s[--j])) {
                    count++;
                }
                else
                    return 3; // just string
            }
            else
                return 3; // one letter deleted but not pseudo palindrome
        }
    }
    if(count == 0) // palindrome
        return 1;
    else           // pseudo palindrome
        return 2;
}

#include <bits/stdc++.h>
using namespace std;

struct point {
    double x;
    double y;
    bool operator==(point p) {
        if(x == p.x && y == p.y)
            return true;
        else
            return false;
    }
};

double dist(point& a, point& b) {
    return sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
}
bool myfunc(point& a, point& b) {
    point p;
    p.x = 0, p.y = 0;
    return dist(p, a) < dist(p, b);

}
bool is_available_weight(int w, vector<point>& s) {
    stack<point> q;
    bool mark[s.size()] = {false, };
    q.push(s[0]);
    mark[0] = true;
    int i;
    while(!q.empty()) {
        for(i = 0; i < s.size(); ++i) {
            if(!mark[i] && dist(s[i], q.top()) <= w) {
                q.push(s[i]);
                mark[i] = true;
                break;
            }
        }
        if(!(i < s.size())) {
            q.pop();
        }
        if(!q.empty())
            if(q.top() == s[s.size()-1])
                return true;
    }
    return false;
}
int doubling_w(int w, int r, vector<point>& s) {
    if(!is_available_weight(w+r, s))
        doubling_w(w, 2*r, s);
    else {
        if(r == 1)
            return w+r;
        else
            doubling_w(w+r/2, 1, s);
    }

}
int main() {
    ifstream ifs("battery.inp");
    int n, z;
    ifs >> n >> z;

    vector<point> spot;
    point t = {0, 0};
    spot.push_back(t);
    for(int i = 0; i < n; ++i) {
        ifs >> t.x >> t.y;
        spot.push_back(t);
    }
    ifs.close();
    sort(spot.begin(), spot.end(), myfunc);
    t.x = z; t.y = z;
    spot.push_back(t);

    int weight = doubling_w(0, 1, spot);
    ofstream ofs("battery.out");
    ofs << weight << endl;
    ofs.close();
    return 0;
}

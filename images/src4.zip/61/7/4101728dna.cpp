#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <queue>
#include <algorithm>

using namespace std;

bool comp(const string& a, const string& b) {
    for(int i=0; i<a.size(); ++i)
        if(a[i] > b[i])
            return true;
    return false;
}

vector< vector<int> > table;
priority_queue<string, vector<string>, less<string>> longest_strings;
string str_A, str_B;
int longest_size = 0;

void gogo(int row, int col, int size, string str) {
    if(str.size() > longest_size)
        return ;

    if(size == 0) {
        reverse(str.begin(), str.end());
        longest_strings.push(str);
//        cout << str << endl;
        return;
    }

    for(int r = row-2; r < row; ++r) {
        for(int c = col-2; c < col; ++c) {
            if(table[r][c] == size) {
                str += str_A[r-2];
                gogo(r, c, size-1, str);
            }
        }
    }
}

int main() {
    ifstream ifs("dna.inp");
    ofstream ofs("dna.out");

    getline(ifs, str_A);
    getline(ifs, str_B);

//    cout << str_A << " " << str_B << endl;

//    vector< vector<int> > table(str_A.size()+2, vector<int>(str_B.size()+2, 0));
    table.resize(str_A.size()+2, vector<int>(str_B.size()+2, 0));
    vector<pair<int, int> > longest_queue;

    for(size_t row = 0; row < str_A.size(); ++row) {
        for(size_t col = 0; col < str_B.size(); ++col) {
            if( str_A[row] == str_B[col] ) {
                int max = table[row][col];

                if( table[row+1][col] > max )
                    max = table[row+1][col];
                if( table[row][col+1] > max )
                    max = table[row][col+1];
                if( table[row+1][col+1] > max )
                    max = table[row+1][col+1];
                table[row+2][col+2] = max + 1;

                if( table[row+2][col+2] > longest_size ) {
                    longest_size = table[row+2][col+2];
                    longest_queue.clear();
                    longest_queue.emplace_back(make_pair(row+2, col+2));
                } else if( table[row+2][col+2] == longest_size ) {
                    longest_queue.emplace_back(make_pair(row+2, col+2));
                } else ;

            }
        }
    }

//    for(size_t i=0; i<str_A.size()+2; ++i) {
//        for(size_t j=0; j < str_B.size()+2; ++j)
//            cout << table[i][j] << " ";
//        cout << endl;
//    }

    for(size_t i = 0; i < longest_queue.size(); ++i) {
        int row = longest_queue[i].first, col = longest_queue[i].second;

//        cout << longest_size << endl;
        string temp = string();

        temp += str_A[row-2];
        gogo(row, col, longest_size-1, temp);
    }


//    cout << longest_strings.size() << endl;
    while( !longest_strings.empty() ) {
//        cout << longest_strings.top() << endl;
        longest_strings.pop();
    }
    ofs << longest_strings.top() << endl;

    return 0;
}
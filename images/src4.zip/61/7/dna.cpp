#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <queue>
#include <algorithm>

using namespace std;

vector< vector<int> > table;
priority_queue<string, vector<string>, greater<string>> longest_strings;
string str_A, str_B;
int longest_size = 0;

void gogo(int row, int col, int size, string str) {
    if(size == 0) {
        reverse(str.begin(), str.end());
        longest_strings.push(str);
        return;
    }

    for(int r = row-2; r < row; ++r) {
        for(int c = col-2; c < col; ++c) {
            if(table[r][c] == size) {
                str.push_back(str_A[r-2]);
                gogo(r, c, size-1, str);
                str.pop_back();
            }
        }
    }
}

int main() {
    ifstream ifs("dna.inp");
    ofstream ofs("dna.out");

    getline(ifs, str_A);
    getline(ifs, str_B);

    table.resize(str_A.size()+2, vector<int>(str_B.size()+2, 0));
    vector<pair<int, int> > longest_queue;

    for(size_t row = 0; row < str_A.size(); ++row) {
        for(size_t col = 0; col < str_B.size(); ++col) {
            if( str_A[row] == str_B[col] ) {
                int max = table[row][col];

                if( table[row+1][col] > max )
                    max = table[row+1][col];
                if( table[row][col+1] > max )
                    max = table[row][col+1];
                if( table[row+1][col+1] > max )
                    max = table[row+1][col+1];
                table[row+2][col+2] = max + 1;

                if( table[row+2][col+2] > longest_size ) {
                    longest_size = table[row+2][col+2];
                    longest_queue.clear();
                    longest_queue.emplace_back(make_pair(row+2, col+2));
                } else if( table[row+2][col+2] == longest_size ) {
                    longest_queue.emplace_back(make_pair(row+2, col+2));
                } else ;

            }
        }
    }

    for(size_t i = 0; i < longest_queue.size(); ++i) {
        int row = longest_queue[i].first, col = longest_queue[i].second;
        string temp = string();

        temp.push_back(str_A[row-2]);
        gogo(row, col, longest_size-1, temp);
    }

    ofs << longest_strings.top() << endl;

    ifs.close();
    ofs.close();
    return 0;
}
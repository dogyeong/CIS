#include <iostream>
#include <fstream>
#include <iterator>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

int main(void) {

    ifstream ifs("palin.inp");
    ofstream ofs("palin.out");

    size_t N;

    ifs >> N;

    vector<string> data_list(N);
    vector<int>    is_palin(N, 1);
    bool palin_flag;

    for(size_t i = 0; i < N; ++i)
        ifs >> data_list[i];

    for(size_t i = 0; i < N; ++i) {
        palin_flag = false;
        for(size_t j = 0, k = data_list[i].size(); j < data_list[i].size()/2 && k > data_list[i].size()/2; ++j, --k)
            if( data_list[i][j] != data_list[i][k] ) {
                
                if( palin_flag ) {
                    is_palin[i] = 3;
                    break;
                }

                if( data_list[i][j + 1] == data_list[i][k] ) {
                    j += 1;
                    is_palin[i] = 2;
                    palin_flag = true;
                } else if( data_list[i][j] == data_list[i][k - 1] ) {
                    k -= 1;
                    is_palin[i] = 2;
                    palin_flag = true;
                } else {
                    is_palin[i] = 3;
                    break;
                }

            }
    }

//    copy(is_palin.begin(), is_palin.end(), ostream_iterator<int>(ofs, "\n"));
    for(int i=0; i<N; ++i)
        ofs << is_palin[i] << endl;

    ifs.close();
    ofs.close();
    return 0;
}

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

class Point {
    int x, y;
public:
    Point(void): x(0), y(0) {}
    Point(int xx, int yy): x(xx), y(yy) {}
    int length(const Point& cp) const { return (int)ceil( sqrt(pow(x-cp.x, 2) + pow(y-cp.y, 2)) ); }
    friend bool pKit1(const Point& p1, const Point& p2);
};

bool pKit1(const Point& p1, const Point& p2) { return p1.x < p2.x; }

void init(ifstream& ifs, vector<Point>& stor, int N, int Z) {
    int x, y;

    stor.resize(N+2);

    stor[0] = Point(0, 0);
    for(size_t i=1; i<N+1; ++i) {
        ifs >> x >> y;
        stor[i] = Point(x, y);
    }
    stor[N+1] = Point(Z, Z);

    sort(stor.begin(), stor.end(), pKit1);
}

bool find(int i, vector<int>& stack) {      // 더 빠른 검색으로
    size_t j;
    for(j=0; j<stack.size() && stack[j]!=i; ++j)
        ;
    return j<stack.size();
}

bool keepgoing(vector<Point>& vp, int sp, int Z, int mid, vector<int>& stack) {
    int j = sp;
    int len;
    vector<int> is;

    for(int i=0; i<vp.size(); ++i) {
        len = vp[j].length(vp[i]);
        if(!find(i, stack) && len <= mid) {
            stack.push_back(i);
            is.push_back(i);
        }
    }

    if(is.size() != 0 && is.back() == vp.size()-1)
        throw mid;
    else
        for(size_t i=0; i<is.size(); ++i)
            keepgoing(vp, is[i], Z, mid, stack);

    return false;
}

int main(void) {
    clock_t start = clock();

    ifstream ifs("3.inp");
    ofstream ofs("battery.out");

    int N, Z;
    int left, right, mid;
    int min;
    vector<Point> stor;

    ifs >> N >> Z;

    init(ifs, stor, N, Z);

    left = 0;
    right = stor[0].length(stor[N+1]);
    mid = static_cast<int>( sqrt(2*Z*Z) );

    while(1) {
        bool is_find = true;
        vector<int> stack;
        cout << "go" << endl;
        try {
            is_find = keepgoing(stor, 0, Z, mid, stack);
        }
        catch(int e) {
            min = e;
            right = mid;
            mid = (left+right)/2;
            if(right == left)
                break;
        }

        if( !is_find ) {
            left = mid;
            mid = (left+right)/2;
            if( right-left == 1 )
                break;
        }
        cout << "end" << endl;
    }

    cout << min << endl;
    ofs << min << endl;

    ifs.close();
    ofs.close();

    clock_t stop = clock();
    double elapsed = (double) (stop - start) / CLOCKS_PER_SEC;
    printf("\nTime elapsed: %.5f\n", elapsed);
    return 0;
}
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

class Point {
    int x, y;
public:
    Point(void): x(0), y(0) {}
    Point(int xx, int yy): x(xx), y(yy) {}
    void print(void) const { cout << x << " " << y << endl; }
    int length(const Point& cp) const { return (int)ceil( sqrt(pow(x-cp.x, 2) + pow(y-cp.y, 2)) ); }
    friend bool pKit1(const Point& p1, const Point& p2);
};

vector<int> stack;

void init(ifstream& ifs, vector<Point>& stor, int N, int Z) {
    int x, y;

    stor.resize(N+2);

    stor[0] = Point(0, 0);
    for(size_t i=1; i<N+1; ++i) {
        ifs >> x >> y;
        stor[i] = Point(x, y);
    }
    stor[N+1] = Point(Z, Z);
}

bool pKit1(const Point& p1, const Point& p2) { return p1.x < p2.x; }

bool find(int i) {
    size_t j;
    for(j=0; j<stack.size() && !(stack[j]==i); ++j)
        ;
    return j<stack.size();
}

bool keepgoing(vector<Point>& vp, int sp, int Z, int mid) {
    int j = sp;
    int len;
    vector<int> is;

    for(int i=0; i<vp.size(); ++i) {
        len = vp[j].length(vp[i]);
//        cout << i << " th len is" << len << endl;
        if(!find(i) && len <= mid) {
            stack.push_back(i);
            is.push_back(i);
        }
    }

//    for(size_t i=0; i<is.size(); ++i)
//        cout << is[i] << endl;

//    cout << "middle" << endl;

    if(is.size() != 0 && is.back() == vp.size()-1) {
        throw mid;
    } else {
        for(size_t i=0; i<is.size(); ++i)
            keepgoing(vp, is[i], Z, mid);
//        cout << "end" << endl;
        return false;
    }
}

int main(void) {
//    clock_t start = clock();

    ifstream ifs("battery.inp");
    ofstream ofs("battery.out");

    int N, Z;
    int left, right, mid;
    int min = Z;
    vector<Point> stor;

    ifs >> N >> Z;

    init(ifs, stor, N, Z);

    left = 0;
    right = stor[0].length(stor[N+1]);
    mid = static_cast<int>( sqrt(2*Z*Z) );
    sort(stor.begin(), stor.end(), pKit1);

    min = Z;
    while(1) {
        bool is_find = true;
//        cout << "@@@@@@@@@@@@@@@@@@@@@@@@@@@" << endl;
//        cout << "mid is " << mid << endl;
//        cout << "left & right is : " << left << " " << right << endl;
        stack.erase(stack.begin(), stack.end());
        try {
//            cout << "go" << endl;
            is_find = keepgoing(stor, 0, Z, mid);
        }
        catch(int e) {
//            cout << "catch" << endl;
            min = e;
            right = mid;
            mid = (left+right)/2;
            if(right == left)
                break;
        }

        if( !is_find ) {
//            cout << "don't catch" << endl;
            left = mid;
            mid = (left+right)/2;
            if( right-left == 1 )
                break;
        }
    }

//    cout << "min is : " << min << endl;
    ofs << min << endl;

    ifs.close();
    ofs.close();

//    clock_t stop = clock();
//    double elapsed = (double) (stop - start) / CLOCKS_PER_SEC;
//    printf("\nTime elapsed: %.5f\n", elapsed);
    return 0;
}
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

vector<bool> stack;

class Point {
    int x, y;
public:
    Point(void): x(0), y(0) {}
    Point(int xx, int yy): x(xx), y(yy) {}
    int length(const Point& cp) const { return static_cast<int>(ceil( sqrt(pow(x-cp.x, 2) + pow(y-cp.y, 2)) )); }
};

bool keepgoing(vector<Point>& vp, int sp, int mid) {
    vector<int> is;

    for(int i=1; i<vp.size(); ++i) {
        if( !stack[i] && i!=sp && vp[sp].length(vp[i]) <= mid) {
            stack[i] = true;
            is.push_back(i);
        }
    }

    if(is.size() == 0) {
        return false;
    } else if(is.back() == vp.size()-1) {
        throw mid;
    } else {
        for(int i=is.size()-1; i>=0; --i) {
            keepgoing(vp, is[i], mid);
        }
    }

    return false;
}

int main(void) {
    ifstream ifs("battery.inp");
    ofstream ofs("battery.out");

    vector<Point> stor;
    int N, Z, left, right, mid, min;

    ifs >> N >> Z;

    int x, y;

    stor.resize(N+2);
    stack.resize(N+2);

    stor[0] = Point(0, 0);
    for(size_t i=1; i<N+1; ++i) {
        ifs >> x >> y;
        stor[i] = Point(x, y);
    }
    stor[N+1] = Point(Z, Z);

    left  = 0;
    right = stor[0].length(stor[N+1]);
    mid   = static_cast<int>(ceil( sqrt(2*Z*Z) ));
    min   = Z;

    while(right-left != 1) {
        bool is_find = true;
        fill(stack.begin(),stack.end(),0);

        try {
            is_find = keepgoing(stor, 0, mid);
        } catch(int e) {
            min = e;
            right = mid;
        }

        if( !is_find ) {
            left = mid;
        }

        mid = (left+right)/2;
    }

    ofs << min;

    ifs.close();
    ofs.close();
    return 0;
}
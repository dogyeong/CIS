#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

vector<vector<int> > ingredient;
vector<int> idx, answer, min_sum(4,0);
int N, low_cost;

int find_greedy(int num) {
    int sum = 1;
    vector<int> next_index;
    idx.clear();
    for(int i=0; i<num+1; ++i) {
        idx.push_back(i);
        next_index.push_back(i+1);
    }
    for(int i=0; i<num+1; ++i)
        (sum *= N-i) /= i+1;

    for(int i=0; i<sum; ++i) {
        vector<int> stack(5,0);
        int j;
        for(j=0; j<num+1; ++j) {
            stack[0] += ingredient[idx[j]][0];
            stack[1] += ingredient[idx[j]][1];
            stack[2] += ingredient[idx[j]][2];
            stack[3] += ingredient[idx[j]][3];
            stack[4] += ingredient[idx[j]][4];
        }

        int k;
        for(k=0; k<4 && !(stack[k] < min_sum[k]); ++k) ;

        if(!(k<4)) return stack[4];

        idx[j-1]++;
        for(k=0; k<num+1; ++k) {
            int s;
            for(s=k+1; s<num+1 && !(idx[s]!=N-(num-s)); ++s) ;
            if(!(s<num+1)) {
                if(next_index[k] == N-(num-k)) {
                    if(k==0) return 0;
                    idx[k]      = next_index[k-1];
                    next_index[k] = idx[k]+1;
                } else {
                    idx[k]      = next_index[k]++;
                }
            }
        }
    }

    return 0;
}

void backtracking(int num) {
    int sum = 1;
    vector<int> next_index;
    idx.clear();
    for(int i=0; i<num+1; ++i) {
        idx.push_back(i);
        next_index.push_back(i+1);
    }
    for(int i=0; i<num+1; ++i)
        (sum *= N-i) /= i+1;

    for(int i=0; i<sum; ++i) {
        vector<int> stack(5,0);
        for(int j=0; j<num+1; ++j) {
            stack[0] += ingredient[idx[j]][0];
            stack[1] += ingredient[idx[j]][1];
            stack[2] += ingredient[idx[j]][2];
            stack[3] += ingredient[idx[j]][3];
            stack[4] += ingredient[idx[j]][4];
        }

        int k;
        for(k=0; k<4 && !(stack[k] < min_sum[k]); ++k) ;

        if(!(k<4)) {
            if(low_cost > stack[4]) {
                answer.clear();
                answer = idx;
                low_cost = stack[4];
            }
            else if(low_cost == stack[4]) {
                if(lexicographical_compare(idx.begin(), idx.end(), answer.begin(), answer.end()))
                    answer = idx;
            }
        }

        idx[num]++;
        for(k=0; k<num+1; ++k) {
            int s=k+1;
            for(; s<num+1 && !(next_index[s]!=N-(num-s)); ++s) ;
            if(!(s<num+1)) {
                if(next_index[k] == N-(num-k)) {
                    if(k==0) return ;
                    idx[k]      = next_index[k-1];
                    next_index[k] = idx[k]+1;
                } else {
                    idx[k]      = next_index[k]++;
                }
            }
        }

    }
    return ;
}

int main(void) {
    ifstream ifs("diet.inp");
    ofstream ofs("diet.out");
    ifs>>N;
    for(int i=0; i<4; ++i) ifs>>min_sum[i];
    for(int i=0; i<N; ++i) {
        vector<int> temp(5,0);
        for(int j=0; j<5; ++j)
            ifs>>temp[j];
        ingredient.push_back(temp);
    }

    int i;
    for(i=0; i<N && !((low_cost=find_greedy(i))!=0); ++i) ;

    answer = idx;
    for(; i<N; ++i) backtracking(i);

    for(i=0; i<answer.size(); ++i)
        ofs << answer[i]+1 << " ";
    ofs << endl;

    ifs.close();
    ofs.close();
    return 0;
}

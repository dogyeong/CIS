#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;
class Diet
{
public:
	Diet() {
		Protein = 0;
		Fat = 0;
		Sugar = 0;
		Vitamin = 0;
		Cost = 0;
	}
	~Diet() {
	}

	int Protein;
	int Fat;
	int Sugar;
	int Vitamin;
	int Cost;
	bool operator <(const Diet& other) {
		if (Protein < other.Protein&&
			Fat < other.Fat&&
			Sugar < other.Sugar&&
			Vitamin < other.Vitamin)
			return true;
		return false;
	}
	bool operator >(const Diet& other) {
		if (Protein > other.Protein&&
			Fat > other.Fat&&
			Sugar > other.Sugar&&
			Vitamin > other.Vitamin)
			return true;
		return false;
	}
	Diet& operator +(const Diet& other) {
		Protein += other.Protein;
		Fat += other.Fat;
		Sugar += other.Sugar;
		Vitamin += other.Vitamin;
		Cost += other.Cost;

		return *this;
	}
	Diet& operator -(const Diet& other) {
		Protein -= other.Protein;
		Fat -= other.Fat;
		Sugar -= other.Sugar;
		Vitamin -= other.Vitamin;
		Cost -= other.Cost;

		return *this;
	}
	Diet& operator =(const Diet& other) {
		Protein = other.Protein;
		Fat = other.Fat;
		Sugar = other.Sugar;
		Vitamin = other.Vitamin;
		Cost = other.Cost;

		return *this;
	}
	void clear() {
		Protein = 0;
		Fat = 0;
		Sugar = 0;
		Vitamin = 0;
		Cost = 0;
	}
	void print() {
		cout << "P : " << Protein << endl << "F : " << Fat << endl
			<<"S : " << Sugar << endl << "V : " << Vitamin << endl << "C : " << Cost << endl;
	}
};
int N;Diet Min;
Diet List[21];
Diet Optimal;
Diet Current;
bool Result[21];
bool Check[21];

bool checkNutrient(int, bool);
bool remainNutrient(int);
int main()

{
	ifstream Textin("diet.inp");
	ofstream Textout("diet.out");
	Textin >> N;
	Textin >> Min.Protein >> Min.Fat >> Min.Sugar >> Min.Vitamin;
	for (int i = 1; i <= N; i++) {
		Textin >> List[i].Protein >> List[i].Fat >> List[i].Sugar >> List[i].Vitamin >> List[i].Cost;
		Check[i] = false;
	}
	
	Optimal.Cost = 987654321;
	checkNutrient(1, true);
	Current = Current - List[1];
	checkNutrient(1, false);
	for (int i = 1; i <= N; i++) {
		if (Result[i] == true) {
			Textout << i << " ";
		}
	}
	Textin.close();
	Textout.close();
//	system("pause");
	return 0;
}

bool checkNutrient(int cur, bool inout)
{
	Check[cur] = inout;
	if (inout == true)
		Current = Current + List[cur];
	//cout << "current position : " << cur << "bool  :  " << inout << endl;
	//Current.print();
	if (cur == N) {
		if (Current > Min && Current.Cost < Optimal.Cost) {
			Optimal = Current;
			if (inout == true) Current = Current - List[cur];
			for (int i = 1; i <= N; i++) Result[i] = Check[i];
			return true;
		}
		else {
			if (inout == true) {
				Current = Current - List[cur];
				Check[cur] = false;
			}
		}
	}
	else {
		if (Current > Min && Current.Cost < Optimal.Cost) {
			Optimal = Current;
		//	cout << "check optimal ----------" << endl;
		//	Optimal.print();
			if (inout == true) Current = Current - List[cur];
			for (int i = 1; i <= N; i++) Result[i] = Check[i];
			return true;
		}
		if (!remainNutrient(cur + 1) || Current.Cost > Optimal.Cost) {
			//cout << "cant" << endl;
			//cout << "Current Cost : " << Current.Cost << "  Optimal Cost : " << Optimal.Cost << endl;
			//Current.print();
			if (inout == true) Current = Current - List[cur];
			Check[cur] = false;
			return false;
		}
		Diet c;
		c = Current;
		checkNutrient(cur + 1, true);
		Current = c;
		checkNutrient(cur + 1, false);
		Current = c;

		return false;
	}
	return true;
}

bool remainNutrient(int cur)
{
	Diet c;
	c = Current + c;
	for (int i = cur; i <= N; i++) {
		c = c + List[i];
		if (c > Min) return true;
	}
	
	return false;
}

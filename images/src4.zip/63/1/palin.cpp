#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;
bool check_a(string word)
{
    int i=0;
    int len = word.size();
    for(i = 0; i<(len/2); i++){
        if(!(word.at(i)==word.at(len-1-i))){
            break;
        }
    }
    if(!(i<(len/2)))    return true;
    else    return false;
}
int main()
{

    ifstream input("palin.inp");

    string word_number_s;

    getline(input, word_number_s);

    int word_number_i = atoi(word_number_s.c_str());
    cout<< word_number_i<<endl;

    string word_array[word_number_i];

    for(int i=0; i<word_number_i; i++){
        string s;
        getline(input,s);
        word_array[i]=s;
    }

    input.close();

    ofstream output("palin.out");
    int i, j;
    int result[word_number_i];
    for(i=0; i<word_number_i; i++){
        int len;
        len = word_array[i].length();
        int num;
        for(j = 0; j<(len/2); j++){
            if(!(word_array[i].at(j)==word_array[i].at(len-1-j))){
                string sub1;
                sub1=word_array[i];
                string sub2;
                sub2=word_array[i];
                if((check_a(sub1.erase(j,1))||check_a(sub2.erase(len-1-j,1))))
                    num=1;
                else
                    num=2;
                break;
            }
        }

        if(!(j<len/2)){
                result[i] = 1;
        }
        else{
            if(num==1)
                result[i]=2;
            else
                result[i]=3;
        }
        cout<<result[i];
    }
    for(i=0; i<word_number_i;i++){
        output<<result[i]<<endl;
    }
    output.close();
    return 0;
}

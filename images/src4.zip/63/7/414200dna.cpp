#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>

int cost[1001][1001];
int from[1001][1001];

#define SEQ 1
#define UP 2
#define LEFT 3
#define UPLEFT 4

using namespace std;

int main() {
	for (int i = 0; i < 1001; i++) {
		for (int j = 0; j < 1001; j++) {
			cost[i][j] = 0;
			from[i][j] = 0;
		}
	}
	string a, b;
	ifstream in("1.inp");
	ofstream out("dna.out");
	getline(in, a);
	getline(in, b);
	reverse(a.begin(), a.end());
	reverse(b.begin(), b.end());
	cost[0][0] = 0;
	int maxI = 0;
	int maxJ = 0;
	for (int i = 0; i < a.length(); i++) {
		for (int j = 0; j < b.length(); j++) {
			if (a[i] != b[j]) {
				cost[i][j] = 0;
				continue;
			}
			if (i > 0 && j > 0 && cost[i - 1][j - 1] != 0) {
				cost[i][j] = cost[i - 1][j - 1];
				from[i][j] = SEQ;
			}
			if (i > 0 && j > 1
				&& cost[i - 1][j - 2] != 0
				&& (cost[i - 1][j - 2] > cost[i][j] || (cost[i - 1][j - 2] == cost[i][j] && b[j - 2] < b[j - 1]))) {
				cost[i][j] = cost[i - 1][j - 2];
				from[i][j] = LEFT;
			}
			if (i > 1 && j > 0
				&& cost[i - 2][j - 1] != 0
				&& (cost[i - 2][j - 1] > cost[i][j] || (cost[i - 2][j - 1] == cost[i][j] && a[i - 2] < a[i - 1]))) {
				cost[i][j] = cost[i - 2][j - 1];
				from[i][j] = UP;
			}
			if (i > 1 && j > 1
				&& cost[i - 2][j - 2] != 0
				&& (cost[i - 2][j - 2] > cost[i][j] || (cost[i - 2][j - 2] == cost[i][j] && a[i - 2] < a[i - 1]))) {
				cost[i][j] = cost[i - 2][j - 2];
				from[i][j] = UPLEFT;
			}
			cost[i][j]++;
			if (cost[i][j] > cost[maxI][maxJ] || (cost[i][j] == cost[maxI][maxJ] && a[i] < a[maxI])) {
				maxI = i;
				maxJ = j;
			}
		}
	}
	int i = maxI;
	int j = maxJ;
	string end;
	while (true) {
		end += a[i];
		if (from[i][j] == SEQ) {
			i--;
			j--;
		}
		else if (from[i][j] == UP) {
			i -= 2;
			j--;
		}
		else if (from[i][j] == LEFT) {
			i--;
			j -= 2;
		}
		else if (from[i][j] == UPLEFT) {
			i -= 2;
			j -= 2;
		}
		else {
			break;
		}
	}
	
	in.close();
	out.close();
	out << end;


	return 0;
}
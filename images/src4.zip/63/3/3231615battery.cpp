#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

class Point {
public:
	int x;
	int y;
	Point() {
		x = 0;
		y = 0;
	}
	Point(int a, int b) {
		x = a;
		y = b;
	}
	Point(const Point& p) {
		x = p.x;
		y = p.y;
	}
	int getX() {
		return x;
	}
	int getY() {
		return y;
	}
	bool check(Point p) {
		return (x == p.x&&y == p.y);
	}
	int dis(Point a) {
		return floor(sqrt((a.x- x)*(a.x-x) + (a.y - y)*(a.y - y)));
	}
};


bool shortestLength(Point start, Point end, vector<Point> points, int len)
{
	vector<Point> point;
	for (int i = 0; i < points.size(); i++) {
		point.push_back(points[i]);
	}
	int size = point.size();
	queue<Point> q;
	
	q.push(start);
	while (!(q.empty())) {
		Point p = q.front();

		q.pop();
		int i = 0;
		while (i < size) {
			if (point[i].dis(p) <= len) {
				if (point[i].check(end)) {
					return true;
				}
				else {
					q.push(point[i]);
					point.erase(point.begin() + i);
					i = i - 1;
					size = point.size();
				}
			}
			i++;
		}
	}
	return false;
}

int main()
{
	ifstream input("battery.inp");
	ofstream output("battery.out");
	
	vector<Point> points;

	int x, y;
	int count;
	input >> count >> x;

	Point end(x,x);
	
	Point start(0, 0);
	for (int i = 0; i < count; i++) {
		input >> x >> y;
		Point p(x, y);		
		points.push_back(p);
	}
	points.push_back(end);
	int len;
	for (len = 1; len < end.dis(end); len++) {
		if ((shortestLength(start, end, points, len))) {
			break;
		}
	}
	output << len;
	input.close();
	output.close();

	return 0;
}
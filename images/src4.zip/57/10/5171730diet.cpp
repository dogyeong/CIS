#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

int num, mp, mf, ms, mv, mincost, tt, subsetn, result;
int **item, remain[4], current[5], *itemcheck, *subsetcheck, *cost;
string *subset, *vertemp, suba;

void print_diet() {
    ofstream ofile("diet.out", ios_base::out);

    for(int i = 0; i < vertemp[result].length(); i++) {
        for(int j = 0; j < num; j++) {
            if(vertemp[result][i] == j+49) ofile << j+1 << " ";
        }
    }

    ofile.close();
}

void con_ct(int ver_n, int sublen) {
    if(ver_n == num) {
        for(int i = 0; i < sublen; i++) {
            vertemp[tt] += subset[i];
        }
        tt++;
        return;
    }
    else {
        con_ct(ver_n+1, sublen);
        subset[sublen++] = suba[ver_n];
        con_ct(ver_n+1, sublen);
    }
}

bool is_right() {
    if(mp <= current[0] && mf <= current[1] && ms <= current[2] && mv <= current[3]) return true;
    else return false;
}

void diet() {

    for(int i = 0; i < subsetn; i++) {
        for(int j = 0; j < vertemp[i].length(); j++) {
            for(int k = 0; k < num; k++) {
                if(vertemp[i][j] == k+49) {
                    itemcheck[k] = 1;
                    for(int l = 0; l < 5; l++) {
                        current[l] += item[k][l];
                    }
                }
            }
        }
        if(is_right() == true) {
                subsetcheck[i] = 1;
                cost[i] = current[4];
        }
        for(int a = 0; a < num; a++) {
            itemcheck[a] = 0;
        }
        for(int a = 0; a < 5; a++) {
            current[a] = 0;
        }
    }

    int resultcost = 999999;

    for(int i = 0; i < subsetn; i++) {
        if(subsetcheck[i] == 1) {
            if(cost[i] < resultcost) {
                resultcost = cost[i];
                result = i;
            }
        }
    }

    print_diet();
}

int main()
{
    ifstream ifile("diet.inp", ios_base::in);

    ifile >> num >> mp >> mf >> ms >> mv;

    remain[0] = mp;
    remain[1] = mf;
    remain[2] = ms;
    remain[3] = mv;

    item = new int*[num];
    for(int i = 0; i < num; i++) {
        item[i] = new int[5];
    }

    itemcheck = new int[num];

    for(int i = 0; i < num; i++) {
        itemcheck[i] = 0;
    }

    for(int i = 0; i < num; i++) {
        for(int j = 0; j < 5; j++) {
            ifile >> item[i][j];
        }
    }

    for(int i = 0; i < num; i++) {
        mincost += item[i][4];
    }

    subset = new string[num];
    subsetn = pow(2, num);
    vertemp = new string[subsetn];

    subsetcheck = new int[subsetn];
    cost = new int[subsetn];

    for(int i = 0; i < subsetn; i++) {
        subsetcheck[i] = 0;
    }

    for(int i = 0; i < num; i++) {
        suba += i + 49;
    }

    con_ct(0,0);

    diet();

    ifile.close();

    return 0;
}

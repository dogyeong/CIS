#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>

int z;
double w, wmax, wmin;

using namespace std;

class Point {
public :
    int x;
    int y;

    Point() {
        x = 0;
        y = 0;
    }

    Point(int a, int b) {
        x = a;
        y = b;
    }

    void setpoint(int a, int b) {
        x = a;
        y = b;
    }
};

double distance(Point a, Point b) {
    return sqrt(pow(abs(b.x - a.x), 2) + pow(abs(b.y - a.y), 2));
}

bool compare(Point a, Point b) {
    Point t;
    return distance(t, a) < distance(t, b);
}

void way(double w, Point point[], int n, bool check[], int start) {
    check[start] = 1;

    for(int i = 0; i < n; i++) {
        if(distance(point[start], point[i]) <= w && check[i] == 0) {
            way(w, point, n, check, i);
        }
    }
    return;
}

double battery(double w, Point point[], int n) {
    bool* check = new bool[n]();

    way(w, point, n, check, 0);

    while(ceil(wmin) != ceil(wmax)) {
        if(check[n-1] == 1) {
            wmax = w;
            w = (wmax + wmin)/2;
            delete[] check;
            battery(w, point, n);
        }
        else {
            wmin = w;
            w = (wmin + wmax)/2;
            delete[] check;
            battery(w, point, n);
        }
    }
}

int main()
{
    int n = 0, a = 0, b = 0;

    ifstream ifile("battery.inp", ios_base::in);
    ofstream ofile("battery.out", ios_base::out);

    ifile >> n >> z;

    Point point[n+2], pstart, pend(z, z);

    w = distance(pstart, pend);
    wmax = w;
    wmin = 0;

    point[0] = pstart;

    for(int i = 1; i < n; i++) {
        ifile >> a >> b;
        point[i].setpoint(a,b);
    }

    point[n+1] = pend;

    sort(point, point+n+2, compare);

    w = battery(w, point, n+2);

    ofile << ceil(w);

    return 0;
}

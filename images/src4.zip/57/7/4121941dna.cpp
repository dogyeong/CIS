#include <iostream>
#include <fstream>

using namespace std;

int lss[1002][1002], sts[1002][1002];

string strmax(string a, string b) {
    if(a.length() > b.length()) return a;
    else if(a.length() < b.length()) return b;
    else if(a.length() == b.length()) return min(a, b);
}

int main()
{
    ifstream ifile("dna.inp", ios_base::in);

    string str1 , str2, str3;

    ifile >> str1 >> str2;

    int row = str1.length(), col = str2.length();

    for(int i = 0; i < row+2; i++) {
        for(int j = 0; j < col+2; j++) {
            lss[i][j] = 0;
            sts[i][j] = 0;
        }
    }

    for(int i = 0; i < row; i++) {
        for(int j = 0; j < col; j++) {
            int x = max(sts[i][j], sts[i+1][j+1]), y = max(sts[i][j+1], sts[i+1][j]);
            x = max(x, y);
            if(str1[i] == str2[j]) {
                x++;
                sts[i+2][j+2] = x;
            }
        }
    }

    for(int i = 0; i < row; i++) {
        for(int j = 0; j < col; j++) {
            int x, l, k, m;
            x = max(lss[i][j], lss[i+1][j+1]);
            m = max(lss[i][j+1], lss[i+1][j]);
            x = max(x, m);
            if(str1[i] == str2[j] && ((i == 0 || j == 0) || (lss[i][j] == 0 && lss[i+1][j+1] == 0) || (str1[i-2] == str2[j-2] || str1[i-2] == str2[j-1] || str1[i-1] == str2[j-2] || str1[i-1] == str2[j-1]))) {
                x++;
            }
            l = max(lss[i][j+2], lss[i+1][j+2]);
            k = max(lss[i+2][j], lss[i+2][j+1]);
            l = max(l, k);
            lss[i+2][j+2] = max(l, x);
        }
    }

    int maxsts = 0;
    for(int i = 0; i < row+2; i++) {
        for(int j = 0; j < col+2; j++) {
            maxsts = max(maxsts, sts[i][j]);
        }
    }
    int rt = 0, ct = 0;
    for(int i = row+2; i >= 0; i--) {
        for(int j = col+2; j >= 0; j--) {
            if(sts[i][j] == maxsts) {
                rt = i;
                ct = j;
                break;
            }
        }
        if(rt != 0 || ct != 0) break;
    }

    int go = maxsts;
    int r = rt, c = ct;
    while(go-1 > 0) {
        int x = max(sts[r-2][c-2], sts[r-1][c-1]), y = max(sts[r-2][c-1], sts[r-1][c-2]);
        x = max(x, y);
        string temp1 = "", temp2 = "";
        if(sts[r][c] == maxsts) {
            str3 = str1[r-2] + str3;
        }
        if(sts[r][c] == go && x == go-1) {
            for(int i = 1; i <= 2; i++) {
                for(int j = 1; j <= 2; j++) {
                    if(sts[r-i][c-j] == go-1) {
                            temp2 = str1[r-i-2];
                            temp1 = strmax(temp1,temp2);
                    }
                }
            }
            str3 = temp1 + str3;
            go--;
            r--;
            c--;
        }
        else if(sts[r][c-1] == go) {
            c--;
        }
        else if(sts[r-1][c] == go) {
            r--;
        }
        else if(sts[r-1][c+1] == go) {
            r--;
            c++;
        }
        else {
            if(sts[r-1][c-1] == go) {
                r--;
                c--;
            }
            else if(sts[r-1][c-2] == go) {
                r--;
                c -= 2;
            }
            else if(sts[r-2][c-1] == go) {
                r -= 2;
                c--;
            }
            else if(sts[r-2][c-2] == go) {
                r -= 2;
                c -= 2;
            }
        }
    }

    ofstream ofile("dna.out", ios_base::out);

    ofile << str3;

    return 0;
}

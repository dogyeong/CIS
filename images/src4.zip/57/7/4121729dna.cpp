#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream ifile("dna.inp", ios_base::in);

    string str1 , str2, str3;

    ifile >> str1 >> str2;

    int lss[str1.length()+2][str2.length()+2], sts[str1.length()+2][str2.length()+2];

    for(int i = 0; i < str1.length()+2; i++) {
        for(int j = 0; j < str2.length()+2; j++) {
            lss[i][j] = 0;
            sts[i][j] = 0;
        }
    }

    for(int i = 0; i < str1.length(); i++) {
        for(int j = 0; j < str2.length(); j++) {
            int x, l, k, m;
            x = max(lss[i][j], lss[i+1][j+1]);
            if(str1[i] == str2[j]) {
                sts[i+2][j+2] = 1;
                x = x + 1;
            }
            l = max(lss[i][j+2], lss[i+1][j+2]);
            k = max(lss[i+2][j], lss[i+2][j+1]);
            m = max(lss[i][j+1], lss[i+1][j]);
            l = max(l, k);
            l = max(l, m);
            lss[i+2][j+2] = max(l, x);
        }
    }
    int r = str1.length()+1, c = str2.length()+1, go = lss[str1.length()+1][str2.length()+1], rt, ct, got;
    while(lss[r][c] > 0) {
        if(lss[r][c] == lss[r][c-1]) {
            c--;
        }
        else if(str1[r-2] != str2[c-2]) {
            r--;
        }
        else if(str1[r-2] == str2[c-2]) {
            str3 = str1[r-2] + str3;
            r--;
            c--;
        }
    }

    ofstream ofile("dna.out", ios_base::out);

    ofile << str3;

    return 0;
}

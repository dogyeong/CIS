#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream ifile("dna.inp", ios_base::in);

    string str1 , str2, str3;

    ifile >> str1 >> str2;

    int lss[str1.length()+2][str2.length()+2], sts[str1.length()+2][str2.length()+2];

    for(int i = 0; i < str1.length()+2; i++) {
        for(int j = 0; j < str2.length()+2; j++) {
            lss[i][j] = 0;
            sts[i][j] = 0;
        }
    }

    for(int i = 0; i < str1.length(); i++) {
        for(int j = 0; j < str2.length(); j++) {
            int x = max(sts[i][j], sts[i+1][j+1]), y = max(sts[i][j+1], sts[i+1][j]);
            x = max(x, y);
            if(str1[i] == str2[j]) {
                x++;
                sts[i+2][j+2] = x;
            }
        }
    }

    for(int i = 0; i < str1.length(); i++) {
        for(int j = 0; j < str2.length(); j++) {
            int x, l, k, m;
            x = max(lss[i][j], lss[i+1][j+1]);
            m = max(lss[i][j+1], lss[i+1][j]);
            x = max(x, m);
            if(str1[i] == str2[j]) {
                x = x + 1;
            }
            l = max(lss[i][j+2], lss[i+1][j+2]);
            k = max(lss[i+2][j], lss[i+2][j+1]);
            l = max(l, k);
            lss[i+2][j+2] = max(l, x);
        }
    }

    int r = str1.length()+1, c = str2.length()+1, go = lss[str1.length()+1][str2.length()+1], rt, ct, got;
    while(lss[r][c] > 0) {
        int x = max(sts[r-2][c-2], sts[r-1][c-1]), y = max(sts[r-2][c-1], sts[r-1][c-2]);
        x = max(x, y);
        if(sts[r][c] == go && x == go-1) {
            str3 = str1[r-2] + str3;
            go--;
            r--;
            c--;
        }
        else if(sts[r][c-1] == go) {
            c--;
        }
        else if(sts[r-1][c] == go) {
            r--;
        }
        else if(lss[r][c] == go && lss[r][c-1] == go) {
            c--;
        }
        else if(lss[r][c] == go && lss[r-1][c] == go) {
            r--;
        }
        else if(lss[r][c] == go && lss[r-1][c+1] == go) {
            r--;
            c++;
        }
    }

    ofstream ofile("dna.out", ios_base::out);

    ofile << str3;

    return 0;
}

#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

int main() {

    ifstream ifile("palin.inp", ios_base::in);
    ofstream ofile("palin.out", ios_base::out);
    int n = 0, strn = 0, ssum = 0, ptf = 0;
    char str[10000];

    ifile >> n;

    for(int i = 0; i < n; i++) {
        ssum = 0;
        ptf = 0;
        ifile >> str;
        strn = strlen(str);
        for(int j = 0; j < strn; j++) {
            if(str[j] == str[strn - j - 1]) {ssum++;}
            else if(j == 0) {
                if(str[j] == str[strn - j - 2]) {
                    for(int k = 0; k < strn - 1; k++) {
                        if(str[k] != str[strn - k - 2]) {break;}
                    }
                    ptf = 1;
                }
                else if(str[j + 1] == str[strn - j - 1]) {
                    for(int l = 1; l < strn; l++) {
                        if(str[l] != str[strn - l - 1]) {break;}
                    }
                    ptf = 1;
                }
            }
            else {
                if(str[j] == str[strn - j - 2]) {
                    for(int k = j; k < strn - j - 1; k++) {
                        if(str[k] != str[strn - k - 2]) {break;}
                    }
                    ptf = 1;
                }
                else if(str[j + 1] == str[strn - j - 1]) {
                    for(int l = j; l < strn - j; l++) {
                        if(str[l] != str[strn - l - 1]) {break;}
                    }
                    ptf = 1;
                }
                else {break;}
            }
        }
        if(ssum == strn) {ofile << 1 << endl;}
        else if(ptf == 1) {ofile << 2 << endl;}
        else {ofile << 3 << endl;}
    }

    ifile.close();
    ofile.close();

    return 0;
}

#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

int main() {

    ifstream ifile("palin.inp", ios_base::in);
    ofstream ofile("palin.out", ios_base::out);
    int n = 0, strn = 0, ssum = 0, ptf = 0, np = 0;
    char str[10000];

    ifile >> n;

    for(int i = 0; i < n; i++) {
        ssum = 0;
        ptf = 0;
        np = 0;
        ifile >> str;
        strn = strlen(str);
        for(int j = 0; j < strn; j++) {
            if(str[j] == str[strn - j - 1]) {ssum++;}
            else if(j == 0) {
                if(str[j] == str[strn - j - 2]) {
                    for(int k = 0; k < strn - 1; k++) {
                        if(str[k] != str[strn - k - 2]) {np = 1; break;}
                    }
                    ptf = 1;
                    break;
                }
                else if(str[j + 1] == str[strn - j - 1]) {
                    for(int l = 0; l < strn - 1; l++) {
                        if(str[l + 1] != str[strn - l - 1]) {np = 1; break;}
                    }
                    ptf = 1;
                    break;
                }
            }
            else if(j != 0) {
                if(str[j] == str[strn - j - 2]) {
                    for(int k = j; k < strn - j - 1; k++) {
                        if(str[k] != str[strn - k - 2]) {np = 1; break;}
                    }
                    ptf = 1;
                    break;
                }
                else if(str[j + 1] == str[strn - j - 1]) {
                    for(int l = j; l < strn - j - 1; l++) {
                        if(str[l + 1] != str[strn - l - 1]) {np = 1; break;}
                    }
                    ptf = 1;
                    break;
                }
                else {break;}
            }
        }
        if(ssum == strn) {ofile << 1 << endl;}
        else if(ptf == 1 && np != 1) {ofile << 2 << endl;}
        else {ofile << 3 << endl;}
    }

    ifile.close();
    ofile.close();

    return 0;
}

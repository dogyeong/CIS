#include <iostream>
#include <fstream>
#include <list>
#include <vector>
#include <algorithm>
#include <stack>
#include <cmath>

using namespace std;

class Point{
	public:
		int x;
		int y;
		list <int> nearby;
		
		Point(int X, int Y);
};

Point::Point(int X, int Y){
	x = X;
	y = Y;
}

void printEle(int a){
	cout << a << " ";
}

int movable(int weight, vector<Point>& station){
	int n = station.size(), k, t;
	stack <int> stack;
	int* dl_flag = new int[n]();
//	for(int i=0; i<n; i++){
//		cout << dl_flag[i] << endl;
//	}
	
	for(int i=0; i<n; i++){
		for(int j=0; j<n; j++){
			if(i == j) continue;
			if((station[i].x-station[j].x)*(station[i].x-station[j].x) + (station[i].y-station[j].y)*(station[i].y-station[j].y) <= weight*weight){
				(station[i].nearby).push_back(j);
			}
			
		}
	}
	
//	for(int i=0; i<n; i++){
//		list<int>::iterator it;
//		cout << i << " "; 
//		for(it=(station[i].nearby).begin(); it!=(station[i].nearby).end(); it++){
//			cout << (*it) << " ";
//		}
//		cout << endl;
//	}
//	cout << endl;
	
	list<int>::iterator it;
	
	stack.push(0);
	dl_flag[0] = 1;
	while(!stack.empty()){
		k = stack.top();
		if(k == n-1){
			return 1;
		}
		stack.pop();
		
		//dl_flag[k] = 0;
		//cout << k << endl;
		for(it=(station[k].nearby).begin(); it!=(station[k].nearby).end(); it++){
			t = *it;
			if(dl_flag[t] == 1){
				continue;
			}
			stack.push(t);
			dl_flag[t] = 1;
		}
	}
	return 0;
//	for(int i=0; i<n; i++){
//		stack.push(i);
//		while(!stack.empty()){
//			k = stack.top();
//			if(k == )
//			stack.pop();
//			
//			for(it=(station[k].nearby).begin(); it!=(station[k].nearby).end(); it++){
//				stack.push(*it);
//			}
//		}
//	}
}

int main(){
	ifstream fp;
	ofstream fp2;
	fp2.open("battery.out")
	int n, z, x, y, w, upmost=1000, least=0;
	fp.open("battery.inp");
	fp >> n >> z;
	vector<Point> station;
	
	Point S(0,0);
	station.push_back(S);
	for(int i=0; i<n; i++){
		fp >> x >> y;
		Point P(x, y);
		station.push_back(P);
	}
	Point T(z, z);
	station.push_back(T);
	/*for(int i=0; i<n; i++){
		cout << "P[" << i << "] " <<  station[i].x << " " << station[i].y << endl;
	}*/
	//for(int i=0; i<14; i++)
	
	w = 100;
	while(!movable(w, station)){
		w++;
	}
	//cout << w;
	fp2 >> w;
	
}

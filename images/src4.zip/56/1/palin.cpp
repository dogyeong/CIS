#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int isPalin(string str){
	int len;
	string::iterator start, end;
	len = str.size();
	start = str.begin();
	end = str.end();
	end--;
	for(int i=0; i<len/2; i++){
		if(*start != *end){
			return 0;
		}
		start++;
		end--;
	}
	return 1;
}

int isPseudo(string str){
	int len;
	string::iterator start, end;
	char buf;
	len = str.size();
	start = str.begin();
	end = str.end();
	end--;
	while(*start == *end){
		start++;
		end--;
	}
	buf = *start;
	str.erase(start);
	if( isPalin(str) ){
		return 1;
	}
	str.insert(start, buf);
	str.erase(end);
	if( isPalin(str) ){
		return 1;
	}
	return 0;
}

int main(){
	ifstream fp;
	ofstream fp2;
	int N;
	string str;
	
	fp.open("palin.inp");
	fp2.open("palin.out");
	fp >> N;
	
	for(int i=0; i<N; i++){
		fp >> str;
		if( isPalin(str) )
			fp2 << 1 << endl;
		else if( isPseudo(str) )
			fp2 << 2 << endl;
		else
			fp2 << 3 << endl;
	}
	
	fp.close();
	fp2.close();
	return 0;
}

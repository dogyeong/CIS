#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void DecToBin(int, int *, int);
int permutation(int);

int main(){
	ifstream fp;
	ofstream fp2;
	int k, pmt, minP, minF, minC, minV, prt, ft, crb, vit, prc, total_prt, total_ft, total_crb, total_vit, total_prc, best_diet, least_price;
	int *diet;
	vector <int> protein;
	vector <int> fat;
	vector <int> carbonhyd;
	vector <int> vitamin;
	vector <int> price;
	
	fp.open("diet.inp");
	fp >> k >> minP >> minF >> minC >> minV;
	diet = new int[k];
	for(int i=0; i<k; i++){
		fp >> prt >> ft >> crb >> vit >> prc;
		protein.push_back(prt);
		fat.push_back(ft);
		carbonhyd.push_back(crb);
		vitamin.push_back(vit);
		price.push_back(prc);
	}
	fp.close();
	
	pmt = permutation(k);
	best_diet = pmt - 1;
	least_price = 0;
	for(int i=0; i<k; i++)
		least_price += price[i];
	
	for(int i=1; i<pmt; i++){
		total_prt = 0;
		total_ft  = 0;
		total_crb = 0;
		total_vit = 0;
		total_prc = 0;
		DecToBin(i, diet, k);
		for(int j=0; j<k; j++){
			if(diet[j] == 1){
				total_prt += protein[j];
				total_ft  += fat[j];
				total_crb += carbonhyd[j];
				total_vit += vitamin[j];
				total_prc += price[j];
			}
		}
		if(total_prt < minP || total_ft < minF || total_crb < minC || total_vit < minV)
			continue;
		if(total_prc <= least_price){
			best_diet = i;
			least_price = total_prc;
		}
	}
	
	fp2.open("diet.out");
	DecToBin(best_diet, diet, k);
	for(int i=0; i<k; i++)
		if(diet[i] == 1)
			fp2 << i+1 << " ";
	fp2.close();
	delete[] diet;
	
	return 0;
}

void DecToBin(int i, int *diet, int k){
	int rem;
	k--;
	while(i != 1){
		rem = i % 2;
		i = i / 2;
		diet[k--] = rem;
	}
	diet[k] = 1;
	while(k != 0)
		diet[--k] = 0;
}

int permutation(int k){
	int pmt = 1;
	for(int i=0; i<k; i++)
		pmt *= 2;
	return pmt;
}

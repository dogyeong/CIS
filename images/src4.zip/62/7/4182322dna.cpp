#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <array>
using namespace std;

string longestCommonSubstring_n2_n2(const string& str1, const string& str2)
{
    size_t size1 = str1.size();
    size_t size2 = str2.size();
    if (size1 == 0 || size2 == 0) return 0;

    vector<vector<int> > table(size1, vector<int>(size2, 0));
    int start1 = -1;
    int start2 = -1;
    int longest = 0;
    table[0][0] = (str1[0] == str2[0] ? 1 : 0);
    table[1][0] = (str1[1] == str2[0] ? 1 : 0);
    for (int j = 1; j < size2; ++j)
    {
        table[0][j] = (str1[0] == str2[j] ? 1 : 0);
        table[1][j] = (str1[1] == str2[j] ? table[0][j-1]+1 : 0);
    }

    for (int i = 2; i < size1; ++i)
    {
        table[i][0] = (str1[i] == str2[0] ? 1 :0);
        table[i][1] = (str1[i] == str2[1] ? table[i-1][0]+1 : 0);
        for (int j = 2; j < size2; ++j)
        {
            if (str1[i] == str2[j])
            {
            	int tmp[4] =  { table[i-1][j-1], table[i-2][j-1],
            					table[i-1][j-1], table[i-2][j-2] };
                sort(tmp, tmp+4);
				table[i][j] = tmp[3]+1;
            }
        }
    }

     string dna = "";

    for (int i = 2; i < size1; ++i)
    {
        for (int j = 2; j < size2; ++j)
        {
            if (longest <= table[i][j])
            {
                longest = table[i][j];
                int si = i;
                int sj = j;
                string tmpStr = "";
                tmpStr.push_back(str1[si]);
                ////cout << "(" << si << "," << sj << ") " << tmpStr << "\n";
                for(int k=1; k<longest; ++k){
                    if(table[si-1][sj-1] == longest-k){ si=si-1; sj=sj-1;}
                    else if(table[si-1][sj-2] == longest-k){ si=si-1; sj=sj-2; }
                    else if(table[si-2][sj-1] == longest-k){ si=si-2; sj=sj-1; }
                    else if(table[si-2][sj-2] == longest-k){ si=si-2; sj=sj-2; }
                    tmpStr.push_back(str1[si]);
                    ////cout << "(" << si << "," << sj << ") " << tmpStr << "\n";
                }
                reverse(tmpStr.begin(), tmpStr.end());
                if(longest > dna.size()) dna = tmpStr;
                else if(longest == dna.size())
                    dna = tmpStr < dna ? tmpStr : dna;

                ////cout << endl;
            }

        }
    }

//#define IDER_DEBUG
#ifdef IDER_DEBUG
    for(int i=0; i < size1; ++i){
		for(int j=0; j < size2; ++j){
			//cout << table[i][j] << " ";
		}
		//cout << endl;
	}
#endif

    return dna;
}

int main(void){

    string str1, str2;
    ifstream ifs("dna.inp");

    ifs >> str1 >> str2;

    ifs.close();
    ofstream ofs("dna.out");

	ofs << longestCommonSubstring_n2_n2(str1,str2);
    ofs.close();
    return 0;
}

#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
using namespace std;


double distance(int x1, int y1, int x2, int y2){
    return sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
}

bool search_nodes(queue<int>& Qx, queue<int>& Qy, vector<int>& Px, vector<int>& Py, double battery, int z)
{
    int d;
    vector<int>::iterator px = Px.begin();
    vector<int>::iterator py = Py.begin();

    while(px != Px.end()){
        d = distance(Qx.front(), Qy.front(), *px, *py);
        if( d < battery ){
            Qx.push(*px); Qy.push(*py);
            Px.erase(px); Py.erase(py);
        }
        else{
        	px++; py++;
		}
    }
    Qx.pop(); Qy.pop();
    if(Qx.empty()) return false;
    if(Qx.back() == z && Qy.back() == z) return true;	
	return search_nodes(Qx,Qy,Px,Py,battery,z);
}


int main(void){

    ifstream ifs("battery.inp");
    if(!ifs.is_open()){
        cerr << "Input File Error" << endl;
        return -1;
    }

    int n, z;
    ifs >> n >> z;

    vector<int> Px;
    vector<int> Py;

    int tx, ty;
    while(ifs >> tx >> ty){
        Px.push_back(tx);
        Py.push_back(ty);
    }
    Px.push_back(z);
    Py.push_back(z);

    vector<int> X;
    vector<int> Y;

    int d = 0;
    double battery = sqrt(z*z/2.0);
    double b = battery;
    
    while( !(floor(b) == floor(b-battery) && floor(b) == floor(b+battery)) ){
        queue<int> Qx; queue<int> Qy;
        Qx.push(0); Qy.push(0);
        X = Px; Y = Py;
        battery = battery / 2.0;
        if(search_nodes(Qx,Qy,X,Y,b,z)){
            b = b - battery;
        }
        else{
            b = b + battery;
        }
	}

	ofstream ofs("battery.out");
    if(!ofs.is_open()){
        cerr << "Output File Error" << endl;
       	return -1;
    }
    
    ofs << ceil(b);
    return 0;
}

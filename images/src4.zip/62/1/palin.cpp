#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <iterator>

using namespace std;

bool isPalin(string s){
    int len = s.length();

    for(int i=0; i < len/2; ++i ){
        if(s[i] != s[len-i-1])
            return false;
    }
    return true;
}

bool isPseudopalin(string s){
    int len = s.length();

    for(int i=0; i < len; ++i ){
        string temps = s;
        temps.erase(i,1);
        if(isPalin(temps))
            return true;
    }
    return false;
}


int main(void){

    ifstream ifs("palin.inp");
	if (!ifs.is_open()) {
		cerr << "Input File Error" << endl;
		return -1;
	}

    int N;

    ifs >> N;

    ofstream ofs("palin.out");
	if (!ofs.is_open()) {
		cerr << "Output File Error" << endl;
		return -1;
	}

    for(int i = 0; i < N; ++i){
        string tempstring;
        ifs >> tempstring;
        if(isPalin(tempstring))
                ofs << '1' << endl;
        else if(isPseudopalin(tempstring))
                ofs << '2' << endl;
        else
                ofs << '3' << endl;
    }

    ifs.close();
    ofs.close();
    return 0;

}

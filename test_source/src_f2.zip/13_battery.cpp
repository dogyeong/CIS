#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <queue>
#include <vector>

using namespace std;

class point {
public:
    int x = 0, y = 0;
    point( int _x, int _y ) {
        x = _x;
        y = _y;
    };
};

vector<point> list;

bool isRange(point a, point b, int distance) {
    if ( sqrt(pow(a.x-b.x, 2)+pow(a.y-b.y, 2)) <= distance )
        return true;
    else
        return false;
}

bool bfs(queue<point> que, int dist, int visit[], int max) {
    queue<point> next;
    while ( !que.empty() ) {
        point tmp = que.front(); que.pop();
        for ( int i = 0; i < list.size(); i++ ) {
            if ( abs(list[i].x-tmp.x) <= dist ) {
                if ( visit[i] == 0 && isRange(tmp, list[i], dist) ) {
                    visit[i] = 1;
                    next.push(list[i]);
                    if ( list[i].x == max && list[i].y == max )
                        return true;
                }
            } else if ( list[i].x-tmp.x > dist )
                break;
        }
    }
    if ( next.empty() )
        return false;
    
    return bfs(next, dist, visit, max);
}

bool compare(point a, point b) {
    return a.x < b.x;
}

int main() {
    
    ifstream ifs("battery.inp");
    if(!ifs.is_open()){
        cerr << "Error" <<endl;
        return -1;
    }
    
    ofstream ofs("battery.out");
    
    int num, max;
    ifs >> num >> max;
    
    
    list.push_back(point(0 ,0));
    for ( int i = 0; i < num; i++ ) {
        int x, y;
        ifs >> x >> y;
        list.push_back(point(x, y));
    }
    list.push_back(point(max, max));
    sort(list.begin(), list.end(), compare);
    
    int d_min = 1, d_max = 100000, d_mid = 0;
    int visit[list.size()];
    while ( d_min < d_max ) {
        d_mid = (d_min+d_max)/2;
        
        fill_n(visit, list.size(), 0);
        queue<point> que;
        que.push(list[0]);
        if ( bfs(que, d_mid, visit, max) )
            d_max = d_mid;
        else
            d_min = d_mid+1;
    }
    ofs << d_min;
    
    ifs.close();
    ofs.close();
    
    return 0;
}

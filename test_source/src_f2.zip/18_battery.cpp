#include <iostream>
#include <utility>
#include <queue>
#include <vector>
#include <fstream>

using namespace std;

vector<pair<int, int> > adj;

int d(int i, int j) {
	return (adj[i].first - adj[j].first) * (adj[i].first - adj[j].first) + (adj[i].second - adj[j].second) * (adj[i].second - adj[j].second);
}

bool bfs(int mid, int dst){
    queue<int> q;
    q.push(0);
    vector<bool> visited(adj.size(), false);
    visited[0] = true;
    
    while(!q.empty()){
        int x = q.front();
        q.pop();
        if(adj[x].first == dst && adj[x].second == dst) return true;
        for(int i = 0 ; i < adj.size(); ++i) {
        	if((d(x, i) <= mid) && visited[i] == false) {
        		q.push(i);
        		visited[i] = true;
			}
		}
    }
    return false;
}


int main(void)
{
   int n, dst;
   
   ifstream inFile("battery.inp");
   ofstream outFile("battery.out");
   
   inFile >> n >> dst;
   adj.emplace_back(0,0);
   for(int i=0; i<n; i++){
   		int x, y;
      inFile >> x >> y;
      adj.emplace_back(x, y);
   }
   adj.emplace_back(dst, dst);
    int lo = 1, hi = 20000;
	
	while(lo <= hi) {
		int mid = (lo + hi) / 2;
		if(bfs(mid * mid, dst)) {
			hi = mid - 1;
		}
		else {
			lo = mid + 1;
		}
	} 
	outFile << lo <<endl;
	outFile.close();
	inFile.close();
	
	return 0;
}

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <cmath>
using namespace std;




int *DFS(queue<int> DFS_,vector<vector<int>> distance_,int n,double w,int k,int visit[]){
        int i;
        for (i=1; i<n+2; i++)
            visit[i]=0;
        while(DFS_.empty()){
            w = w+1;
            for (i=1; i<n+2; i++){
                if(distance_[k][i] == w ){
                    DFS_.push(i);
                    visit[i] = 1;
                    }
                }
        }

        while (!DFS_.empty()){
            k = DFS_.front();
            DFS_.pop();
            for(i=1; i<n+2;i++){
                if(distance_[k][i] <= w && !visit[i] ){
                    visit[i] = 1;
                    DFS_.push(i);
                }
                if (distance_[k][i] <= w){
                    if (i == n+1){
                        visit[0] = w;
                        return visit;
                    }
                }
            }
            if(DFS_.empty()){
                w += 1;
                k=0;
                for (i=1; i<n+2; i++){
                    visit[i]=0;
                    if(distance_[k][i] <= w ){
                        DFS_.push(i);
                        visit[i] = 1;
                    }
                }
            }
        }

}


int main(){
    ifstream infile("battery.inp");
    ofstream outfile("battery.out");
    int n,z;
    infile >> n >> z;
    int i,j,k=0,visit[n+2];
    vector<vector<int>> distance_(n+2,vector<int>(n+2));
    double Px[n+2],Py[n+2],w;
    queue<int> DFS_;
    Px[0] = 0 ; Py[0] = 0; Px[n+1]=z; Py[n+1]=z;
    for (i=1;i<n+1;i++)
        infile >> Px[i] >> Py[i];
    w = 1;
    for(i=0; i<n+2;i++){
        for(j=0; j<n+2; j++){
            distance_[i][j] = ceil(sqrt(pow((Px[i] - Px[j]),2)+pow((Py[i] - Py[j]),2)));
        }
    }
    DFS(DFS_,distance_,n,w,k,visit);

    cout << visit[0] ;
    outfile << visit[0] ;
    outfile.close();
}







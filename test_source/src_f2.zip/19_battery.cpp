#include<bits/stdc++.h>
using namespace std;
vector<pair<int,int>> btr;
int len(pair<int,int> A, pair<int,int> B){
    return ceil(sqrt(pow(A.first-B.first,2)+pow(A.second-B.second,2)));
}
int dfs(vector<vector<int>> &length,vector<int> &visit,int ind,int limit){
    if(ind == length.size()-1)
        return 1;
    visit[ind]=1;
    int cnt=0;
    for(int i=length.size()-1;i>=0;--i){
        if((length[ind][i]!=0)&&(visit[i]==0)&&(length[ind][i]<=limit)){
            cnt+=dfs(length,visit,i,limit);
            if(cnt!=0)
                break;
        }
    }
    return cnt;
}
int main(){
    ifstream in("battery.inp");
    ofstream out("battery.out");
    int N,Z;
    in>>N>>Z;
    vector<vector<int>> length(N+2,vector<int>(N+2,0));
    btr.push_back(make_pair(0,0));
    for(int i=0;i<N;++i){
        int x,y;
        in>>x>>y;
        btr.push_back(make_pair(x,y));
    }
    btr.push_back(make_pair(Z,Z));
    for(int i=0;i<btr.size();++i){
        for(int j=i+1;j<btr.size();++j){
            length[i][j] = len(btr[i],btr[j]);
            length[j][i] = length[i][j];
        }
    }
    int left=0;
    int right=length[0][N+1];
    int pivot=right/2;
    while(left+1<right){
        vector<int> visit(N+2,0);
        if(dfs(length,visit,0,pivot)){
            right=pivot;
            pivot=ceil((pivot+left)/2);
        }
        else{
            left=pivot;
            pivot=ceil((pivot+right)/2);
        }
    }
    out<<pivot+1;
}

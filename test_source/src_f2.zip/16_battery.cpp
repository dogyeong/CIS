#include<cmath>
#include<iostream>
#include<queue>
#include<bits/stdc++.h>
#define MAX_LENGTH 10001
using namespace std;

int n,pivot,k;
float frval;
float dist[MAX_LENGTH][MAX_LENGTH];

class Node{
public:
    int counter=0,dpcount=0;
    int number,x,y;
    Node(int X,int Y,int num): x(X),y(Y),number(num){}
    float dp[MAX_LENGTH];
//    int pri[MAX_LENGTH];
    int print()
    {
        for(int i=0;i<n+1;i++)
            cout <<dp[i] <<" ";
        cout<<endl;
    }
};

int distinction(Node **nodes)
{
    int A,B;
    for(int i=0;i<n+1;i++)
    {
        k=0;
        for(int j=i+1;j<n+2;j++){
            A=(nodes[i]->x)-(nodes[j]->x);
            B=(nodes[i]->y)-(nodes[j]->y);
            A*=A,B*=B;
            dist[i][j]=sqrt(A+B);
            dist[j][i]=dist[i][j];
            nodes[i]->dp[(nodes[i]->dpcount)++]=dist[i][j];
            nodes[j]->dp[(nodes[j]->dpcount)++]=dist[i][j];
        }
    }
}

int BFS(int piv,Node ** node)
{
    queue<int> Q;
    int num;
    int expset[n+2]={0,};
    int ftcheck[n+2]={0,};
    Q.push(0);
    ftcheck[0]=1;
    while(!Q.empty())
    {
        num=Q.front();
        Q.pop();
        ftcheck[num]=0;
        if(num==n+1)return 1;
        else{
            expset[num]=1;
            for(int i=0;i<n+2;i++){
                if(dist[num][i]<=piv)
                {
                    if(expset[i] || ftcheck[i])continue;
                    Q.push(i);
                    ftcheck[i]=1;
                }
            }
        }
    }
    return 0;
}

int main()
{
    ifstream input("battery.inp");
    ofstream output("battery.out");

    int z,A,B;
    input >> n >>z;

    int wl=1,wr=n*sqrt(2);
    Node* nodes[n+2];
    nodes[0]=new Node(0,0,0);
    nodes[n+1]=new Node(z,z,n+1);
    for(int i=1;i<n+1;i++)
    {
        input>>A >>B;
        nodes[i]=new Node(A,B,i);
    }
    distinction(nodes);

    while(wl<wr)
    {
        pivot=(wl+wr)/2;
        if(BFS(pivot,nodes)) wr=pivot;
        else wl=pivot+1;
    }
    output <<wl << endl;
    input.close();
    output.close();

    return 0;
}

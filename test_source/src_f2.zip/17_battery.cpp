#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
using namespace std;
int s[2]={0,0};

int dis(int a[2], int b[2]){
    int64_t c;
    c = (a[0]-b[0])*(a[0]-b[0])+(a[1]-b[1])*(a[1]-b[1]);
    return c;
}

class point{
public:
    int x;
    int y;
    bool over=false;

    int dist(){
        int po[2];
        po[0]=x;
        po[1]=y;
        return dis(po,s);
    }

};
int dis(point a, point b){
    int64_t c;
    c=(a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y);
    return c;
}
void bubblesort(vector<point>& v){
    for(int i=0; i<v.size()-1; i++){
        for(int j=1; j<v.size()-i;j++){
            if(v[j-1].dist() > v[j].dist()){
                swap(v[j-1],v[j]);
            }
        }
    }
}
bool possible(vector<point> v, int a){
    bool poss=false, overlab=false, poss2=false;
    vector<point> vp, vpp, vo;
    vector<point>::iterator iter;
    point sp,v0;
    a=a*a;
    int bs=0, vs, vps=1,q=0;
    vp.push_back(v.front());
    int k=1,j;
    for(int j=1; j<v.size();j++){
        if(dis(v.front(), v[j])<=a){
            poss2=true;
            break;
        }
    }
    if(poss2==true){
        while(vp.back().x!=v.back().x){
            for(int i=0;i<vp.size();i++){
                for(int j=vp.size();j<v.size();j++){
                    if(v[j].over==true){

                    }
                    else if(dis(vp[i],v[j])<=a){
                        if(v[j].over==false){
                            vp.push_back(v[j]);
                            v[j].over=true;
                            break;
                        }
                    }
                }
            }
            if(vps==vp.size()){
                poss=false;
                break;
            }
            else{
                poss=true;
            }
            vps=vp.size();

        }

    }
    return poss;
}

int battery(vector<point> v, int z){
    int a, b[2],p[2]={0,0},zp[2], iv=v.size(), ivz=10000, w=1, k=0;
    point vo;
    point sp;
    sp.x=0;
    sp.y=0;
    int d[v.size()];
    vector<point> vp, v0;

    zp[0]=z;
    zp[1]=z;
    a=sqrt(dis(zp,s))/2;
    bubblesort(v);
    v0=v;
    vo=sp;
    while(w){
        if(possible(v, a)==1){
            a=a/2;
        }
        else{
            w=0;
        }
    }
    while(!possible(v, a)){
        a++;
    }
    return a;
}

int main()
{
    ifstream inputfile("battery.inp");
    ofstream outputfile("battery.out");
    int n, z, y;
    vector<point> v,vp;
    point p;
    inputfile>>n;
    inputfile>>z;
    for(int i=0; i<n; i++){
        inputfile>>p.x;
        inputfile>>p.y;

        v.push_back(p);
    }
    p.x=z;
    p.y=z;
    v.push_back(p);
    p.x=0;
    p.y=0;
    v.push_back(p);
    bubblesort(v);


    outputfile << battery(v,z);
    inputfile.close();
    outputfile.close();
    return 0;
}

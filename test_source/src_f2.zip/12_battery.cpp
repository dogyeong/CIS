#include <iostream>
#include <fstream>
#include <cassert>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

struct point {
	int x, y;
public:
	point(int _x=0, int _y=0)
		:x(_x), y(_y) {}
	double dis(const point& p) const {
		return sqrt((x-p.x)*(x-p.x)+(y-p.y)*(y-p.y));
	}
	bool operator < (const point& p) const {
		return x<p.x && y<p.y;
	}
	friend istream& operator >> (istream& is, point& p) {
		return is >> p.x >> p.y;
	}		
	friend ostream& operator << (ostream& os, const point& p) {
		return os << "(" << p.x << "," << p.y << ")";
	}
};

bool is_possible(vector<point> const& station, double d, int pos, vector<int>& check, vector<int>& dead_end) 
{	
	if(pos == station.size()-1)
		return true;
		
	for(int i=0;i<station.size();++i) {
		if(check[i]==0 && dead_end[i]==0 && (station[i].dis(station[pos]) <= d)) {
			check[i] = 1;
			if(is_possible(station, d, i, check, dead_end))
				return true;	
			check[i] = 0;	
		}	
	}
	dead_end[pos] = 1;
	return false;		 
}

double find_shortest(vector<point> const& station, point const& goal, double low, double high)
{	
	if((int)ceil(low)==(int)ceil(high))
		return ceil(high);
		
	double mid = (low+high)/2.0;	
	vector<int> check(station.size(),0);
	vector<int> dead_end(station.size(),0);
	if(is_possible(station,mid,0,check,dead_end))
		return find_shortest(station,goal,low,mid);
	return find_shortest(station,goal,mid,high);	
}

int main(void)
{
	ifstream ifs("battery.inp");
	assert(ifs.is_open());
	
	int n, z;
	ifs >> n >> z;
	
	point start = point(0,0);
	point goal = point(z,z);
	vector<point> station(n+2);
	station[0] = start;
	for(int i=1;i<=n;++i)
		ifs >> station[i];
	station[n+1] = goal;
	ifs.close();
	
	//sort(station.begin(), station.end());
	double d = find_shortest(station,goal,0.0,start.dis(goal));
	ofstream ofs("battery.out");
	ofs << (int)d << endl;
	ofs.close();	
	return 0;
}

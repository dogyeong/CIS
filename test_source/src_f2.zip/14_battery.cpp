#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <cmath>
using namespace std;
#define endl '\n'
void fastIO() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
}

vector<pair<int, int> > arr;

int dist(int here, int i) {
	return (arr[here].first - arr[i].first) * (arr[here].first - arr[i].first) +
	(arr[here].second - arr[i].second) * (arr[here].second - arr[i].second);
}

int bfs(int mid) {
	queue<int> q;
	int size = arr.size();
	vector<int> visited(size, 0);
	int dest = size - 1;
	visited[0] = 1;
	q.emplace(0);
	while(!q.empty()) {
		int here = q.front();
		q.pop();
		
		for(int i = size - 1 ; i >= 0; i -= 1) {
			if(visited[i] == 0 && dist(here, i) <= mid) {
				if(i == dest) return 1;
				visited[i] = 1;
				q.emplace(i);
			}
		}
	}
	return 0;
}

int main() {
	fastIO();
	
	//ifstream in("C:\\Users\\ksaid\\Downloads\\4-1\\�˰�����\\sampleData3\\1.inp");
	ifstream in("battery.inp");
	ofstream out("battery.out");
	
	int n, z;
	in >> n >> z;
	arr.emplace_back(0, 0);
	for(int i = 1 ; i <= n ; i += 1) {
		int x, y;
		in >> x >> y;
		arr.emplace_back(x, y);
	}
	arr.emplace_back(z, z);
	sort(arr.begin(), arr.end());
	int lo = 1, hi = 14143;
	while(lo <= hi) {
		int mid = (lo + hi) / 2;
		if(bfs(mid * mid)) {
			hi = mid - 1;
		}
		else {
			lo = mid + 1;
		}
	}
	out << lo << endl;
	in.close();
	out.close();
	return 0;
}



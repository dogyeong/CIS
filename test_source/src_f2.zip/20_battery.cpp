#include <iostream>
#include <vector>
#include <math.h>
#include <queue>
#include <fstream>

using namespace std;

class Point{
public:
    int x;
    int y;
    Point (int _x, int _y) : x(_x), y(_y){}
};

int n, z, x, y;
vector<Point> station;

double getDist(Point p1, Point p2){
    return sqrt((p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y));
}

bool bfs(int w){
    queue<Point> q;
    bool visited[n] = {false,};

    for (int i = 0; i<n; i++){
        Point temp = station.at(i);
        double dist = getDist(Point(0, 0), temp);
        if(dist <= w){
            q.push(station.at(i));
            visited[i] = true;
        }
    }

    while (!q.empty()) {
        Point f = q.front();
        q.pop();

        if(getDist(f, Point(z, z) ) <= w) return true;

        for(int i = 0; i<n ; i++){
            Point temp = station.at(i);
            if(visited[i])continue;
            if(getDist(temp, f) <= w){
                q.push(temp);
                visited[i] = true;
            }
        }
    }
    return false;
}

int main(){
    ifstream in("battery.inp");
    ofstream out("battery.out");

    in >> n >> z;
    for (int i = 0 ; i <n ;i++){
        in>>x>>y;
        station.push_back(Point(x,y));
    }

    int w= z/2;
    int diff = w;

    while(diff){
        if(bfs(w)) w-=diff;
        else w+=diff;
        diff/=2;
    }
    while(bfs(w)){w--;}
    while(!bfs(w)){w++;}
    out <<w<<endl;

	in.close();
    out.close();
    return 0;
}
